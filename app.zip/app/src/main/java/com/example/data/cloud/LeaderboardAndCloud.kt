package com.example.data.cloud

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

data class LeaderboardEntry(
    val rank: Int,
    val playerName: String,
    val avatarEmoji: String,
    val scoreText: String,
    val timeSec: Int,
    val stars: Int,
    val isCurrentPlayer: Boolean = false
)

object LeaderboardManager {
    private const val TAG = "LeaderboardManager"

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    /**
     * Đăng nhập ẩn danh qua Firebase Anonymous Authentication.
     * Tự động lấy UID định danh duy nhất cho riêng thiết bị này.
     */
    suspend fun getOrSignInAnonymousUid(): String? = suspendCoroutine { cont ->
        try {
            val currentUser = auth.currentUser
            if (currentUser != null) {
                cont.resume(currentUser.uid)
                return@suspendCoroutine
            }
            auth.signInAnonymously()
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    Log.d(TAG, "Đăng nhập ẩn danh thành công: $uid")
                    cont.resume(uid)
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Lỗi đăng nhập ẩn danh: ${e.message}")
                    cont.resume(null)
                }
        } catch (e: Exception) {
            Log.w(TAG, "Exception khi gọi Firebase Auth: ${e.message}")
            cont.resume(null)
        }
    }

    /**
     * Kiểm tra và đặt Nickname cho người chơi:
     * - Trim khoảng trắng và chuyển sang chữ thường (lowercase) để kiểm tra trùng.
     * - Nếu tên đã tồn tại bởi UID khác -> Báo lỗi không cho đặt trùng.
     * - Nếu chưa ai dùng -> Lưu cặp dữ liệu UID = Nickname và cho phép chơi.
     */
    suspend fun checkAndSaveNickname(nickname: String): Pair<Boolean, String?> = suspendCoroutine { cont ->
        val trimmed = nickname.trim()
        if (trimmed.length < 2 || trimmed.length > 20) {
            cont.resume(Pair(false, "Nickname phải từ 2 đến 20 ký tự!"))
            return@suspendCoroutine
        }

        val normalized = trimmed.lowercase()

        try {
            val currentUid = auth.currentUser?.uid
            if (currentUid == null) {
                auth.signInAnonymously()
                    .addOnSuccessListener { result ->
                        val newUid = result.user?.uid ?: "local_user"
                        validateAndCommitNickname(trimmed, normalized, newUid, cont)
                    }
                    .addOnFailureListener {
                        // Trường hợp không có mạng: chấp nhận tạm thời trên máy
                        cont.resume(Pair(true, null))
                    }
            } else {
                validateAndCommitNickname(trimmed, normalized, currentUid, cont)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Lỗi kiểm tra nickname: ${e.message}")
            cont.resume(Pair(true, null)) // Cho phép chơi offline
        }
    }

    private fun validateAndCommitNickname(
        displayName: String,
        normalizedName: String,
        uid: String,
        cont: kotlin.coroutines.Continuation<Pair<Boolean, String?>>
    ) {
        val usernameDocRef = firestore.collection("usernames").document(normalizedName)
        usernameDocRef.get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val existingUid = snapshot.getString("uid")
                    if (existingUid != null && existingUid != uid) {
                        // Tên đã có người khác sử dụng
                        cont.resume(Pair(false, "Tên này đã có người sử dụng, vui lòng chọn tên khác!"))
                        return@addOnSuccessListener
                    }
                }

                // Tên hợp lệ, lưu vào Database
                val usernameData = hashMapOf(
                    "uid" to uid,
                    "displayName" to displayName,
                    "normalizedName" to normalizedName,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val userData = hashMapOf(
                    "nickname" to displayName,
                    "normalizedName" to normalizedName,
                    "updatedAt" to FieldValue.serverTimestamp()
                )

                usernameDocRef.set(usernameData, SetOptions.merge())
                firestore.collection("users").document(uid).set(userData, SetOptions.merge())
                    .addOnSuccessListener {
                        cont.resume(Pair(true, null))
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "Không thể ghi tên người chơi: ${e.message}")
                        cont.resume(Pair(true, null)) // Cho phép chơi tiếp
                    }
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Không thể kiểm tra trùng tên qua mạng: ${e.message}")
                cont.resume(Pair(true, null)) // Cho phép chơi offline
            }
    }

    /**
     * Gửi điểm màn chơi (Level) lên Firestore nếu kỷ lục mới tốt hơn kỷ lục cũ (thời gian nhỏ hơn).
     */
    fun submitLevelScore(
        levelNumber: Int,
        playerName: String,
        timeSec: Int,
        stars: Int,
        moves: Int
    ) {
        if (timeSec <= 0) return
        val uid = auth.currentUser?.uid ?: return
        val levelDocRef = firestore.collection("leaderboard_levels")
            .document(levelNumber.toString())
            .collection("scores")
            .document(uid)

        levelDocRef.get().addOnSuccessListener { snapshot ->
            val oldTime = snapshot.getLong("timeSec")
            if (oldTime == null || timeSec < oldTime) {
                val data = hashMapOf(
                    "uid" to uid,
                    "playerName" to playerName.ifBlank { "Bạn" },
                    "timeSec" to timeSec,
                    "stars" to stars,
                    "moves" to moves,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                levelDocRef.set(data, SetOptions.merge())
            }
        }.addOnFailureListener {
            Log.w(TAG, "Lỗi gửi điểm màn $levelNumber: ${it.message}")
        }
    }

    /**
     * Gửi điểm thử thách hàng ngày (Daily Challenge) lên Firestore.
     */
    fun submitDailyScore(
        dateKey: String,
        playerName: String,
        timeSec: Int,
        stage: Int
    ) {
        if (timeSec <= 0) return
        val uid = auth.currentUser?.uid ?: return
        val dailyDocRef = firestore.collection("leaderboard_daily")
            .document(dateKey)
            .collection("scores")
            .document(uid)

        dailyDocRef.get().addOnSuccessListener { snapshot ->
            val oldTime = snapshot.getLong("timeSec")
            if (oldTime == null || timeSec < oldTime) {
                val data = hashMapOf(
                    "uid" to uid,
                    "playerName" to playerName.ifBlank { "Bạn" },
                    "timeSec" to timeSec,
                    "stage" to stage,
                    "stars" to 3,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                dailyDocRef.set(data, SetOptions.merge())
            }
        }.addOnFailureListener {
            Log.w(TAG, "Lỗi gửi điểm thử thách ngày $dateKey: ${it.message}")
        }
    }

    /**
     * Tải danh sách Bảng Xếp Hạng Top 100 người giải mê cung nhanh nhất (thời gian nhỏ nhất lên đầu).
     */
    suspend fun fetchLevelLeaderboard(
        levelNumber: Int,
        playerBestTimeSec: Int?,
        playerStars: Int,
        currentPlayerName: String
    ): List<LeaderboardEntry> = suspendCoroutine { cont ->
        val currentUid = auth.currentUser?.uid
        val fallbackList = getLocalLevelLeaderboard(playerBestTimeSec, playerStars, currentPlayerName)

        firestore.collection("leaderboard_levels")
            .document(levelNumber.toString())
            .collection("scores")
            .orderBy("timeSec", Query.Direction.ASCENDING)
            .limit(100)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (querySnapshot == null || querySnapshot.isEmpty) {
                    cont.resume(fallbackList)
                    return@addOnSuccessListener
                }

                val entries = mutableListOf<LeaderboardEntry>()
                var playerFoundInTop = false

                querySnapshot.documents.forEachIndexed { index, doc ->
                    val uid = doc.getString("uid") ?: doc.id
                    val name = doc.getString("playerName") ?: "Người chơi ${index + 1}"
                    val time = doc.getLong("timeSec")?.toInt() ?: 0
                    val stars = doc.getLong("stars")?.toInt() ?: 3
                    val isCurrent = (uid == currentUid)

                    if (isCurrent) playerFoundInTop = true

                    entries.add(
                        LeaderboardEntry(
                            rank = index + 1,
                            playerName = if (isCurrent) (currentPlayerName.ifBlank { name }) else name,
                            avatarEmoji = when (index) {
                                0 -> "👑"
                                1 -> "🥈"
                                2 -> "🥉"
                                else -> "🚀"
                            },
                            scoreText = "${time}s (${stars}★)",
                            timeSec = time,
                            stars = stars,
                            isCurrentPlayer = isCurrent
                        )
                    )
                }

                // Nếu người chơi chưa lọt Top 100 nhưng đã có điểm, chèn vào danh sách
                if (!playerFoundInTop && playerBestTimeSec != null && playerBestTimeSec > 0) {
                    entries.add(
                        LeaderboardEntry(
                            rank = entries.size + 1,
                            playerName = currentPlayerName.ifBlank { "Bạn" },
                            avatarEmoji = "🚀",
                            scoreText = "${playerBestTimeSec}s (${playerStars}★)",
                            timeSec = playerBestTimeSec,
                            stars = playerStars,
                            isCurrentPlayer = true
                        )
                    )
                }

                cont.resume(entries)
            }
            .addOnFailureListener {
                cont.resume(fallbackList)
            }
    }

    /**
     * Tải danh sách Bảng Xếp Hạng Thử Thách Ngày Top 100.
     */
    suspend fun fetchDailyLeaderboard(
        dateKey: String,
        playerScoreSec: Int?,
        currentPlayerName: String
    ): List<LeaderboardEntry> = suspendCoroutine { cont ->
        val currentUid = auth.currentUser?.uid
        val fallbackList = getLocalDailyLeaderboard(playerScoreSec, currentPlayerName)

        firestore.collection("leaderboard_daily")
            .document(dateKey)
            .collection("scores")
            .orderBy("timeSec", Query.Direction.ASCENDING)
            .limit(100)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (querySnapshot == null || querySnapshot.isEmpty) {
                    cont.resume(fallbackList)
                    return@addOnSuccessListener
                }

                val entries = mutableListOf<LeaderboardEntry>()
                var playerFoundInTop = false

                querySnapshot.documents.forEachIndexed { index, doc ->
                    val uid = doc.getString("uid") ?: doc.id
                    val name = doc.getString("playerName") ?: "Người chơi ${index + 1}"
                    val time = doc.getLong("timeSec")?.toInt() ?: 0
                    val isCurrent = (uid == currentUid)

                    if (isCurrent) playerFoundInTop = true

                    entries.add(
                        LeaderboardEntry(
                            rank = index + 1,
                            playerName = if (isCurrent) (currentPlayerName.ifBlank { name }) else name,
                            avatarEmoji = when (index) {
                                0 -> "👑"
                                1 -> "🥈"
                                2 -> "🥉"
                                else -> "🏆"
                            },
                            scoreText = "${time}s (⭐⭐⭐)",
                            timeSec = time,
                            stars = 3,
                            isCurrentPlayer = isCurrent
                        )
                    )
                }

                if (!playerFoundInTop && playerScoreSec != null && playerScoreSec > 0) {
                    entries.add(
                        LeaderboardEntry(
                            rank = entries.size + 1,
                            playerName = currentPlayerName.ifBlank { "Bạn" },
                            avatarEmoji = "🚀",
                            scoreText = "${playerScoreSec}s (⭐⭐⭐)",
                            timeSec = playerScoreSec,
                            stars = 3,
                            isCurrentPlayer = true
                        )
                    )
                }

                cont.resume(entries)
            }
            .addOnFailureListener {
                cont.resume(fallbackList)
            }
    }

    private fun getLocalLevelLeaderboard(
        playerBestTimeSec: Int?,
        playerStars: Int,
        currentPlayerName: String
    ): List<LeaderboardEntry> {
        val list = mutableListOf<LeaderboardEntry>()
        if (playerBestTimeSec != null && playerBestTimeSec > 0) {
            list.add(
                LeaderboardEntry(
                    rank = 1,
                    playerName = currentPlayerName.ifBlank { "Bạn" },
                    avatarEmoji = "🚀",
                    scoreText = "${playerBestTimeSec}s (${playerStars}★)",
                    timeSec = playerBestTimeSec,
                    stars = playerStars,
                    isCurrentPlayer = true
                )
            )
        }
        return list
    }

    private fun getLocalDailyLeaderboard(
        playerScoreSec: Int?,
        currentPlayerName: String
    ): List<LeaderboardEntry> {
        val list = mutableListOf<LeaderboardEntry>()
        if (playerScoreSec != null && playerScoreSec > 0) {
            list.add(
                LeaderboardEntry(
                    rank = 1,
                    playerName = currentPlayerName.ifBlank { "Bạn" },
                    avatarEmoji = "🚀",
                    scoreText = "${playerScoreSec}s (⭐⭐⭐)",
                    timeSec = playerScoreSec,
                    stars = 3,
                    isCurrentPlayer = true
                )
            )
        }
        return list
    }

    // Backward compatibility helper
    fun getLevelLeaderboard(levelNumber: Int, playerBestTimeSec: Int?, playerStars: Int): List<LeaderboardEntry> {
        return getLocalLevelLeaderboard(playerBestTimeSec, playerStars, "Bạn")
    }

    fun getDailyLeaderboard(playerScoreSec: Int?): List<LeaderboardEntry> {
        return getLocalDailyLeaderboard(playerScoreSec, "Bạn")
    }
}

object DailyChallengeManager {
    fun getTodayDateKey(): String {
        val now = LocalDate.now()
        return now.format(DateTimeFormatter.ISO_LOCAL_DATE)
    }

    /**
     * Kích thước mê cung cho từng lượt: Lượt 1: 14x14, Lượt 2: 15x15, Lượt 3: 16x16
     */
    fun getDailySize(stage: Int): Int {
        return when (stage) {
            1 -> 14
            2 -> 15
            3 -> 16
            else -> 14
        }
    }

    /**
     * Số bước mục tiêu chuẩn tương ứng cho từng kích thước
     */
    fun getDailyTarget(stage: Int): Int {
        return when (stage) {
            1 -> 95   // 14x14
            2 -> 110  // 15x15
            3 -> 130  // 16x16
            else -> 95
        }
    }

    /**
     * Phần thưởng Xu cho từng lượt
     */
    fun getDailyCoinsReward(stage: Int): Int {
        return when (stage) {
            1 -> 50
            2 -> 75
            3 -> 150
            else -> 50
        }
    }

    /**
     * Seed xác định cho từng ngày và từng lượt chơi (Đảm bảo tất cả người chơi cùng nhận 1 mê cung giống nhau)
     */
    fun getDailySeed(dateStr: String = getTodayDateKey(), stage: Int = 1): ULong {
        val now = try {
            LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE)
        } catch (e: Exception) {
            LocalDate.now()
        }
        val baseSeed = (now.year * 10000L + now.dayOfYear * 7919L)
        val stageSeed = baseSeed + (stage * 1337L)
        return stageSeed.toULong()
    }

    /**
     * Tính thời gian còn lại (mili-giây) cho đến 00:00:00 ngày hôm sau
     */
    fun getCooldownRemainingMillis(): Long {
        val now = java.time.LocalDateTime.now()
        val midnight = now.toLocalDate().plusDays(1).atStartOfDay()
        val duration = java.time.Duration.between(now, midnight)
        return maxOf(0L, duration.toMillis())
    }

    /**
     * Định dạng thời gian đếm ngược "HH:MM:SS"
     */
    fun formatCooldown(millis: Long): String {
        val totalSec = millis / 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    const val MAX_DAILY_ATTEMPTS = 3
    const val DAILY_SIZE = 14
    const val DAILY_TARGET = 95
}
