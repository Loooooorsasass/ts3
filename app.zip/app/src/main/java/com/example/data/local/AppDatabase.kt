package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        GameProgressEntity::class,
        LevelRecordEntity::class,
        SaveSlotEntity::class,
        AchievementEntity::class,
        DailyChallengeRecordEntity::class,
        MazeLevelEntity::class
    ],
    version = 16,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameProgressDao(): GameProgressDao
    abstract fun levelRecordDao(): LevelRecordDao
    abstract fun saveSlotDao(): SaveSlotDao
    abstract fun achievementDao(): AchievementDao
    abstract fun dailyChallengeDao(): DailyChallengeDao
    abstract fun mazeLevelDao(): MazeLevelDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfX INTEGER NOT NULL DEFAULT -1")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfY INTEGER NOT NULL DEFAULT -1")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfActive INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfCubX INTEGER NOT NULL DEFAULT -1")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfCubY INTEGER NOT NULL DEFAULT -1")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfCubActive INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfCubDistanceTraveled INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfStunnedUntilMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN playerFrozenUntilMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfNextIceThrowAtMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN wolfIceBeamUntilMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN freeAegisShieldInRun INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN shieldTriggeredCount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE save_slot ADD COLUMN gearDurabilityConsumedInRun INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE game_progress ADD COLUMN customVisionCells INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_progress ADD COLUMN hasPassedDemo INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "exact_maze_db"
                )
                    .addMigrations(MIGRATION_14_15, MIGRATION_15_16)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
