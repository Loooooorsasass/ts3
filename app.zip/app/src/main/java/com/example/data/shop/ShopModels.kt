package com.example.data.shop

import androidx.compose.ui.graphics.Color
import com.example.core.i18n.AppLanguage

data class PlayerSkin(
    val id: String,
    val name: String,
    val description: String,
    val priceCoins: Int,
    val iconEmoji: String,
    val primaryColor: Color,
    val secondaryColor: Color = primaryColor,
    val glowColor: Color,
    val isVipOnly: Boolean = false,
    val avatarType: PlayerAvatarType = PlayerAvatarType.NEON_SPHERE
) {
    companion object {
        fun fromGameItemSkin(item: GameItemSkin, lang: AppLanguage = AppLanguage.VI): PlayerSkin {
            return PlayerSkin(
                id = item.id,
                name = item.getName(lang),
                description = item.getDescription(lang),
                priceCoins = item.priceCoins,
                iconEmoji = item.iconEmoji,
                primaryColor = item.primaryColor,
                secondaryColor = item.secondaryColor,
                glowColor = item.glowColor,
                isVipOnly = item.isVipOnly,
                avatarType = item.avatarType
            )
        }
    }
}

data class MazeTheme(
    val id: String,
    val name: String,
    val nameEn: String,
    val priceCoins: Int,
    val bgColor: Color,
    val panelColor: Color,
    val wallColor: Color,
    val pathVisitedColor: Color,
    val accentColor: Color,
    val goalColor: Color
) {
    fun getDisplayName(lang: AppLanguage): String {
        return if (lang == AppLanguage.VI) name else nameEn
    }
}

data class EquipmentItem(
    val id: String,
    val nameVi: String,
    val nameEn: String,
    val descVi: String,
    val descEn: String,
    val iconEmoji: String,
    val priceCoins: Int,
    val priceKeys: Int,
    val accentColor: Color,
    val maxDurability: Int = 5
) {
    fun getName(lang: AppLanguage): String = if (lang == AppLanguage.VI) nameVi else nameEn
    fun getDesc(lang: AppLanguage): String = if (lang == AppLanguage.VI) descVi else descEn
}

object ShopCatalog {

    const val SINGLE_USE_SHIELD_PRICE_COINS = 280
    const val SINGLE_USE_SHIELD_PRICE_KEYS = 3
    const val SINGLE_USE_HINT_PRICE_COINS = 220
    const val SINGLE_USE_SKIP_PRICE_COINS = 380

    val EQUIPMENTS = listOf(
        EquipmentItem(
            id = "boots_haste",
            nameVi = "Giày Thần Tốc",
            nameEn = "Haste Boots",
            descVi = "+15s thời gian đếm ngược màn Sói Đuổi (Độ bền: 5 ván Sói Đuổi, hỏng sau 5 ván)",
            descEn = "+15s countdown time limit in Wolf Chase (Durability: 5 Wolf Chase games, breaks after 5 runs)",
            iconEmoji = "🥾",
            priceCoins = 450,
            priceKeys = 4,
            accentColor = Color(0xFF38BDF8),
            maxDurability = 5
        ),
        EquipmentItem(
            id = "shield_aegis",
            nameVi = "Khiên Aegis Cổ Đại",
            nameEn = "Ancient Aegis Shield",
            descVi = "Tự động chặn Sói 1 lần mỗi ván Sói Đuổi (Độ bền: 4 ván Sói Đuổi, hỏng sau 4 ván)",
            descEn = "Auto-blocks Wolf once per Wolf Chase run (Durability: 4 Wolf Chase games, breaks after 4 runs)",
            iconEmoji = "🛡️",
            priceCoins = 650,
            priceKeys = 5,
            accentColor = Color(0xFF60A5FA),
            maxDurability = 4
        ),
        EquipmentItem(
            id = "compass_vision",
            nameVi = "La Bàn Tiên Tri",
            nameEn = "Oracle Compass",
            descVi = "Bật sẵn Radar hướng đích & mở rộng tầm nhìn màn Sói Đuổi (Độ bền: 5 ván Sói Đuổi, hỏng sau 5 ván)",
            descEn = "Auto-enables Goal Radar & expands vision in Wolf Chase (Durability: 5 Wolf Chase games, breaks after 5 runs)",
            iconEmoji = "🧭",
            priceCoins = 550,
            priceKeys = 4,
            accentColor = Color(0xFF34D399),
            maxDurability = 5
        )
    )

    fun normalizeGearId(id: String): String {
        return when (id.trim()) {
            "boots_speed" -> "boots_haste"
            "armor_wolf" -> "shield_aegis"
            else -> id.trim()
        }
    }

    fun getEquipmentById(id: String): EquipmentItem? {
        if (id.isBlank()) return null
        val normalized = normalizeGearId(id)
        return EQUIPMENTS.find { it.id == normalized }
    }

    fun getSkins(lang: AppLanguage = AppLanguage.VI): List<PlayerSkin> {
        return GameItemAssets.ALL_SKINS.map { PlayerSkin.fromGameItemSkin(it, lang) }
    }

    val SKINS: List<PlayerSkin>
        get() = getSkins(AppLanguage.VI)

    val THEMES = listOf(
        MazeTheme(
            id = "ancient_forest",
            name = "1. Khu Rừng Cổ Đại (Ancient Forest)",
            nameEn = "1. Ancient Forest",
            priceCoins = 0,
            bgColor = Color(0xFF071B12),
            panelColor = Color(0xFF0F2B1F),
            wallColor = Color(0xFF34D399),
            pathVisitedColor = Color(0x5510B981),
            accentColor = Color(0xFF6EE7B7),
            goalColor = Color(0xFFFBBF24)
        ),
        MazeTheme(
            id = "frozen_labyrinth",
            name = "2. Mê Cung Băng Giá (Frozen Labyrinth)",
            nameEn = "2. Frozen Labyrinth",
            priceCoins = 350,
            bgColor = Color(0xFF08182B),
            panelColor = Color(0xFF102A45),
            wallColor = Color(0xFF7DD3FC),
            pathVisitedColor = Color(0x5538BDF8),
            accentColor = Color(0xFFBAE6FD),
            goalColor = Color(0xFFFDE047)
        ),
        MazeTheme(
            id = "neon_relics",
            name = "3. Di Tích Neon (Neon Relics)",
            nameEn = "3. Neon Relics",
            priceCoins = 450,
            bgColor = Color(0xFF090D24),
            panelColor = Color(0xFF14193D),
            wallColor = Color(0xFF22D3EE),
            pathVisitedColor = Color(0x5506B6D4),
            accentColor = Color(0xFFF472B6),
            goalColor = Color(0xFF34D399)
        ),
        MazeTheme(
            id = "golden_desert",
            name = "4. Biển Cát Hoàng Kim (Golden Desert)",
            nameEn = "4. Golden Desert",
            priceCoins = 550,
            bgColor = Color(0xFF1F160A),
            panelColor = Color(0xFF2E200E),
            wallColor = Color(0xFFFBBF24),
            pathVisitedColor = Color(0x55F59E0B),
            accentColor = Color(0xFFFDE047),
            goalColor = Color(0xFFEF4444)
        ),
        MazeTheme(
            id = "void_abyss",
            name = "5. Vực Thẳm Hư Vô (Void Abyss)",
            nameEn = "5. Void Abyss",
            priceCoins = 650,
            bgColor = Color(0xFF130924),
            panelColor = Color(0xFF20103A),
            wallColor = Color(0xFFC084FC),
            pathVisitedColor = Color(0x55A855F7),
            accentColor = Color(0xFFE879F9),
            goalColor = Color(0xFF38BDF8)
        ),
        MazeTheme(
            id = "classic_black",
            name = "6. Studio Đen Tương Phản (Studio Dark)",
            nameEn = "6. Studio High-Contrast Dark",
            priceCoins = 750,
            bgColor = Color(0xFF0B1120),
            panelColor = Color(0xFF152238),
            wallColor = Color(0xFF38BDF8),
            pathVisitedColor = Color(0x590284C7),
            accentColor = Color(0xFF38BDF8),
            goalColor = Color(0xFF10B981)
        ),
        MazeTheme(
            id = "crimson_ruby",
            name = "7. Hồng Ngọc Hỏa Diệm (Crimson Ruby)",
            nameEn = "7. Crimson Ruby",
            priceCoins = 850,
            bgColor = Color(0xFF210A13),
            panelColor = Color(0xFF33101E),
            wallColor = Color(0xFFFB7185),
            pathVisitedColor = Color(0x4DF43F5E),
            accentColor = Color(0xFFFDA4AF),
            goalColor = Color(0xFFFBBF24)
        ),
        MazeTheme(
            id = "cobalt_sapphire",
            name = "8. Lam Đại Dương (Ocean Sapphire)",
            nameEn = "8. Ocean Sapphire",
            priceCoins = 950,
            bgColor = Color(0xFF09152E),
            panelColor = Color(0xFF12234A),
            wallColor = Color(0xFF60A5FA),
            pathVisitedColor = Color(0x4D3B82F6),
            accentColor = Color(0xFF93C5FD),
            goalColor = Color(0xFFF97316)
        ),
        MazeTheme(
            id = "coral_sunset",
            name = "9. Cam Hoàng Hôn (Coral Sunset)",
            nameEn = "9. Coral Sunset",
            priceCoins = 1100,
            bgColor = Color(0xFF211109),
            panelColor = Color(0xFF331B0F),
            wallColor = Color(0xFFFB923C),
            pathVisitedColor = Color(0x4DF97316),
            accentColor = Color(0xFFFDBA74),
            goalColor = Color(0xFF22D3EE)
        ),
        MazeTheme(
            id = "arctic_mint",
            name = "10. Băng Tuyết Bạc Hà (Arctic Mint)",
            nameEn = "10. Arctic Mint",
            priceCoins = 1300,
            bgColor = Color(0xFF071D21),
            panelColor = Color(0xFF0E2E33),
            wallColor = Color(0xFF2DD4BF),
            pathVisitedColor = Color(0x4D14B8A6),
            accentColor = Color(0xFF5EEAD4),
            goalColor = Color(0xFFF43F5E)
        )
    )

    fun getSkinById(id: String, lang: AppLanguage = AppLanguage.VI): PlayerSkin {
        val item = GameItemAssets.findSkin(id)
        return PlayerSkin.fromGameItemSkin(item, lang)
    }

    fun getThemeById(id: String, isDarkMode: Boolean = true): MazeTheme {
        // Alias legacy IDs for smooth backward compatibility
        val resolvedId = when (id) {
            "classic_black" -> "ancient_forest" // Default era
            "midnight_cyber" -> "neon_relics"
            "emerald_matrix" -> "ancient_forest"
            "obsidian_gold" -> "golden_desert"
            "sunset_neon" -> "void_abyss"
            else -> id
        }
        val baseTheme = THEMES.find { it.id == resolvedId } ?: THEMES.find { it.id == id } ?: THEMES.first()
        if (!isDarkMode) {
            return baseTheme.copy(
                bgColor = Color(0xFFF6F7FA),
                panelColor = Color(0xFFFFFFFF),
                wallColor = if (baseTheme.id == "classic_black") Color(0xFF334155) else baseTheme.wallColor,
                pathVisitedColor = Color(0x330284C7),
                accentColor = if (baseTheme.id == "classic_black") Color(0xFF0284C7) else baseTheme.accentColor
            )
        }
        return baseTheme
    }

    fun getThemeByLevel(levelNum: Int): MazeTheme {
        return when (levelNum) {
            in 1..10 -> getThemeById("ancient_forest")
            in 11..20 -> getThemeById("frozen_labyrinth")
            in 21..30 -> getThemeById("neon_relics")
            in 31..40 -> getThemeById("golden_desert")
            else -> getThemeById("void_abyss")
        }
    }
}

data class GameEra(
    val id: String,
    val nameVi: String,
    val nameEn: String,
    val descriptionVi: String,
    val descriptionEn: String,
    val levels: IntRange,
    val themeId: String
)

object GameEras {
    val ERAS = listOf(
        GameEra(
            id = "ancient_forest",
            nameVi = "Khu Rừng Cổ Đại",
            nameEn = "Ancient Forest",
            descriptionVi = "Những con đường mòn rêu phong giữa đại ngàn bí ẩn.",
            descriptionEn = "Mossy trails shrouded in the primeval canopy.",
            levels = 1..10,
            themeId = "ancient_forest"
        ),
        GameEra(
            id = "frozen_labyrinth",
            nameVi = "Mê Cung Băng Giá",
            nameEn = "Frozen Labyrinth",
            descriptionVi = "Băng tuyết vĩnh cửu với mặt sàn trơn trượt thử thách bước chân.",
            descriptionEn = "Eternal glaciers with slippery icy pathways.",
            levels = 11..20,
            themeId = "frozen_labyrinth"
        ),
        GameEra(
            id = "neon_relics",
            nameVi = "Di Tích Neon",
            nameEn = "Neon Relics",
            descriptionVi = "Tàn tích công nghệ cổ xưa phát sáng lập lòe trong màn đêm.",
            descriptionEn = "Ancient cyber ruins humming with holographic energy.",
            levels = 21..30,
            themeId = "neon_relics"
        ),
        GameEra(
            id = "golden_desert",
            nameVi = "Biển Cát Hoàng Kim",
            nameEn = "Golden Desert",
            descriptionVi = "Biển cát rực vàng che giấu những mật đạo nghìn năm.",
            descriptionEn = "Sun-drenched golden dunes hiding forgotten secrets.",
            levels = 31..40,
            themeId = "golden_desert"
        ),
        GameEra(
            id = "void_abyss",
            nameVi = "Vực Thẳm Hư Vô",
            nameEn = "Void Abyss",
            descriptionVi = "Khoảng không vũ trụ huyền bí, nơi thử thách đỉnh cao trí tuệ.",
            descriptionEn = "Cosmic abyss where the ultimate test of wisdom awaits.",
            levels = 41..50,
            themeId = "void_abyss"
        )
    )

    fun getEraForLevel(levelNum: Int): GameEra {
        return ERAS.find { levelNum in it.levels } ?: ERAS.last()
    }
}
