package com.example.data.lore

data class LoreCard(
    val id: String,
    val milestoneLevel: Int,
    val eraId: String,
    val titleVi: String,
    val titleEn: String,
    val quoteVi: String,
    val quoteEn: String,
    val authorOrLoreVi: String,
    val authorOrLoreEn: String,
    val badgeIcon: String
)

object ExplorerJournal {
    val CARDS = listOf(
        LoreCard(
            id = "lore_lv5",
            milestoneLevel = 5,
            eraId = "ancient_forest",
            titleVi = "Bước Chân Đầu Tiên",
            titleEn = "First Steps",
            quoteVi = "Đường cụt không phải là thất bại, đó là nơi dạy bạn biết quay đầu.",
            quoteEn = "A dead end is never a defeat; it teaches you the wisdom of turning back.",
            authorOrLoreVi = "Triết lý Kẻ Khám Phá Rừng Sâu",
            authorOrLoreEn = "Forest Explorer's Lore",
            badgeIcon = "🌱"
        ),
        LoreCard(
            id = "lore_lv10",
            milestoneLevel = 10,
            eraId = "ancient_forest",
            titleVi = "Trí Tuệ Cổ Đại",
            titleEn = "Ancient Wisdom",
            quoteVi = "Không có con đường nào là vô nghĩa. Mỗi ngã rẽ đều tôi luyện nên bản lĩnh người lữ hành.",
            quoteEn = "No path is walked in vain. Every turn forges the soul of the traveler.",
            authorOrLoreVi = "Bia Đá Cổ Đại",
            authorOrLoreEn = "Ancient Forest Monolith",
            badgeIcon = "🌿"
        ),
        LoreCard(
            id = "lore_lv15",
            milestoneLevel = 15,
            eraId = "frozen_labyrinth",
            titleVi = "Ngọn Lửa Kiên Định",
            titleEn = "Steadfast Flame",
            quoteVi = "Sự bình tĩnh giữa bão tuyết chính là ngọn lửa ấm áp nhất dẫn lối qua băng giá.",
            quoteEn = "Serenity amidst the blizzard is the warmest flame guiding you home.",
            authorOrLoreVi = "Nhật Ký Thám Hiểm Cực Bắc",
            authorOrLoreEn = "Arctic Explorer's Log",
            badgeIcon = "❄️"
        ),
        LoreCard(
            id = "lore_lv20",
            milestoneLevel = 20,
            eraId = "frozen_labyrinth",
            titleVi = "Vượt Qua Giới Hạn",
            titleEn = "Beyond the Ice",
            quoteVi = "Khi mặt đất trơn trượt khó bước, hãy học cách lướt theo nhịp điệu của sự dũng cảm.",
            quoteEn = "When the ice is slick beneath your feet, glide forward with fearless grace.",
            authorOrLoreVi = "Lời Dặn Của Thần Băng",
            authorOrLoreEn = "Words of the Frost Spirit",
            badgeIcon = "🧊"
        ),
        LoreCard(
            id = "lore_lv25",
            milestoneLevel = 25,
            eraId = "neon_relics",
            titleVi = "Ánh Sáng Chân Thật",
            titleEn = "True Frequency",
            quoteVi = "Giữa muôn ngàn tín hiệu nhiễu loạn, chỉ có tâm tĩnh lặng mới tìm thấy lối ra chân thật.",
            quoteEn = "Amidst thousands of neon distortions, only a tranquil mind hears the true signal.",
            authorOrLoreVi = "Mã Lệnh Di Tích Cyber",
            authorOrLoreEn = "Cyber Ruins Terminal",
            badgeIcon = "⚡"
        ),
        LoreCard(
            id = "lore_lv30",
            milestoneLevel = 30,
            eraId = "neon_relics",
            titleVi = "Linh Cảm Người Khám Phá",
            titleEn = "The Human Spark",
            quoteVi = "Máy móc tính toán đường đi ngắn nhất, nhưng chính trực giác đưa con người đến đỉnh vinh quang.",
            quoteEn = "Machines compute the shortest path, but intuition carries the human spirit to triumph.",
            authorOrLoreVi = "Nhật Ký Kỹ Sư Cổ",
            authorOrLoreEn = "Old Engineer's Note",
            badgeIcon = "🔮"
        ),
        LoreCard(
            id = "lore_lv35",
            milestoneLevel = 35,
            eraId = "golden_desert",
            titleVi = "Ảo Ảnh Sa Mạc",
            titleEn = "Desert Mirage",
            quoteVi = "Đừng để ảo ảnh đánh lừa; kiên trì từng bước chân nhỏ sẽ đưa bạn qua biển cát mênh mông.",
            quoteEn = "Do not be deceived by mirages; steady steps will conquer the widest desert.",
            authorOrLoreVi = "Châm Ngôn Lữ Khách Sa Mạc",
            authorOrLoreEn = "Desert Nomad Proverb",
            badgeIcon = "🏜️"
        ),
        LoreCard(
            id = "lore_lv40",
            milestoneLevel = 40,
            eraId = "golden_desert",
            titleVi = "Kho Báu Thời Gian",
            titleEn = "Treasure of Time",
            quoteVi = "Cổ vật quý giá nhất không chỉ nằm ở vạch đích, mà là kinh nghiệm khắc sâu qua từng ngả đường.",
            quoteEn = "The greatest treasure is not merely the goal, but the wisdom earned along the way.",
            authorOrLoreVi = "Bản Thảo Kim Tự Tháp",
            authorOrLoreEn = "Pyramid Papyrus",
            badgeIcon = "🏺"
        ),
        LoreCard(
            id = "lore_lv45",
            milestoneLevel = 45,
            eraId = "void_abyss",
            titleVi = "Niềm Tin Trong Bóng Tối",
            titleEn = "Leap of Faith",
            quoteVi = "Trong bóng tối mịt mù nhất, một đốm sáng nhỏ của niềm tin cũng đủ thắp sáng cả mê cung.",
            quoteEn = "In the darkest abyss, a single spark of faith illuminates the entire labyrinth.",
            authorOrLoreVi = "Bản Ghi Thiên Hà",
            authorOrLoreEn = "Galactic Chronicle",
            badgeIcon = "🌌"
        ),
        LoreCard(
            id = "lore_lv50",
            milestoneLevel = 50,
            eraId = "void_abyss",
            titleVi = "Đỉnh Cao Trí Tuệ",
            titleEn = "Apex of Wisdom",
            quoteVi = "Bạn đã vượt qua mọi giới hạn. Không còn mê cung nào có thể giam giữ một tâm hồn tự do và sáng suốt.",
            quoteEn = "You have transcended every limit. No maze can ever constrain a free and enlightened soul.",
            authorOrLoreVi = "Di Ngôn Của Người Sáng Lập",
            authorOrLoreEn = "The Architect's Testament",
            badgeIcon = "👑"
        )
    )

    fun getUnlockedCards(highestCleared: Int): List<LoreCard> {
        return CARDS.filter { highestCleared >= it.milestoneLevel }
    }

    fun getLatestUnlockedCard(highestCleared: Int): LoreCard? {
        return CARDS.filter { highestCleared >= it.milestoneLevel }.maxByOrNull { it.milestoneLevel }
    }
}
