package com.example.core.engine

import java.util.ArrayDeque
import kotlin.random.Random

/**
 * Danh sách các thuật toán sinh mê cung lục giác hỗ trợ:
 * - DFS / Recursive Backtracking: Đường dài ngoằn ngoèo, ít rẽ nhánh, lời giải sâu.
 * - Prim: Phân nhánh trung bình, nhiều nhánh ngắn tỏa từ thân chính.
 * - Kruskal: Cây bao trùm qua Disjoint-Set / Forest, ngẫu nhiên hoàn toàn fractal.
 */
enum class HexAlgorithm(val id: Int, val nameVi: String, val nameEn: String) {
    DFS(1, "Quay lui (DFS Backtracking)", "Recursive Backtracker (DFS)"),
    PRIM(2, "Thuật toán Prim", "Prim's Algorithm"),
    KRUSKAL(3, "Thuật toán Kruskal", "Kruskal's Algorithm")
}

/**
 * Engine tạo, giải và AI Pac-Man trên lưới lục giác (Pointy-Top / Odd-r offset coordinates).
 * Hỗ trợ chuyển đổi sang Axial coordinates (q, r) và Cube coordinates (x, y, z) với x + y + z = 0.
 */
object HexMazeEngine {

    /**
     * Xây dựng mê cung lục giác với thuật toán được chỉ định hoặc mặc định (Kruskal/DFS/Prim).
     * @param cols   số cột của lưới
     * @param rows   số hàng của lưới
     * @param target số bước tối ưu (được tính sau khi xác định start/goal)
     * @param seed   chuỗi seed để tạo Random
     * @param algorithm thuật toán sinh (DFS, Prim, Kruskal)
     * @return HexMaze đã sẵn sàng
     */
    fun buildHexMaze(
        cols: Int,
        rows: Int,
        target: Int = 0,
        seed: String = System.nanoTime().toString(),
        algorithm: HexAlgorithm = HexAlgorithm.KRUSKAL
    ): HexMaze {
        val random = Random(seed.hashCode())
        val total = cols * rows
        val masks = IntArray(total) { 0 }

        when (algorithm) {
            HexAlgorithm.DFS -> generateHexDFS(cols, rows, masks, random)
            HexAlgorithm.PRIM -> generateHexPrim(cols, rows, masks, random)
            HexAlgorithm.KRUSKAL -> generateHexKruskal(cols, rows, masks, random)
        }

        // Tìm cặp ô xa nhất (double BFS) để làm start/goal
        val (startIdx, goalIdx) = findFurthestPair(masks, cols, rows)
        val start = HexPoint(startIdx % cols, startIdx / cols)
        val goal = HexPoint(goalIdx % cols, goalIdx / cols)

        // Tìm đường ngắn nhất (spine)
        val spine = findHexShortestPath(masks, cols, rows, start, goal)
        val finalTarget = if (target > 0) target else (spine.size - 1).coerceAtLeast(1)

        return HexMaze(cols, rows, masks, start, goal, spine, finalTarget, seed)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1. THUẬT TOÁN QUAY LUI ĐỆ QUY (RECURSIVE BACKTRACKER / DFS)
    // ─────────────────────────────────────────────────────────────────────────
    private fun generateHexDFS(cols: Int, rows: Int, masks: IntArray, rand: Random) {
        val total = cols * rows
        val visited = BooleanArray(total)
        val stack = ArrayDeque<Int>()

        val startIdx = rand.nextInt(total)
        stack.addLast(startIdx)
        visited[startIdx] = true

        while (stack.isNotEmpty()) {
            val current = stack.last()
            val cCol = current % cols
            val cRow = current / cols

            val unvisitedNeighbors = mutableListOf<Pair<Int, HexDirection>>()
            for (dir in HexDirection.values()) {
                val (nCol, nRow) = dir.neighbor(cCol, cRow)
                if (nCol in 0 until cols && nRow in 0 until rows) {
                    val nIdx = nRow * cols + nCol
                    if (!visited[nIdx]) {
                        unvisitedNeighbors.add(Pair(nIdx, dir))
                    }
                }
            }

            if (unvisitedNeighbors.isNotEmpty()) {
                val (nextIdx, direction) = unvisitedNeighbors[rand.nextInt(unvisitedNeighbors.size)]
                masks[current] = masks[current] or direction.bit
                masks[nextIdx] = masks[nextIdx] or HexDirection.opposite(direction).bit
                visited[nextIdx] = true
                stack.addLast(nextIdx)
            } else {
                stack.removeLast()
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. THUẬT TOÁN PRIM (RANDOMIZED PRIM'S ALGORITHM)
    // ─────────────────────────────────────────────────────────────────────────
    private data class HexWallEdge(val fromIdx: Int, val toIdx: Int, val dir: HexDirection)

    private fun generateHexPrim(cols: Int, rows: Int, masks: IntArray, rand: Random) {
        val total = cols * rows
        val inMaze = BooleanArray(total)
        val frontier = ArrayList<HexWallEdge>()

        fun addFrontierEdges(idx: Int) {
            val cCol = idx % cols
            val cRow = idx / cols
            for (dir in HexDirection.values()) {
                val (nCol, nRow) = dir.neighbor(cCol, cRow)
                if (nCol in 0 until cols && nRow in 0 until rows) {
                    val nIdx = nRow * cols + nCol
                    if (!inMaze[nIdx]) {
                        frontier.add(HexWallEdge(idx, nIdx, dir))
                    }
                }
            }
        }

        val startIdx = rand.nextInt(total)
        inMaze[startIdx] = true
        addFrontierEdges(startIdx)

        while (frontier.isNotEmpty()) {
            val randIdx = rand.nextInt(frontier.size)
            val edge = frontier.removeAt(randIdx)

            if (!inMaze[edge.toIdx]) {
                masks[edge.fromIdx] = masks[edge.fromIdx] or edge.dir.bit
                masks[edge.toIdx] = masks[edge.toIdx] or HexDirection.opposite(edge.dir).bit
                inMaze[edge.toIdx] = true
                addFrontierEdges(edge.toIdx)
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. THUẬT TOÁN KRUSKAL (RANDOMIZED KRUSKAL VỚI DISJOINT-SET / DSU)
    // ─────────────────────────────────────────────────────────────────────────
    private class DisjointSet(size: Int) {
        val parent = IntArray(size) { it }
        val rank = IntArray(size) { 0 }

        fun find(i: Int): Int {
            var root = i
            while (root != parent[root]) {
                root = parent[root]
            }
            var curr = i
            while (curr != root) {
                val next = parent[curr]
                parent[curr] = root
                curr = next
            }
            return root
        }

        fun union(i: Int, j: Int): Boolean {
            val rootI = find(i)
            val rootJ = find(j)
            if (rootI == rootJ) return false

            if (rank[rootI] < rank[rootJ]) {
                parent[rootI] = rootJ
            } else if (rank[rootI] > rank[rootJ]) {
                parent[rootJ] = rootI
            } else {
                parent[rootJ] = rootI
                rank[rootI]++
            }
            return true
        }
    }

    private fun generateHexKruskal(cols: Int, rows: Int, masks: IntArray, rand: Random) {
        val total = cols * rows
        val dsu = DisjointSet(total)
        val allEdges = ArrayList<HexWallEdge>()

        // Thu thập tất cả các cạnh duy nhất giữa 2 ô lục giác kề nhau
        // Chỉ cần duyệt 3 hướng thuận (NE, E, SE) để tránh trùng lặp cạnh vô hướng
        val forwardDirs = arrayOf(HexDirection.NE, HexDirection.E, HexDirection.SE)

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val u = r * cols + c
                for (dir in forwardDirs) {
                    val (nc, nr) = dir.neighbor(c, r)
                    if (nc in 0 until cols && nr in 0 until rows) {
                        val v = nr * cols + nc
                        allEdges.add(HexWallEdge(u, v, dir))
                    }
                }
            }
        }

        // Xáo trộn ngẫu nhiên tất cả các cạnh
        allEdges.shuffle(rand)

        // Hợp nhất hai ô ở hai bên nếu chúng chưa liên thông
        for (edge in allEdges) {
            if (dsu.union(edge.fromIdx, edge.toIdx)) {
                masks[edge.fromIdx] = masks[edge.fromIdx] or edge.dir.bit
                masks[edge.toIdx] = masks[edge.toIdx] or HexDirection.opposite(edge.dir).bit
            }
        }
    }

    /**
     * BFS tìm đường ngắn nhất trên lưới hex giữa start và goal.
     */
    fun findHexShortestPath(masks: IntArray, cols: Int, rows: Int, start: HexPoint, goal: HexPoint): List<HexPoint> {
        val total = cols * rows
        val prev = IntArray(total) { -1 }
        val queue: ArrayDeque<Int> = ArrayDeque()
        val startIdx = start.row * cols + start.col
        val goalIdx = goal.row * cols + goal.col

        queue.add(startIdx)
        prev[startIdx] = startIdx

        while (queue.isNotEmpty()) {
            val idx = queue.removeFirst()
            if (idx == goalIdx) break
            val col = idx % cols
            val row = idx / cols
            val mask = masks[idx]

            for (dir in HexDirection.values()) {
                if (mask and dir.bit != 0) {
                    val (nCol, nRow) = dir.neighbor(col, row)
                    if (nCol in 0 until cols && nRow in 0 until rows) {
                        val nIdx = nRow * cols + nCol
                        if (prev[nIdx] == -1) {
                            prev[nIdx] = idx
                            queue.add(nIdx)
                        }
                    }
                }
            }
        }

        val path = mutableListOf<HexPoint>()
        var cur = goalIdx
        if (prev[cur] == -1) return path
        while (cur != startIdx) {
            val col = cur % cols
            val row = cur / cols
            path.add(HexPoint(col, row))
            cur = prev[cur]
        }
        path.add(start)
        path.reverse()
        return path
    }

    /**
     * Double BFS để tìm cặp ô xa nhất trong toàn bộ lưới (startIdx, goalIdx).
     */
    fun findFurthestPair(masks: IntArray, cols: Int, rows: Int): Pair<Int, Int> {
        val first = bfsFurthest(0, masks, cols, rows)
        val second = bfsFurthest(first, masks, cols, rows)
        return Pair(first, second)
    }

    private fun bfsFurthest(startIdx: Int, masks: IntArray, cols: Int, rows: Int): Int {
        val total = cols * rows
        val dist = IntArray(total) { -1 }
        val queue: ArrayDeque<Int> = ArrayDeque()
        queue.add(startIdx)
        dist[startIdx] = 0
        var furthestIdx = startIdx

        while (queue.isNotEmpty()) {
            val idx = queue.removeFirst()
            val col = idx % cols
            val row = idx / cols
            val mask = masks[idx]

            for (dir in HexDirection.values()) {
                if (mask and dir.bit != 0) {
                    val (nCol, nRow) = dir.neighbor(col, row)
                    if (nCol in 0 until cols && nRow in 0 until rows) {
                        val nIdx = nRow * cols + nCol
                        if (dist[nIdx] == -1) {
                            dist[nIdx] = dist[idx] + 1
                            queue.add(nIdx)
                            if (dist[nIdx] > dist[furthestIdx]) {
                                furthestIdx = nIdx
                            }
                        }
                    }
                }
            }
        }
        return furthestIdx
    }

    /**
     * AI Pac‑Man: tính bước tiếp theo để di chuyển tới người chơi trên lưới lục giác.
     */
    object HexPacmanAI {
        fun computeNextMove(maze: HexMaze, pacmanPos: HexPoint, playerPos: HexPoint): HexPoint? {
            val path = findHexShortestPath(maze.masks, maze.cols, maze.rows, pacmanPos, playerPos)
            return if (path.size >= 2) path[1] else null
        }

        fun computeDistanceMap(maze: HexMaze, fromPos: HexPoint): IntArray {
            val total = maze.cols * maze.rows
            val dist = IntArray(total) { -1 }
            val queue: ArrayDeque<Int> = ArrayDeque()
            val startIdx = fromPos.row * maze.cols + fromPos.col
            queue.add(startIdx)
            dist[startIdx] = 0

            while (queue.isNotEmpty()) {
                val idx = queue.removeFirst()
                val col = idx % maze.cols
                val row = idx / maze.cols
                val mask = maze.masks[idx]

                for (dir in HexDirection.values()) {
                    if (mask and dir.bit != 0) {
                        val (nCol, nRow) = dir.neighbor(col, row)
                        if (nCol in 0 until maze.cols && nRow in 0 until maze.rows) {
                            val nIdx = nRow * maze.cols + nCol
                            if (dist[nIdx] == -1) {
                                dist[nIdx] = dist[idx] + 1
                                queue.add(nIdx)
                            }
                        }
                    }
                }
            }
            return dist
        }
    }
}
