package com.example.core.engine

/**
 * Các hằng số hướng cho lưới lục giác (odd-r offset).
 * Sử dụng bitmask để lưu trạng thái đường mở.
 */
const val HEX_NE = 1    // Northeast
const val HEX_E  = 2    // East
const val HEX_SE = 4    // Southeast
const val HEX_SW = 8    // Southwest
const val HEX_W  = 16   // West
const val HEX_NW = 32   // Northwest

/**
 * Enum biểu diễn các hướng lục giác cùng với offset cho các hàng chẵn/ lẻ.
 */
enum class HexDirection(val bit: Int, val dxEven: Int, val dyEven: Int, val dxOdd: Int, val dyOdd: Int) {
    NE(HEX_NE, 0, -1, 1, -1),
    E (HEX_E , 1, 0 , 1, 0 ),
    SE(HEX_SE, 0, 1 , 1, 1 ),
    SW(HEX_SW,-1, 1 , 0, 1 ),
    W (HEX_W , -1,0 , -1,0 ),
    NW(HEX_NW, -1,-1, 0,-1 );

    /**
     * Tính tọa độ ô kế tiếp dựa trên parity của hàng hiện tại.
     */
    fun neighbor(col: Int, row: Int): Pair<Int, Int> {
        return if (row % 2 == 0) {
            Pair(col + dxEven, row + dyEven)
        } else {
            Pair(col + dxOdd, row + dyOdd)
        }
    }

    companion object {
        /**
         * Trả về hướng tương đương (đối diện).
         */
        fun opposite(direction: HexDirection): HexDirection = when (direction) {
            NE -> SW
            E  -> W
            SE -> NW
            SW -> NE
            W  -> E
            NW -> SE
        }
    }
}

/**
 * Tọa độ trục (Axial Coordinates) cho lưới lục giác: (q, r).
 */
data class HexAxial(val q: Int, val r: Int) {
    /**
     * Chuyển đổi sang tọa độ lập phương (Cube Coordinates): x + y + z = 0.
     */
    val cubeX: Int get() = q
    val cubeZ: Int get() = r
    val cubeY: Int get() = -q - r

    /**
     * Chuyển đổi về tọa độ offset odd-r (col, row).
     */
    fun toOffset(): HexPoint {
        val col = q + (r - (r and 1)) / 2
        return HexPoint(col, r)
    }
}

/**
 * Điểm trên lưới lục giác, sử dụng hệ tọa độ cột‑hàng offset odd-r (col, row).
 * Hỗ trợ chuyển đổi sang hệ tọa độ trục Axial (q, r) và Cube (x, y, z) với x + y + z = 0.
 */
data class HexPoint(val col: Int, val row: Int) {
    /**
     * Chuyển đổi sang tọa độ trục Axial (q, r).
     */
    fun toAxial(): HexAxial {
        val q = col - (row - (row and 1)) / 2
        val r = row
        return HexAxial(q, r)
    }

    /**
     * Khoảng cách lục giác (Manhattan distance trên lưới lục giác) tới điểm khác.
     */
    fun distanceTo(other: HexPoint): Int {
        val a = toAxial()
        val b = other.toAxial()
        return (Math.abs(a.cubeX - b.cubeX) + Math.abs(a.cubeY - b.cubeY) + Math.abs(a.cubeZ - b.cubeZ)) / 2
    }
}

/**
 * Cấu trúc ma trận mê cung lục giác.
 * Mỗi ô lưu bitmask các lối đi mở (không có tường) theo hướng HEX_*.
 */
data class HexMaze(
    val cols: Int,
    val rows: Int,
    val masks: IntArray, // size = cols * rows
    val start: HexPoint,
    val goal: HexPoint,
    val spine: List<HexPoint>, // đường ngắn nhất giữa start và goal
    val target: Int, // số bước tối ưu cần di chuyển
    val seedStr: String
) {
    /**
     * Lấy bitmask của ô tại (col, row). Trả về 0 nếu ngoài phạm vi.
     */
    fun cellAt(col: Int, row: Int): Int {
        if (col !in 0 until cols || row !in 0 until rows) return 0
        return masks[row * cols + col]
    }

    /**
     * Trả về danh sách các ô láng giềng có kết nối mở từ ô hiện tại.
     */
    fun neighbors(col: Int, row: Int): List<HexPoint> {
        val mask = cellAt(col, row)
        val result = mutableListOf<HexPoint>()
        for (dir in HexDirection.values()) {
            if (mask and dir.bit != 0) {
                val (nCol, nRow) = dir.neighbor(col, row)
                if (isValidCell(nCol, nRow)) {
                    result.add(HexPoint(nCol, nRow))
                }
            }
        }
        return result
    }

    private fun isValidCell(col: Int, row: Int): Boolean = col in 0 until cols && row in 0 until rows
}

/**
 * Định nghĩa mức độ (level) cho chế độ lục giác.
 */
data class HexLevelDef(
    val id: String,
    val numericLevel: Int?,
    val cols: Int,
    val rows: Int,
    val target: Int,
    val isPacmanChase: Boolean = false,
    val timeLimitSec: Int = 0,
    val vision: Int? = null
)

/**
 * Cấu hình tĩnh cho các mức lục giác.
 */
object HexMazeConfig {
    const val MAX_HEX_LEVEL = 50
    const val MAX_PACMAN_LEVEL = 20
    const val PACMAN_UNLOCK_LEVEL = 10
    const val PACMAN_SPAWN_DELAY_SEC = 5
    const val PACMAN_NORMAL_STEP_MS = 500L
    const val PACMAN_FAST_STEP_MS = 350L
    const val PACMAN_FRENZY_STEP_MS = 250L

    /**
     * Tốc độ Pac-man tăng dần từ dễ đến khó (Cấp 1: 520ms -> Cấp 20: 250ms)
     */
    fun pacmanStepIntervalForLevel(stage: Int): Long {
        val clamped = stage.coerceIn(1, MAX_PACMAN_LEVEL)
        return (520L - (clamped - 1) * 14L).coerceAtLeast(250L)
    }

    /**
     * Tính kích thước lưới (cols, rows) dựa trên level.
     */
    fun hexMapSizeForLevel(level: Int): Pair<Int, Int> {
        return when {
            level <= 10 -> Pair(5 + (level - 1) / 2, 5 + (level - 1) / 2) // 5x5 → 9x9
            level <= 30 -> Pair(10 + (level - 11) / 2, 10 + (level - 11) / 2) // 10x10 → 19x19
            else -> Pair(20 + (level - 31) / 2, 20 + (level - 31) / 2) // 20x20 → 29x29
        }
    }

    /**
     * Tạo đối tượng HexLevelDef cho một level thường.
     */
    fun generateHexLevelDef(level: Int): HexLevelDef {
        val (c, r) = hexMapSizeForLevel(level)
        return HexLevelDef(
            id = "HEX_$level",
            numericLevel = level,
            cols = c,
            rows = r,
            target = 0, // sẽ được tính bởi engine
            isPacmanChase = false
        )
    }

    /**
     * Tạo đối tượng HexLevelDef cho chế độ Pac‑Man chase.
     */
    fun generatePacmanLevelDef(pacmanStage: Int): HexLevelDef {
        val (c, r) = hexMapSizeForLevel(pacmanStage + PACMAN_UNLOCK_LEVEL)
        return HexLevelDef(
            id = "HEX_PACMAN_$pacmanStage",
            numericLevel = pacmanStage,
            cols = c,
            rows = r,
            target = 0,
            isPacmanChase = true,
            timeLimitSec = 0
        )
    }

    /**
     * Helper trả về mảng các offset (dx, dy) cho 6 hướng dựa trên parity của hàng.
     */
    fun hexNeighborOffsets(row: Int): Array<Pair<Int, Int>> {
        return if (row % 2 == 0) {
            arrayOf(
                Pair(0, -1),   // NE
                Pair(1, 0),    // E
                Pair(0, 1),    // SE
                Pair(-1, 1),   // SW
                Pair(-1, 0),   // W
                Pair(-1, -1)   // NW
            )
        } else {
            arrayOf(
                Pair(1, -1),   // NE (odd row shift right)
                Pair(1, 0),    // E
                Pair(1, 1),    // SE
                Pair(0, 1),    // SW
                Pair(-1, 0),   // W
                Pair(0, -1)    // NW
            )
        }
    }

    fun hexOpposite(directionBit: Int): Int = when (directionBit) {
        HEX_NE -> HEX_SW
        HEX_E  -> HEX_W
        HEX_SE -> HEX_NW
        HEX_SW -> HEX_NE
        HEX_W  -> HEX_E
        HEX_NW -> HEX_SE
        else -> 0
    }

    fun isValidHexCell(col: Int, row: Int, cols: Int, rows: Int): Boolean =
        col in 0 until cols && row in 0 until rows
}
