package com.example.core.engine

import kotlin.random.Random

/**
 * Engine cho chế độ Rush Mode (10 phút thử thách).
 * Người chơi giải nhiều mê cung nhất có thể trong 600 giây,
 * kích thước tăng dần từ 5×5 đến 25×25.
 */

/**
 * Cấu hình tĩnh cho Rush Mode
 */
object RushModeConfig {
    const val TOTAL_TIME_SECONDS = 600 // 10 phút = 600 giây
    const val MIN_SIZE = 5  // Kích thước mê cung nhỏ nhất: 5×5
    const val MAX_SIZE = 25 // Kích thước mê cung lớn nhất: 25×25

    /**
     * Tính kích thước mê cung dựa trên số mê cung đã vượt qua.
     * - Mê cung 1-3: 5×5 (Khởi động)
     * - Mê cung 4-6: 7×7
     * - Mê cung 7-9: 9×9
     * - ...
     * - Mê cung 31+: 25×25 (Cực khó)
     */
    fun mazeSizeForRound(mazesCleared: Int): Int {
        val group = mazesCleared / 3
        val size = MIN_SIZE + group * 2
        return size.coerceAtMost(MAX_SIZE)
    }

    /**
     * Tính điểm thưởng cho mỗi mê cung dựa trên kích thước và thời gian giải.
     */
    fun scoreForMaze(mazeSize: Int, solveTimeSec: Int): Int {
        val baseScore = mazeSize * mazeSize
        val speedBonus = maxOf(0, (mazeSize * 3) - solveTimeSec) * 2
        return baseScore + speedBonus
    }

    /**
     * Tạo LevelDef cho mê cung Rush Mode dùng chung cách sinh và tỉ lệ target của chế độ game thường.
     */
    fun generateRushLevelDef(mazesCleared: Int): LevelDef {
        val size = mazeSizeForRound(mazesCleared)
        val n = size * size
        val levelNumber = (mazesCleared + 1).coerceIn(1, 50)
        val ratio = MazeConfig.difficultyRatio(levelNumber)
        val baseTarget = ((n - 1) * ratio).toInt().coerceIn(1, n - 1)
        val reduction = if (levelNumber < 40) 0.30 else 0.25
        val target = (baseTarget * (1.0 - reduction)).toInt().coerceIn(1, n - 1)
        val algIndex = MazeConfig.algorithmIndexForLevel(levelNumber)

        return LevelDef(
            id = "RUSH_${mazesCleared + 1}",
            numericLevel = mazesCleared + 1,
            tier = "RUSH",
            w = size,
            h = size,
            target = target,
            moveCap = null,
            vision = null,
            isFinal = false,
            noTimer = true,
            isWolfChase = false,
            timeLimitSec = 0,
            algorithmIndex = algIndex
        )
    }
}

/**
 * Bản ghi kết quả của 1 mê cung trong Rush Mode
 */
data class RushMazeRecord(
    val roundNumber: Int,
    val mazeSize: Int,
    val solveTimeSec: Int,
    val score: Int,
    val moves: Int
)

/**
 * Trạng thái phiên chơi Rush Mode
 */
data class RushModeState(
    val isActive: Boolean = false,
    val startTimeMillis: Long = 0L,
    val mazesCleared: Int = 0,
    val totalScore: Int = 0,
    val currentMazeStartTime: Long = 0L,
    val remainingSeconds: Int = RushModeConfig.TOTAL_TIME_SECONDS,
    val mazeHistory: List<RushMazeRecord> = emptyList(),
    val isFinished: Boolean = false
) {
    val elapsedSeconds: Int
        get() = if (startTimeMillis > 0L)
            ((System.currentTimeMillis() - startTimeMillis) / 1000).toInt()
        else 0

    val currentMazeSize: Int
        get() = RushModeConfig.mazeSizeForRound(mazesCleared)

    val isTimeUp: Boolean
        get() = elapsedSeconds >= RushModeConfig.TOTAL_TIME_SECONDS
}

/**
 * Quản lý trạng thái và logic Rush Mode
 */
object RushModeManager {

    fun startNewSession(): RushModeState {
        val now = System.currentTimeMillis()
        return RushModeState(
            isActive = true,
            startTimeMillis = now,
            mazesCleared = 0,
            totalScore = 0,
            currentMazeStartTime = now,
            remainingSeconds = RushModeConfig.TOTAL_TIME_SECONDS,
            mazeHistory = emptyList(),
            isFinished = false
        )
    }

    fun onMazeCleared(
        currentState: RushModeState,
        solveTimeSec: Int,
        moves: Int
    ): RushModeState {
        val mazeSize = currentState.currentMazeSize
        val score = RushModeConfig.scoreForMaze(mazeSize, solveTimeSec)
        val record = RushMazeRecord(
            roundNumber = currentState.mazesCleared + 1,
            mazeSize = mazeSize,
            solveTimeSec = solveTimeSec,
            score = score,
            moves = moves
        )
        val now = System.currentTimeMillis()
        return currentState.copy(
            mazesCleared = currentState.mazesCleared + 1,
            totalScore = currentState.totalScore + score,
            currentMazeStartTime = now,
            mazeHistory = currentState.mazeHistory + record
        )
    }

    fun updateTimer(currentState: RushModeState): RushModeState {
        if (!currentState.isActive || currentState.isFinished) return currentState
        val elapsed = currentState.elapsedSeconds
        val remaining = (RushModeConfig.TOTAL_TIME_SECONDS - elapsed).coerceAtLeast(0)
        val timeUp = remaining <= 0
        return currentState.copy(
            remainingSeconds = remaining,
            isFinished = timeUp,
            isActive = !timeUp
        )
    }

    fun endSession(currentState: RushModeState): RushModeState {
        return currentState.copy(
            isFinished = true,
            isActive = false,
            remainingSeconds = 0
        )
    }

    fun getRank(mazesCleared: Int): RushRank = when {
        mazesCleared >= 21 -> RushRank.MASTER
        mazesCleared >= 16 -> RushRank.DIAMOND
        mazesCleared >= 11 -> RushRank.GOLD
        mazesCleared >= 6 -> RushRank.SILVER
        else -> RushRank.BRONZE
    }
}

enum class RushRank(val emoji: String, val nameVi: String, val nameEn: String) {
    BRONZE("🥉", "Đồng", "Bronze"),
    SILVER("🥈", "Bạc", "Silver"),
    GOLD("🥇", "Vàng", "Gold"),
    DIAMOND("💎", "Kim Cương", "Diamond"),
    MASTER("👑", "Bậc Thầy", "Master")
}
