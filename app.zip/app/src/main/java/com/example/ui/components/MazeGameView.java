package com.example.ui.components;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * MazeGameView - Custom View điều khiển trò chơi Mê Cung bằng Kéo thả 1 nét (One-Line Drag)
 * hoặc Chế độ Vuốt từng bước (1 ô / 1 lần vuốt), chạy trên Canvas và Paint thuần của Android SDK,
 * tối ưu hóa 60/120 FPS.
 *
 * - Không khởi tạo đối tượng trong onDraw().
 * - Hiển thị Đích đến (Goal) là hình Lá cờ màu đỏ (Red Flag) sống động với cột cờ, chân đế và chóp vàng.
 * - Hỗ trợ chế độ Từng Bước (STEP_BY_STEP): Chỉ vuốt di chuyển đúng 1 ô mỗi lần chạm/vuốt.
 * - Hỗ trợ chế độ Tự Động (AUTO): Kéo lướt 1 nét mượt mà liên tục.
 * - Tự động Hoàn tác (Undo) khi kéo ngón tay lùi lại ô trước đó.
 * - ĐÃ TẮT RUNG KHI DI CHUYỂN / VA TƯỜNG (Chỉ rung khi chiến thắng).
 */
public class MazeGameView extends View {

    public static final int NORTH = 1;
    public static final int EAST = 2;
    public static final int SOUTH = 4;
    public static final int WEST = 8;

    public static class MazePoint {
        public int x;
        public int y;

        public MazePoint(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            MazePoint that = (MazePoint) o;
            return x == that.x && y == that.y;
        }

        @Override
        public int hashCode() {
            return 31 * x + y;
        }
    }

    public static class MazeCollectibleItem {
        public int x;
        public int y;
        public String type;

        public MazeCollectibleItem(int x, int y, String type) {
            this.x = x;
            this.y = y;
            this.type = type;
        }
    }

    public interface OnMazeMoveListener {
        void onMove(int dx, int dy, MazePoint newPlayer, int totalMoves);
        void onUndo(MazePoint restoredPlayer);
        void onWallHit();
        void onGameWin(int totalMoves);
    }

    private OnMazeMoveListener moveListener;

    // Maze structure
    private int mazeW = 5;
    private int mazeH = 5;
    private int[] masks = new int[0];
    private MazePoint startPoint = new MazePoint(0, 0);
    private MazePoint goalPoint = new MazePoint(4, 4);
    private MazePoint playerPos = new MazePoint(0, 0);
    private Integer visionWindow = null;

    private final Set<Integer> visitedSet = new HashSet<>();
    private final List<MazePoint> pathHistory = new ArrayList<>();
    private final List<Integer> stepColorParities = new ArrayList<>();
    private int currentMoveParity = 0;
    private boolean hasMovedInCurrentGesture = false;
    private int lastTouchCellX = -1;
    private int lastTouchCellY = -1;
    private static final int MAX_MAZE_TURN_CORNERS = 10;
    private final List<MazePoint> hintPoints = new ArrayList<>();
    private final List<MazeCollectibleItem> collectibleItems = new ArrayList<>();
    @Nullable
    private MazePoint wolfPos = null;
    @Nullable
    private MazePoint wolfCubPos = null;
    private boolean isWolfFrenzy = false;
    private boolean isWolfStunned = false;
    private boolean hasShieldProtection = false;
    private boolean isPlayerFrozen = false;
    private boolean isIceBeamActive = false;
    private String currentSkinId = "classic_blue";

    private boolean isDragging = false;
    private boolean isGameWon = false;
    private boolean isCelebratingWin = false;
    private long winAnimStartTime = 0L;
    private static final long WIN_ANIM_DURATION_MS = 1000L;
    private Paint winBurstPaint;
    private Paint winParticlePaint;
    private boolean isStepByStepMode = false;
    private boolean stepModeHasMoved = false;
    private float touchDownX = 0f;
    private float touchDownY = 0f;
    private long lastStepTime = 0L;
    private long lastAutoStepTime = 0L;

    // Hằng số nhịp độ di chuyển: chế độ từng bước có tốc độ tối đa 0.1 giây / bước (100ms / ô, đi 20 ô mất 2 giây)
    private static final long AUTO_STEP_INTERVAL_MS = 0L;
    private static final long STEP_MODE_COOLDOWN_MS = 100L;
    private float moveSensitivity = 1.0f;

    // Smooth Lerp Interpolation coordinates (Làm mượt chuyển động không bị giật)
    private float animPlayerX = -1f;
    private float animPlayerY = -1f;
    private float animWolfX = -1f;
    private float animWolfY = -1f;
    private float animWolfCubX = -1f;
    private float animWolfCubY = -1f;
    private long lastAnimFrameTime = 0L;
    private static final float LERP_FACTOR_PLAYER = 0.35f; // Tỉ lệ lướt mượt nhân vật
    private static final float LERP_FACTOR_WOLF = 0.22f;   // Tỉ lệ lướt mượt sói chạy đều
    private final List<MazePoint> pendingStepsQueue = new ArrayList<>();
    private final Runnable stepQueueRunnable = new Runnable() {
        @Override
        public void run() {
            processNextPendingStep();
        }
    };

    // Layout measurements
    private float cellSize = 0f;
    private float offX = 0f;
    private float offY = 0f;
    private int viewW = 5;
    private int viewH = 5;
    private int originX = 0;
    private int originY = 0;

    // Pre-allocated Paint and Draw Objects (Studio Lighting Engine)
    private Paint bgPaint;
    private Paint gridFloorPaint;
    private Paint boardAmbientPaint;
    private Paint ambientSpotlightPaint;
    private Paint ambientSpotlightInnerPaint;
    private Paint wallGlowPaint;
    private Paint wallPaint;
    private Paint wallCorePaint;
    private Paint visitedCellPaint;
    private Paint visitedCellBorderPaint;
    private Paint visitedSpecularPaint;
    private Paint startPortalGlowPaint;
    private Paint startPortalPaint;
    private Paint hintPaint;
    private Paint hintCorePaint;

    // Red Flag (Goal) Paints
    private Paint goalGlowOuterPaint;
    private Paint goalGlowPaint;
    private Paint flagPolePaint;
    private Paint flagTopperPaint;
    private Paint flagClothPaint;
    private Paint flagClothShadowPaint;
    private Paint flagBasePaint;
    private Paint flagEmblemPaint;

    // Player & Trail Paints
    private Paint playerGlowPaint;
    private Paint playerBodyPaint;
    private Paint playerHighlightPaint;
    private Paint pathTrailGlowPaint;
    private Paint pathTrailPaint;
    private Paint pathTrailLightPaint;
    private Paint pathTrailCorePaint;

    // Viewport Frame Paint
    private Paint viewportFramePaint;

    // CỘT MỐC ĐÁNH DẤU ĐƯỜNG CỤT / ĐÃ QUA
    public static class MazeMilestone {
        public final int x;
        public final int y;
        public final int order;
        public MazeMilestone(int x, int y, int order) {
            this.x = x;
            this.y = y;
            this.order = order;
        }
    }
    private final List<MazeMilestone> milestones = new ArrayList<>();
    private int nextMilestoneOrder = 1;
    private long lastMilestoneTapTime = 0L;
    private int lastTappedMilestoneX = -1;
    private int lastTappedMilestoneY = -1;

    private Paint milestonePaint;
    private Paint milestoneBorderPaint;
    private Paint milestoneTextPaint;

    // Juice & Dynamic Visuals: Recoil, Particles, Ancient Relic
    public static class SparkParticle {
        public float x, y;
        public float vx, vy;
        public float size;
        public int color;
        public float alpha;
        public SparkParticle(float x, float y, float vx, float vy, float size, int color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.size = size;
            this.color = color;
            this.alpha = 1.0f;
        }
    }
    private final List<SparkParticle> sparkParticles = new ArrayList<>();
    private Paint sparkPaint;
    private Paint fogPaint;
    private Paint relicGlowPaint;
    private Paint relicCorePaint;
    private Paint relicRunePaint;
    private Paint voidAuraPaint;
    private Paint voidParticlePaint;
    private float playerRecoilX = 0f;
    private float playerRecoilY = 0f;

    private final RectF tempRect = new RectF();
    private final Path tempPath = new Path();
    private final Path tempLightPath = new Path();
    private final Path wallPath = new Path();
    private final Path flagPath = new Path();

    public MazeGameView(Context context) {
        super(context);
        init();
    }

    public MazeGameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MazeGameView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.parseColor("#FFFFFF"));
        bgPaint.setStyle(Paint.Style.FILL);

        gridFloorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridFloorPaint.setColor(Color.parseColor("#160F172A"));
        gridFloorPaint.setStyle(Paint.Style.STROKE);
        gridFloorPaint.setStrokeWidth(1.1f);

        boardAmbientPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        boardAmbientPaint.setColor(Color.parseColor("#102563EB"));
        boardAmbientPaint.setStyle(Paint.Style.FILL);

        ambientSpotlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ambientSpotlightPaint.setColor(Color.parseColor("#182563EB"));
        ambientSpotlightPaint.setStyle(Paint.Style.FILL);

        ambientSpotlightInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ambientSpotlightInnerPaint.setColor(Color.parseColor("#242563EB"));
        ambientSpotlightInnerPaint.setStyle(Paint.Style.FILL);

        wallGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        wallGlowPaint.setColor(Color.parseColor("#331E293B"));
        wallGlowPaint.setStyle(Paint.Style.STROKE);
        wallGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        wallGlowPaint.setStrokeJoin(Paint.Join.ROUND);

        wallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        wallPaint.setColor(Color.parseColor("#1E293B"));
        wallPaint.setStyle(Paint.Style.STROKE);
        wallPaint.setStrokeCap(Paint.Cap.ROUND);
        wallPaint.setStrokeJoin(Paint.Join.ROUND);

        wallCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        wallCorePaint.setColor(Color.parseColor("#B3FFFFFF"));
        wallCorePaint.setStyle(Paint.Style.STROKE);
        wallCorePaint.setStrokeCap(Paint.Cap.ROUND);
        wallCorePaint.setStrokeJoin(Paint.Join.ROUND);

        visitedCellPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        visitedCellPaint.setColor(Color.parseColor("#4D14B8A6"));
        visitedCellPaint.setStyle(Paint.Style.FILL);

        visitedCellBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        visitedCellBorderPaint.setColor(Color.parseColor("#752DD4BF"));
        visitedCellBorderPaint.setStyle(Paint.Style.STROKE);
        visitedCellBorderPaint.setStrokeWidth(1.6f);

        visitedSpecularPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        visitedSpecularPaint.setColor(Color.parseColor("#66FFFFFF"));
        visitedSpecularPaint.setStyle(Paint.Style.STROKE);
        visitedSpecularPaint.setStrokeCap(Paint.Cap.ROUND);
        visitedSpecularPaint.setStrokeWidth(1.8f);

        startPortalGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        startPortalGlowPaint.setColor(Color.parseColor("#3838BDF8"));
        startPortalGlowPaint.setStyle(Paint.Style.FILL);

        startPortalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        startPortalPaint.setColor(Color.parseColor("#CC38BDF8"));
        startPortalPaint.setStyle(Paint.Style.STROKE);
        startPortalPaint.setStrokeWidth(2.8f);

        pathTrailGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathTrailGlowPaint.setColor(Color.parseColor("#662DD4BF"));
        pathTrailGlowPaint.setStyle(Paint.Style.STROKE);
        pathTrailGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        pathTrailGlowPaint.setStrokeJoin(Paint.Join.ROUND);

        pathTrailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathTrailPaint.setColor(Color.parseColor("#2DD4BF"));
        pathTrailPaint.setStyle(Paint.Style.STROKE);
        pathTrailPaint.setStrokeCap(Paint.Cap.ROUND);
        pathTrailPaint.setStrokeJoin(Paint.Join.ROUND);

        pathTrailLightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathTrailLightPaint.setColor(Color.parseColor("#99F6E4"));
        pathTrailLightPaint.setStyle(Paint.Style.STROKE);
        pathTrailLightPaint.setStrokeCap(Paint.Cap.ROUND);
        pathTrailLightPaint.setStrokeJoin(Paint.Join.ROUND);

        pathTrailCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathTrailCorePaint.setColor(Color.parseColor("#E6FFFFFF"));
        pathTrailCorePaint.setStyle(Paint.Style.STROKE);
        pathTrailCorePaint.setStrokeCap(Paint.Cap.ROUND);
        pathTrailCorePaint.setStrokeJoin(Paint.Join.ROUND);

        hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hintPaint.setColor(Color.parseColor("#77F59E0B"));
        hintPaint.setStyle(Paint.Style.FILL);

        hintCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hintCorePaint.setColor(Color.parseColor("#FFFDE047"));
        hintCorePaint.setStyle(Paint.Style.FILL);

        // ĐÍCH ĐẾN: LÁ CỜ ĐỎ (RED FLAG)
        goalGlowOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        goalGlowOuterPaint.setColor(Color.parseColor("#2EEF4444"));
        goalGlowOuterPaint.setStyle(Paint.Style.FILL);

        goalGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        goalGlowPaint.setColor(Color.parseColor("#59EF4444")); // Hào quang đỏ rõ ràng
        goalGlowPaint.setStyle(Paint.Style.FILL);

        flagPolePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagPolePaint.setColor(Color.parseColor("#F8FAFC")); // Cột cờ bạc sáng
        flagPolePaint.setStyle(Paint.Style.STROKE);
        flagPolePaint.setStrokeCap(Paint.Cap.ROUND);

        flagTopperPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagTopperPaint.setColor(Color.parseColor("#FBBF24")); // Chóp cột cờ tròn vàng
        flagTopperPaint.setStyle(Paint.Style.FILL);

        flagClothPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagClothPaint.setColor(Color.parseColor("#EF4444")); // Lá cờ màu đỏ tươi rực rỡ
        flagClothPaint.setStyle(Paint.Style.FILL);

        flagClothShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagClothShadowPaint.setColor(Color.parseColor("#FECACA")); // Viền bắt sáng lá cờ
        flagClothShadowPaint.setStyle(Paint.Style.STROKE);
        flagClothShadowPaint.setStrokeWidth(2.0f);

        flagBasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagBasePaint.setColor(Color.parseColor("#CBD5E1")); // Chân đế cột cờ sáng rõ
        flagBasePaint.setStyle(Paint.Style.FILL);

        flagEmblemPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagEmblemPaint.setColor(Color.parseColor("#FEF08A")); // Ngôi sao vàng sáng trên cờ
        flagEmblemPaint.setStyle(Paint.Style.FILL);

        winBurstPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        winBurstPaint.setStyle(Paint.Style.STROKE);
        winBurstPaint.setStrokeCap(Paint.Cap.ROUND);

        winParticlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        winParticlePaint.setStyle(Paint.Style.FILL);

        // NHÂN VẬT
        playerGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerGlowPaint.setColor(Color.parseColor("#4DFBBF24"));
        playerGlowPaint.setStyle(Paint.Style.FILL);

        playerBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerBodyPaint.setColor(Color.parseColor("#F59E0B"));
        playerBodyPaint.setStyle(Paint.Style.FILL);

        playerHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerHighlightPaint.setColor(Color.WHITE);
        playerHighlightPaint.setStyle(Paint.Style.FILL);

        // Khung viền góc nhìn 10x10
        viewportFramePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        viewportFramePaint.setColor(Color.parseColor("#4438BDF8"));
        viewportFramePaint.setStyle(Paint.Style.STROKE);
        viewportFramePaint.setStrokeWidth(2.5f);

        // HẠT TIA LỬA KHI ĐÂM TƯỜNG (SPARKS)
        sparkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        sparkPaint.setStyle(Paint.Style.FILL);

        // SƯƠNG MỜ KHÁM PHÁ (FOG OF WAR)
        fogPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fogPaint.setStyle(Paint.Style.FILL);
        fogPaint.setColor(Color.parseColor("#99060B14"));

        // CỔ VẬT TRÍ TUỆ (ANCIENT ARTIFACT OF WISDOM)
        relicGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        relicGlowPaint.setStyle(Paint.Style.FILL);
        relicGlowPaint.setColor(Color.parseColor("#44FBBF24"));

        relicCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        relicCorePaint.setStyle(Paint.Style.FILL);

        // CỘT MỐC ĐÁNH DẤU ĐƯỜNG CỤT (MILESTONE PILLAR)
        milestonePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        milestonePaint.setStyle(Paint.Style.FILL);
        milestonePaint.setColor(Color.parseColor("#EF4444")); // Cột mốc cản màu đỏ cam nổi bật

        milestoneBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        milestoneBorderPaint.setStyle(Paint.Style.STROKE);
        milestoneBorderPaint.setStrokeWidth(2.5f);
        milestoneBorderPaint.setColor(Color.parseColor("#FDE047")); // Viền vàng neon phát sáng

        milestoneTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        milestoneTextPaint.setStyle(Paint.Style.FILL);
        milestoneTextPaint.setColor(Color.WHITE);
        milestoneTextPaint.setTextAlign(Paint.Align.CENTER);
        milestoneTextPaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        relicCorePaint.setColor(Color.parseColor("#FDE047"));

        relicRunePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        relicRunePaint.setStyle(Paint.Style.STROKE);
        relicRunePaint.setStrokeWidth(2.2f);
        relicRunePaint.setColor(Color.parseColor("#FEF08A"));

        // BÓNG TỐI PHÁ HỦY (CONSUMING DARKNESS VOID)
        voidAuraPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        voidAuraPaint.setStyle(Paint.Style.FILL);
        voidAuraPaint.setColor(Color.parseColor("#AA07050E"));

        voidParticlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        voidParticlePaint.setStyle(Paint.Style.FILL);
        voidParticlePaint.setColor(Color.parseColor("#CC180A2E"));
    }

    private void triggerWallImpact(int dx, int dy) {
        playerRecoilX = -dx * 0.22f;
        playerRecoilY = -dy * 0.22f;
        float pxCenter = offX + (playerPos.x - originX) * cellSize + cellSize / 2f;
        float pyCenter = offY + (viewH - 1 - (playerPos.y - originY)) * cellSize + cellSize / 2f;
        float contactX = pxCenter + dx * (cellSize * 0.44f);
        float contactY = pyCenter - dy * (cellSize * 0.44f);
        java.util.Random rnd = new java.util.Random();
        for (int i = 0; i < 10; i++) {
            float angle = (float) (rnd.nextDouble() * 2 * Math.PI);
            float speed = (0.04f + rnd.nextFloat() * 0.12f) * cellSize;
            float vx = (float) Math.cos(angle) * speed - dx * speed * 0.5f;
            float vy = (float) Math.sin(angle) * speed + dy * speed * 0.5f;
            float pSize = (0.05f + rnd.nextFloat() * 0.08f) * cellSize;
            int pColor = (i % 2 == 0) ? Color.parseColor("#FDE047") : Color.parseColor("#FFFFFF");
            sparkParticles.add(new SparkParticle(contactX, contactY, vx, vy, pSize, pColor));
        }
        postInvalidateOnAnimation();
    }

    public void setOnMazeMoveListener(OnMazeMoveListener listener) {
        this.moveListener = listener;
    }

    public void setStepByStepMode(boolean stepByStep) {
        if (this.isStepByStepMode != stepByStep) {
            removeCallbacks(stepQueueRunnable);
            pendingStepsQueue.clear();
        }
        this.isStepByStepMode = stepByStep;
        this.stepModeHasMoved = false;
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(stepQueueRunnable);
        pendingStepsQueue.clear();
        super.onDetachedFromWindow();
    }

    public void setMoveSensitivity(float sensitivity) {
        this.moveSensitivity = Math.max(0.4f, Math.min(2.5f, sensitivity));
    }

    public void updateColors(int wallColor, int visitedColor, int accentColor) {
        wallPaint.setColor(wallColor);
        wallGlowPaint.setColor(withAlpha(wallColor, 88));
        visitedCellPaint.setColor(visitedColor);
        visitedCellBorderPaint.setColor(withAlpha(accentColor, 135));
        pathTrailGlowPaint.setColor(withAlpha(accentColor, 110));
        pathTrailPaint.setColor(accentColor);
        startPortalGlowPaint.setColor(withAlpha(accentColor, 52));
        startPortalPaint.setColor(withAlpha(accentColor, 200));
        boardAmbientPaint.setColor(withAlpha(wallColor, 22));
        ambientSpotlightPaint.setColor(withAlpha(accentColor, 36));
        ambientSpotlightInnerPaint.setColor(withAlpha(accentColor, 62));
        playerBodyPaint.setColor(accentColor);
        viewportFramePaint.setColor(withAlpha(wallColor, 120));
        invalidate();
    }

    public void updateStudioTheme(int panelColor, int wallColor, int visitedColor, int accentColor) {
        bgPaint.setColor(panelColor);
        int lum = (Color.red(panelColor) * 299 + Color.green(panelColor) * 587 + Color.blue(panelColor) * 114) / 1000;
        if (lum >= 160) {
            gridFloorPaint.setColor(Color.parseColor("#160F172A"));
            flagPolePaint.setColor(Color.parseColor("#334155"));
            flagBasePaint.setColor(Color.parseColor("#64748B"));
        } else {
            gridFloorPaint.setColor(Color.parseColor("#22FFFFFF"));
            flagPolePaint.setColor(Color.parseColor("#F8FAFC"));
            flagBasePaint.setColor(Color.parseColor("#CBD5E1"));
        }
        updateColors(wallColor, visitedColor, accentColor);
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(
                Math.max(0, Math.min(255, alpha)),
                Color.red(color),
                Color.green(color),
                Color.blue(color)
        );
    }

    public void setPlayerSkinId(String skinId) {
        if (skinId != null && !skinId.isEmpty()) {
            this.currentSkinId = skinId;
            invalidate();
        }
    }

    public void setDynamicEntities(
            @Nullable List<MazeCollectibleItem> collectibles,
            @Nullable MazePoint wolf,
            @Nullable MazePoint wolfCub,
            boolean wolfFrenzy,
            boolean wolfStunned,
            boolean shieldActive,
            boolean playerFrozen,
            boolean iceBeamActive
    ) {
        this.collectibleItems.clear();
        if (collectibles != null) {
            this.collectibleItems.addAll(collectibles);
        }
        this.wolfPos = (wolf != null) ? new MazePoint(wolf.x, wolf.y) : null;
        this.wolfCubPos = (wolfCub != null) ? new MazePoint(wolfCub.x, wolfCub.y) : null;
        this.isWolfFrenzy = wolfFrenzy;
        this.isWolfStunned = wolfStunned;
        this.hasShieldProtection = shieldActive;
        this.isPlayerFrozen = playerFrozen;
        this.isIceBeamActive = iceBeamActive;
        invalidate();
    }

    public void setMazeData(
            int w,
            int h,
            int[] masksArray,
            MazePoint start,
            MazePoint goal,
            MazePoint player,
            Set<Integer> visited,
            List<MazePoint> history,
            @Nullable List<MazePoint> hint,
            @Nullable Integer vision
    ) {
        this.mazeW = w;
        this.mazeH = h;
        this.masks = (masksArray != null) ? masksArray : new int[0];
        this.startPoint = new MazePoint(start.x, start.y);
        this.goalPoint = new MazePoint(goal.x, goal.y);
        this.playerPos = new MazePoint(player.x, player.y);
        this.visionWindow = vision;
        boolean atGoal = (player.x == goal.x && player.y == goal.y && visited != null && visited.size() > 1);
        if (atGoal) {
            if (!this.isCelebratingWin && !this.isGameWon) {
                this.isCelebratingWin = true;
                this.winAnimStartTime = System.currentTimeMillis();
                this.isDragging = false;
                postInvalidate();
            }
        } else {
            this.isCelebratingWin = false;
            this.isGameWon = false;
        }

        this.visitedSet.clear();
        if (visited != null) {
            this.visitedSet.addAll(visited);
        } else {
            this.visitedSet.add(player.y * mazeW + player.x);
        }

        this.pathHistory.clear();
        if (history != null && !history.isEmpty()) {
            this.pathHistory.addAll(history);
        } else {
            this.pathHistory.add(new MazePoint(player.x, player.y));
        }
        if (this.pathHistory.size() <= 1) {
            this.stepColorParities.clear();
            this.stepColorParities.add(0);
            this.currentMoveParity = 0;
            this.hasMovedInCurrentGesture = false;
        } else {
            while (this.stepColorParities.size() < this.pathHistory.size()) {
                this.stepColorParities.add(this.currentMoveParity);
            }
            while (this.stepColorParities.size() > this.pathHistory.size()) {
                this.stepColorParities.remove(this.stepColorParities.size() - 1);
            }
        }

        this.hintPoints.clear();
        if (hint != null) {
            this.hintPoints.addAll(hint);
        }

        // Reset các cột mốc khi nạp ván mới
        if (history == null || history.size() <= 1) {
            this.milestones.clear();
            this.nextMilestoneOrder = 1;
        }

        invalidate();
    }

    public boolean undoStep() {
        if (isGameWon || isCelebratingWin || pathHistory.size() <= 1) return false;
        pathHistory.remove(pathHistory.size() - 1);
        if (stepColorParities.size() > 1) {
            stepColorParities.remove(stepColorParities.size() - 1);
        }
        MazePoint prev = pathHistory.get(pathHistory.size() - 1);
        playerPos = new MazePoint(prev.x, prev.y);

        // Rebuild visited set from history
        visitedSet.clear();
        for (MazePoint p : pathHistory) {
            visitedSet.add(p.y * mazeW + p.x);
        }

        if (moveListener != null) {
            moveListener.onUndo(playerPos);
        }
        invalidate();
        return true;
    }

    public void resetLevel() {
        removeCallbacks(stepQueueRunnable);
        pendingStepsQueue.clear();
        if (startPoint == null) return;
        playerPos = new MazePoint(startPoint.x, startPoint.y);
        pathHistory.clear();
        pathHistory.add(new MazePoint(startPoint.x, startPoint.y));
        stepColorParities.clear();
        stepColorParities.add(0);
        currentMoveParity = 0;
        hasMovedInCurrentGesture = false;
        visitedSet.clear();
        visitedSet.add(startPoint.y * mazeW + startPoint.x);
        isGameWon = false;
        isCelebratingWin = false;
        isDragging = false;
        stepModeHasMoved = false;
        if (moveListener != null) {
            moveListener.onUndo(playerPos);
        }
        animPlayerX = startPoint.x;
        animPlayerY = startPoint.y;
        animWolfX = -1f;
        animWolfY = -1f;
        animWolfCubX = -1f;
        animWolfCubY = -1f;
        invalidate();
    }

    public int cellAt(int x, int y) {
        if (x < 0 || x >= mazeW || y < 0 || y >= mazeH) return 0;
        int idx = y * mazeW + x;
        if (idx < 0 || idx >= masks.length) return 0;
        return masks[idx];
    }

    // ==========================================
    // XỬ LÝ SỰ KIỆN KÉO THẢ / VUỐT TỪNG BƯỚC
    // ==========================================
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isGameWon || isCelebratingWin) return super.onTouchEvent(event);

        float touchX = event.getX();
        float touchY = event.getY();

        if (cellSize <= 0f) return super.onTouchEvent(event);

        // Chuyển đổi Pixel sang Grid (col: x, row: y)
        int localCol = (int) Math.floor((touchX - offX) / cellSize);
        int localRow = (int) Math.floor(((offY + viewH * cellSize) - touchY) / cellSize);

        int targetX = originX + localCol;
        int targetY = originY + localRow;

        long now = System.currentTimeMillis();

        float minSwipeDist = Math.max(16f, cellSize * 0.25f);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDownX = touchX;
                touchDownY = touchY;
                stepModeHasMoved = false;
                hasMovedInCurrentGesture = false;
                lastTouchCellX = targetX;
                lastTouchCellY = targetY;
                lastAutoStepTime = now;
                isDragging = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!isDragging) return true;

                float moveDeltaX = touchX - touchDownX;
                float moveDeltaY = touchDownY - touchY; // Positive = UP (North)

                // 1. CHẾ ĐỘ DI CHUYỂN TỪNG BƯỚC (STEP-BY-STEP MODE)
                if (isStepByStepMode) {
                    if (Math.abs(moveDeltaX) >= minSwipeDist || Math.abs(moveDeltaY) >= minSwipeDist) {
                        int dx = 0;
                        int dy = 0;
                        if (Math.abs(moveDeltaX) >= Math.abs(moveDeltaY)) {
                            dx = (moveDeltaX > 0) ? 1 : -1;
                        } else {
                            dy = (moveDeltaY > 0) ? 1 : -1;
                        }
                        if (slideInDirection(dx, dy)) {
                            touchDownX = touchX;
                            touchDownY = touchY;
                            lastTouchCellX = targetX;
                            lastTouchCellY = targetY;
                            stepModeHasMoved = true;
                            invalidate();
                        }
                    }
                    return true;
                }

                // 2. TÍNH NĂNG HOÀN TÁC KHI KÉO VỀ Ô CŨ (GIỚI HẠN TỐI ĐA 10 Ô QUAY LẠI)
                if (isInsideMaze(targetX, targetY)) {
                    int existingHistoryIdx = -1;
                    for (int i = pathHistory.size() - 2; i >= 0; i--) {
                        MazePoint p = pathHistory.get(i);
                        if (p.x == targetX && p.y == targetY) {
                            existingHistoryIdx = i;
                            break;
                        }
                    }
                    if (existingHistoryIdx >= 0) {
                        int stepsToUndo = (pathHistory.size() - 1) - existingHistoryIdx;
                        // Không thể ngắt từ xa quá 10 ô quay lại
                        if (stepsToUndo >= 1 && stepsToUndo <= 10) {
                            pendingStepsQueue.clear();
                            while (pathHistory.size() - 1 > existingHistoryIdx) {
                                undoStep();
                            }
                            lastAutoStepTime = now;
                            invalidate();
                            return true;
                        }
                    }
                }

                // 3. VUỐT ĐỂ TRƯỢT TỰ ĐỘNG THEO HƯỚNG VUỐT (TỐC ĐỘ GIỚI HẠN 0.1S / Ô = 100MS)
                if (Math.abs(moveDeltaX) >= minSwipeDist || Math.abs(moveDeltaY) >= minSwipeDist) {
                    if (now - lastAutoStepTime >= 100L) {
                        int swipeDx = 0;
                        int swipeDy = 0;
                        if (Math.abs(moveDeltaX) >= Math.abs(moveDeltaY)) {
                            swipeDx = (moveDeltaX > 0) ? 1 : -1;
                        } else {
                            swipeDy = (moveDeltaY > 0) ? 1 : -1;
                        }
                        if (slideInDirection(swipeDx, swipeDy)) {
                            touchDownX = touchX;
                            touchDownY = touchY;
                            hasMovedInCurrentGesture = true;
                            lastAutoStepTime = now;
                            invalidate();
                        }
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // Nếu người chơi chạm vào một ô trong khoảng cách dưới 10 ô (Tap to Move)
                if (!hasMovedInCurrentGesture && !stepModeHasMoved) {
                    float totalDeltaX = touchX - touchDownX;
                    float totalDeltaY = touchDownY - touchY;
                    if (Math.abs(totalDeltaX) >= minSwipeDist || Math.abs(totalDeltaY) >= minSwipeDist) {
                        int dx = 0;
                        int dy = 0;
                        if (Math.abs(totalDeltaX) >= Math.abs(totalDeltaY)) {
                            dx = (totalDeltaX > 0) ? 1 : -1;
                        } else {
                            dy = (totalDeltaY > 0) ? 1 : -1;
                        }
                    } else if (isInsideMaze(targetX, targetY)) {
                        // Xử lý chạm vào ô trong mê cung:
                        // 1. Nếu chạm vào ô đã có Cột Mốc:
                        if (hasMilestoneAt(targetX, targetY)) {
                            long tapNow = System.currentTimeMillis();
                            if (lastTappedMilestoneX == targetX && lastTappedMilestoneY == targetY && (tapNow - lastMilestoneTapTime <= 450L)) {
                                // Double Tap: Đập nổ / Xóa bỏ Cột Mốc với hiệu ứng nổ hạt bụi/sao!
                                explodeMilestoneAt(targetX, targetY);
                                lastTappedMilestoneX = -1;
                                lastTappedMilestoneY = -1;
                                lastMilestoneTapTime = 0L;
                            } else {
                                // Tap lần 1 vào cột mốc
                                lastTappedMilestoneX = targetX;
                                lastTappedMilestoneY = targetY;
                                lastMilestoneTapTime = tapNow;
                            }
                        } else if (targetX != playerPos.x || targetY != playerPos.y) {
                            // 2. Nếu ô này đã đi qua hoặc là ngõ cụt và người chơi chạm để cắm Cột Mốc đánh dấu:
                            boolean isVisited = visitedSet.contains(targetY * mazeW + targetX);
                            boolean isDeadEnd = isCellDeadEnd(targetX, targetY);
                            if (isVisited || isDeadEnd) {
                                // Thêm cột mốc đánh số thứ tự tăng dần không giới hạn
                                addMilestoneAt(targetX, targetY);
                            } else {
                                // Cố gắng di chuyển nếu là ô bình thường
                                tryMoveToTappedCell(targetX, targetY);
                            }
                        }
                    }
                }
                if (hasMovedInCurrentGesture) {
                    currentMoveParity = 1 - currentMoveParity;
                    hasMovedInCurrentGesture = false;
                }
                isDragging = false;
                stepModeHasMoved = false;
                return true;
        }

        return super.onTouchEvent(event);
    }

    private boolean slideInDirection(int initialDx, int initialDy) {
        if (initialDx == 0 && initialDy == 0) return false;
        int dx = Integer.compare(initialDx, 0);
        int dy = Integer.compare(initialDy, 0);
        if (dx != 0 && dy != 0) {
            if (Math.abs(initialDx) >= Math.abs(initialDy)) {
                dy = 0;
            } else {
                dx = 0;
            }
        }

        if (moveListener != null) {
            moveListener.onMove(dx, dy, playerPos, 0);
            return true;
        }
        return false;
    }

    /**
     * Di chuyển nhân vật khi chạm vào ô (targetX, targetY):
     * - Tự động nhận diện và di chuyển nếu khoảng cách dưới/bằng 10 ô (đường đi tối đa 10 bước).
     * - Có thể vượt qua tối đa 5 góc cua liên tiếp.
     * - Tốc độ di chuyển chuẩn xác 0.1s / ô (100ms / ô).
     */
    private boolean tryMoveToTappedCell(int targetX, int targetY) {
        if (!isInsideMaze(targetX, targetY)) return false;
        if (targetX == playerPos.x && targetY == playerPos.y) return false;

        // Tìm đường đi trong khoảng cách <= 10 ô và tối đa 5 góc cua
        List<MazePoint> path = findMultiTurnMazePath(targetX, targetY, 5, 10);
        if (path != null && !path.isEmpty() && path.size() <= 10) {
            pendingStepsQueue.clear();
            pendingStepsQueue.addAll(path);
            processNextPendingStep();
            return true;
        }

        // Nếu là ô liền kề trực tiếp (1 ô)
        int dx = targetX - playerPos.x;
        int dy = targetY - playerPos.y;
        if (Math.abs(dx) + Math.abs(dy) == 1) {
            if (slideInDirection(dx, dy)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Thực hiện từng bước đi trong hàng đợi với tốc độ điều tiết 0.1 giây / bước (100ms / ô):
     */
    private void processNextPendingStep() {
        removeCallbacks(stepQueueRunnable);
        if (isGameWon || isCelebratingWin || pendingStepsQueue.isEmpty()) {
            pendingStepsQueue.clear();
            return;
        }
        if (isPlayerFrozen) {
            pendingStepsQueue.clear();
            if (moveListener != null) {
                moveListener.onMove(0, 0, playerPos, Math.max(0, pathHistory.size() - 1));
            }
            return;
        }

        long now = System.currentTimeMillis();
        // Tốc độ điều tiết: chuẩn 0.1 giây / bước (100ms / ô)
        long stepInterval = 100L;

        long elapsed = now - lastStepTime;
        if (elapsed < stepInterval) {
            postDelayed(stepQueueRunnable, stepInterval - elapsed);
            return;
        }

        MazePoint nextStep = pendingStepsQueue.remove(0);
        int dx = nextStep.x - playerPos.x;
        int dy = nextStep.y - playerPos.y;

        if ((Math.abs(dx) + Math.abs(dy) == 1) && tryMoveSingleCell(dx, dy)) {
            lastStepTime = System.currentTimeMillis();
            stepModeHasMoved = true;
            hasMovedInCurrentGesture = true;
            invalidate();

            if (!pendingStepsQueue.isEmpty() && !isGameWon && !isCelebratingWin && !isPlayerFrozen) {
                postDelayed(stepQueueRunnable, stepInterval);
            } else {
                pendingStepsQueue.clear();
                currentMoveParity = 1 - currentMoveParity;
                invalidate();
            }
        } else {
            pendingStepsQueue.clear();
        }
    }

    /**
     * Tìm đường đi ngắn nhất & ít khúc cua nhất từ playerPos đến (targetX, targetY)
     * - Khoảng cách tối đa: maxSteps = 10 ô
     * - Số góc cua tối đa: maxTurns = 5 góc cua
     */
    private List<MazePoint> findMultiTurnMazePath(int targetX, int targetY, int maxTurns, int maxSteps) {
        if (!isInsideMaze(targetX, targetY)) return null;
        if (targetX == playerPos.x && targetY == playerPos.y) return null;

        int manhattanDist = Math.abs(targetX - playerPos.x) + Math.abs(targetY - playerPos.y);
        if (manhattanDist > maxSteps) {
            return null;
        }

        final int[] dxs = {1, -1, 0, 0};
        final int[] dys = {0, 0, 1, -1};
        final int[] dirMasks = {EAST, WEST, NORTH, SOUTH};

        class MazeSearchNode {
            final int x, y, dir, turns, steps;
            final MazeSearchNode parent;
            MazeSearchNode(int x, int y, int dir, int turns, int steps, MazeSearchNode parent) {
                this.x = x;
                this.y = y;
                this.dir = dir;
                this.turns = turns;
                this.steps = steps;
                this.parent = parent;
            }
        }

        List<MazeSearchNode> queue = new ArrayList<>();
        Set<Integer> visitedStates = new HashSet<>();
        queue.add(new MazeSearchNode(playerPos.x, playerPos.y, 4, 0, 0, null));
        visitedStates.add(((playerPos.y * mazeW + playerPos.x) * 5) + 4);

        int head = 0;
        MazeSearchNode bestGoal = null;

        while (head < queue.size() && head < 2000) {
            MazeSearchNode curr = queue.get(head++);
            if (curr.x == targetX && curr.y == targetY) {
                if (curr.steps <= maxSteps && curr.turns <= maxTurns) {
                    if (bestGoal == null || curr.steps < bestGoal.steps || (curr.steps == bestGoal.steps && curr.turns < bestGoal.turns)) {
                        bestGoal = curr;
                    }
                }
                continue;
            }

            if (curr.steps >= maxSteps) continue;

            int mask = cellAt(curr.x, curr.y);
            for (int d = 0; d < 4; d++) {
                if ((mask & dirMasks[d]) == 0) continue;
                int nx = curr.x + dxs[d];
                int ny = curr.y + dys[d];
                if (!isInsideMaze(nx, ny) || hasMilestoneAt(nx, ny)) continue;

                int nextTurns = (curr.dir == 4 || curr.dir == d) ? curr.turns : (curr.turns + 1);
                if (nextTurns > maxTurns) continue;
                int nextSteps = curr.steps + 1;
                if (nextSteps > maxSteps) continue;

                int stateKey = ((ny * mazeW + nx) * 5) + d;
                if (visitedStates.contains(stateKey)) continue;
                visitedStates.add(stateKey);

                queue.add(new MazeSearchNode(nx, ny, d, nextTurns, nextSteps, curr));
            }
        }

        if (bestGoal == null) return null;

        List<MazePoint> steps = new ArrayList<>();
        MazeSearchNode node = bestGoal;
        while (node != null && node.parent != null) {
            steps.add(0, new MazePoint(node.x, node.y));
            node = node.parent;
        }
        return steps;
    }

    private boolean tryMoveSingleCell(int dx, int dy) {
        if (dx == 0 && dy == 0) return false;
        if (isPlayerFrozen) {
            if (moveListener != null) {
                moveListener.onMove(dx, dy, playerPos, Math.max(0, pathHistory.size() - 1));
            }
            return false;
        }
        int nextX = playerPos.x + dx;
        int nextY = playerPos.y + dy;

        if (!isInsideMaze(nextX, nextY)) return false;

        // CỘT MỐC LÀ VẬT CẢN CỨNG: Không thể đi qua ô có cột mốc
        if (hasMilestoneAt(nextX, nextY)) {
            triggerWallImpact(dx, dy);
            if (moveListener != null) {
                moveListener.onWallHit();
            }
            return false;
        }

        int dirMask = 0;
        if (dx == 1 && dy == 0) dirMask = EAST;
        else if (dx == -1 && dy == 0) dirMask = WEST;
        else if (dx == 0 && dy == 1) dirMask = NORTH;
        else if (dx == 0 && dy == -1) dirMask = SOUTH;

        int currentMask = cellAt(playerPos.x, playerPos.y);

        if ((currentMask & dirMask) != 0) {
            if (pathHistory.size() >= 2) {
                MazePoint prev = pathHistory.get(pathHistory.size() - 2);
                if (nextX == prev.x && nextY == prev.y) {
                    pathHistory.remove(pathHistory.size() - 1);
                    if (stepColorParities.size() > 1) {
                        stepColorParities.remove(stepColorParities.size() - 1);
                    }
                    playerPos = new MazePoint(prev.x, prev.y);

                    visitedSet.clear();
                    for (MazePoint p : pathHistory) {
                        visitedSet.add(p.y * mazeW + p.x);
                    }

                    if (moveListener != null) {
                        moveListener.onUndo(playerPos);
                    }
                    return true;
                }
            }

            playerPos = new MazePoint(nextX, nextY);
            pathHistory.add(new MazePoint(nextX, nextY));
            stepColorParities.add(currentMoveParity);
            visitedSet.add(nextY * mazeW + nextX);

            if (moveListener != null) {
                moveListener.onMove(dx, dy, playerPos, pathHistory.size() - 1);
            }

            if (playerPos.x == goalPoint.x && playerPos.y == goalPoint.y) {
                if (!isCelebratingWin && !isGameWon) {
                    isCelebratingWin = true;
                    winAnimStartTime = System.currentTimeMillis();
                    isDragging = false;
                    postInvalidate();
                }
            }
            return true;
        } else {
            triggerWallImpact(dx, dy);
            if (moveListener != null) {
                moveListener.onWallHit();
            }
            return false;
        }
    }

    private boolean isInsideMaze(int x, int y) {
        return x >= 0 && x < mazeW && y >= 0 && y < mazeH;
    }

    public boolean hasMilestoneAt(int x, int y) {
        for (MazeMilestone m : milestones) {
            if (m.x == x && m.y == y) return true;
        }
        return false;
    }

    public boolean isCellDeadEnd(int x, int y) {
        if (!isInsideMaze(x, y)) return false;
        int mask = cellAt(x, y);
        int openCount = 0;
        if ((mask & NORTH) != 0) openCount++;
        if ((mask & SOUTH) != 0) openCount++;
        if ((mask & EAST) != 0) openCount++;
        if ((mask & WEST) != 0) openCount++;
        return openCount <= 1;
    }

    public void addMilestoneAt(int x, int y) {
        if (!isInsideMaze(x, y)) return;
        if (hasMilestoneAt(x, y)) return;
        if (x == playerPos.x && y == playerPos.y) return;
        if (x == goalPoint.x && y == goalPoint.y) return;

        milestones.add(new MazeMilestone(x, y, nextMilestoneOrder++));
        // Hiệu ứng hạt bụi nhẹ khi đặt mốc
        float cx = offX + (x - originX) * cellSize + cellSize / 2f;
        float cy = offY + (viewH - 1 - (y - originY)) * cellSize + cellSize / 2f;
        for (int i = 0; i < 6; i++) {
            float angle = (float) (Math.random() * Math.PI * 2);
            float speed = 2.5f + (float) Math.random() * 3.5f;
            sparkParticles.add(new SparkParticle(
                cx, cy,
                (float) Math.cos(angle) * speed,
                (float) Math.sin(angle) * speed,
                cellSize * 0.08f,
                Color.parseColor("#FDE047")
            ));
        }
        invalidate();
    }

    public void explodeMilestoneAt(int x, int y) {
        for (int i = milestones.size() - 1; i >= 0; i--) {
            MazeMilestone m = milestones.get(i);
            if (m.x == x && m.y == y) {
                milestones.remove(i);
                // Tạo hiệu ứng hạt nổ tung tóe (Particle explosion)
                float cx = offX + (x - originX) * cellSize + cellSize / 2f;
                float cy = offY + (viewH - 1 - (y - originY)) * cellSize + cellSize / 2f;
                for (int p = 0; p < 18; p++) {
                    float angle = (float) (Math.random() * Math.PI * 2);
                    float speed = 4f + (float) Math.random() * 7f;
                    sparkParticles.add(new SparkParticle(
                        cx, cy,
                        (float) Math.cos(angle) * speed,
                        (float) Math.sin(angle) * speed,
                        cellSize * 0.12f,
                        (p % 2 == 0) ? Color.parseColor("#EF4444") : Color.parseColor("#FBBF24")
                    ));
                }
                break;
            }
        }
        invalidate();
    }

    private boolean isPointInViewport(MazePoint p) {
        return p.x >= originX && p.x < originX + viewW && p.y >= originY && p.y < originY + viewH;
    }

    private boolean isConnectedStep(MazePoint a, MazePoint b) {
        int dx = b.x - a.x;
        int dy = b.y - a.y;
        if (Math.abs(dx) + Math.abs(dy) != 1) return false;
        int mask = cellAt(a.x, a.y);
        if (dx == 1) return (mask & EAST) != 0;
        if (dx == -1) return (mask & WEST) != 0;
        if (dy == 1) return (mask & NORTH) != 0;
        if (dy == -1) return (mask & SOUTH) != 0;
        return false;
    }

    // ==========================================
    // HIỂN THỊ ĐỒ HỌA TRÊN CANVAS (ONDRAW) - 60/120 FPS
    // ==========================================
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float canvasW = getWidth();
        float canvasH = getHeight();
        if (canvasW <= 0 || canvasH <= 0 || mazeW <= 0 || mazeH <= 0) return;

        viewW = (visionWindow != null) ? Math.min(visionWindow, mazeW) : mazeW;
        viewH = (visionWindow != null) ? Math.min(visionWindow, mazeH) : mazeH;

        if (visionWindow != null) {
            originX = Math.min(Math.max(0, playerPos.x - viewW / 2), mazeW - viewW);
            originY = Math.min(Math.max(0, playerPos.y - viewH / 2), mazeH - viewH);
        } else {
            originX = 0;
            originY = 0;
        }

        cellSize = Math.min(canvasW / viewW, canvasH / viewH);
        offX = (canvasW - viewW * cellSize) / 2f;
        offY = (canvasH - viewH * cellSize) / 2f;

        float strokeWidth = Math.max(2.6f, cellSize * 0.09f);
        wallPaint.setStrokeWidth(strokeWidth);
        wallGlowPaint.setStrokeWidth(strokeWidth * 2.8f);
        wallCorePaint.setStrokeWidth(Math.max(1.1f, strokeWidth * 0.34f));
        float trailStroke = cellSize * 0.27f;
        pathTrailGlowPaint.setStrokeWidth(cellSize * 0.46f);
        pathTrailPaint.setStrokeWidth(trailStroke);
        pathTrailLightPaint.setStrokeWidth(trailStroke);
        pathTrailCorePaint.setStrokeWidth(Math.max(1.5f, cellSize * 0.095f));
        flagPolePaint.setStrokeWidth(Math.max(2.2f, cellSize * 0.08f));

        // 0. Nền bàn cờ rõ nét & khung viền góc nhìn 10x10
        tempRect.set(offX, offY, offX + viewW * cellSize, offY + viewH * cellSize);
        canvas.drawRoundRect(tempRect, 14f, 14f, bgPaint);
        canvas.drawRoundRect(tempRect, 14f, 14f, viewportFramePaint);

        // Vẽ lưới nền mảnh (Floor Grid) giúp nhìn rõ từng ô trong mê cung
        if (cellSize >= 14f) {
            for (int ly = 0; ly <= viewH; ly++) {
                float yLine = offY + ly * cellSize;
                canvas.drawLine(offX, yLine, offX + viewW * cellSize, yLine, gridFloorPaint);
            }
            for (int lx = 0; lx <= viewW; lx++) {
                float xLine = offX + lx * cellSize;
                canvas.drawLine(xLine, offY, xLine, offY + viewH * cellSize, gridFloorPaint);
            }
        }

        int playerColor = com.example.data.shop.GameItemAssets.INSTANCE.getSkinPrimaryColorArgb(currentSkinId);
        // Đường line đi theo người chơi: 1 màu đồng nhất rõ nét
        pathTrailPaint.setColor(playerColor);
        startPortalPaint.setColor(withAlpha(playerColor, 200));

        // 1.5. Vẽ Cổng Xuất Phát gọn gàng
        if (startPoint.x >= originX && startPoint.x < originX + viewW &&
                startPoint.y >= originY && startPoint.y < originY + viewH) {
            float sxCenter = offX + (startPoint.x - originX) * cellSize + cellSize / 2f;
            float syCenter = offY + (viewH - 1 - (startPoint.y - originY)) * cellSize + cellSize / 2f;
            canvas.drawCircle(sxCenter, syCenter, cellSize * 0.28f, startPortalPaint);
        }

        // 2. Vẽ đường nối 1 màu duy nhất đi theo người chơi
        if (pathHistory.size() > 1) {
            tempPath.reset();
            boolean hasSegment = false;

            for (int i = 1; i < pathHistory.size(); i++) {
                MazePoint prev = pathHistory.get(i - 1);
                MazePoint curr = pathHistory.get(i);

                if (!isConnectedStep(prev, curr)) {
                    continue;
                }

                boolean prevIn = isPointInViewport(prev);
                boolean currIn = isPointInViewport(curr);

                if (!prevIn && !currIn) {
                    continue;
                }

                float prevPx = offX + (prev.x - originX) * cellSize + cellSize / 2f;
                float prevPy = offY + (viewH - 1 - (prev.y - originY)) * cellSize + cellSize / 2f;
                float currPx = offX + (curr.x - originX) * cellSize + cellSize / 2f;
                float currPy = offY + (viewH - 1 - (curr.y - originY)) * cellSize + cellSize / 2f;

                tempPath.moveTo(prevPx, prevPy);
                tempPath.lineTo(currPx, currPy);
                hasSegment = true;
            }

            if (hasSegment) {
                canvas.save();
                canvas.clipRect(offX, offY, offX + viewW * cellSize, offY + viewH * cellSize);
                canvas.drawPath(tempPath, pathTrailPaint);
                canvas.restore();
            }
        }

        // 3. Vẽ gợi ý đường đi
        if (!hintPoints.isEmpty()) {
            for (MazePoint p : hintPoints) {
                if (p.x >= originX && p.x < originX + viewW && p.y >= originY && p.y < originY + viewH) {
                    float hx = offX + (p.x - originX) * cellSize + cellSize / 2f;
                    float hy = offY + (viewH - 1 - (p.y - originY)) * cellSize + cellSize / 2f;
                    canvas.drawCircle(hx, hy, cellSize * 0.18f, hintPaint);
                }
            }
        }

        // 4. Vẽ tường mê cung sắc nét, viền rõ ràng giúp người chơi nhìn rõ từng hướng đi không bị chặn
        wallPath.reset();
        for (int ly = 0; ly < viewH; ly++) {
            for (int lx = 0; lx < viewW; lx++) {
                int gx = originX + lx;
                int gy = originY + ly;
                int mask = cellAt(gx, gy);
                float sx = offX + lx * cellSize;
                float sy = offY + (viewH - 1 - ly) * cellSize;

                // Tường BẮC (NORTH - phía trên trên màn hình)
                if ((mask & NORTH) == 0) {
                    wallPath.moveTo(sx, sy);
                    wallPath.lineTo(sx + cellSize, sy);
                }
                // Tường NAM (SOUTH - phía dưới trên màn hình)
                if ((mask & SOUTH) == 0) {
                    wallPath.moveTo(sx, sy + cellSize);
                    wallPath.lineTo(sx + cellSize, sy + cellSize);
                }
                // Tường TÂY (WEST - bên trái)
                if ((mask & WEST) == 0) {
                    wallPath.moveTo(sx, sy);
                    wallPath.lineTo(sx, sy + cellSize);
                }
                // Tường ĐÔNG (EAST - bên phải)
                if ((mask & EAST) == 0) {
                    wallPath.moveTo(sx + cellSize, sy);
                    wallPath.lineTo(sx + cellSize, sy + cellSize);
                }
            }
        }
        canvas.drawPath(wallPath, wallPaint);
        canvas.drawPath(wallPath, wallCorePaint);

        // 4.5. KHÔNG DÙNG SƯƠNG MỜ (ĐÃ BỎ THEO YÊU CẦU NGƯỜI DÙNG)
        // Bản đồ luôn hiển thị rõ nét toàn bộ đường đi, không che khuất

        // 5. VẼ ĐÍCH ĐẾN: CỔ VẬT TRÍ TUỆ (ANCIENT ARTIFACT OF WISDOM)
        if (goalPoint.x >= originX && goalPoint.x < originX + viewW &&
                goalPoint.y >= originY && goalPoint.y < originY + viewH) {
            float gLeft = offX + (goalPoint.x - originX) * cellSize;
            float gTop = offY + (viewH - 1 - (goalPoint.y - originY)) * cellSize;
            float gxCenter = gLeft + cellSize / 2f;
            float gyCenter = gTop + cellSize / 2f;
            long nowTime = System.currentTimeMillis();

            // Hào quang tỏa sáng nhịp đập vũ trụ (Pulsing Ethereal Halo)
            float pulse = (float) Math.sin(nowTime * 0.005);
            float haloRadius = cellSize * (0.38f + 0.08f * pulse);
            canvas.drawCircle(gxCenter, gyCenter, haloRadius, relicGlowPaint);

            // Vòng tròn thần bí xoay quanh cổ vật (Rotating Astral Rune Ring)
            float runeOrbitR = cellSize * 0.32f;
            float rotAngle = (nowTime % 7200L) * (360f / 3600f);
            canvas.save();
            canvas.rotate(rotAngle, gxCenter, gyCenter);
            tempRect.set(gxCenter - runeOrbitR, gyCenter - runeOrbitR, gxCenter + runeOrbitR, gyCenter + runeOrbitR);
            canvas.drawArc(tempRect, 0f, 65f, false, relicRunePaint);
            canvas.drawArc(tempRect, 90f, 65f, false, relicRunePaint);
            canvas.drawArc(tempRect, 180f, 65f, false, relicRunePaint);
            canvas.drawArc(tempRect, 270f, 65f, false, relicRunePaint);

            // 4 Vệ tinh tinh thể cổ (Orbiting Rune Gems)
            canvas.drawCircle(gxCenter + runeOrbitR, gyCenter, cellSize * 0.045f, relicCorePaint);
            canvas.drawCircle(gxCenter - runeOrbitR, gyCenter, cellSize * 0.045f, relicCorePaint);
            canvas.drawCircle(gxCenter, gyCenter + runeOrbitR, cellSize * 0.045f, relicCorePaint);
            canvas.drawCircle(gxCenter, gyCenter - runeOrbitR, cellSize * 0.045f, relicCorePaint);
            canvas.restore();

            // Trái tim Cổ Vật: Khối Kim Cương Lục Giác Phát Quang Rực Rỡ
            float diamondSize = cellSize * 0.22f;
            tempPath.reset();
            tempPath.moveTo(gxCenter, gyCenter - diamondSize);
            tempPath.lineTo(gxCenter + diamondSize * 0.85f, gyCenter);
            tempPath.lineTo(gxCenter, gyCenter + diamondSize);
            tempPath.lineTo(gxCenter - diamondSize * 0.85f, gyCenter);
            tempPath.close();
            canvas.drawPath(tempPath, relicCorePaint);

            // Lõi lăng kính sáng trắng ở trung tâm
            canvas.drawCircle(gxCenter, gyCenter, cellSize * 0.08f, playerHighlightPaint);
        }

        // 5.5. VẼ CÁC CỘT MỐC ĐÁNH DẤU (MILESTONES ĐƯỢC ĐÁNH SỐ THỨ TỰ & CHẶN ĐƯỜNG)
        if (!milestones.isEmpty()) {
            float pillarRadius = cellSize * 0.32f;
            float textOffset = cellSize * 0.11f;
            milestoneTextPaint.setTextSize(cellSize * 0.32f);

            for (MazeMilestone ms : milestones) {
                if (ms.x >= originX && ms.x < originX + viewW && ms.y >= originY && ms.y < originY + viewH) {
                    float mxCenter = offX + (ms.x - originX) * cellSize + cellSize / 2f;
                    float myCenter = offY + (viewH - 1 - (ms.y - originY)) * cellSize + cellSize / 2f;

                    // Thân cột mốc: Hình vuông bo góc vững chắc (Obstacle Pillar Block)
                    tempRect.set(mxCenter - pillarRadius, myCenter - pillarRadius, mxCenter + pillarRadius, myCenter + pillarRadius);
                    canvas.drawRoundRect(tempRect, cellSize * 0.12f, cellSize * 0.12f, milestonePaint);
                    canvas.drawRoundRect(tempRect, cellSize * 0.12f, cellSize * 0.12f, milestoneBorderPaint);

                    // Số thứ tự cột mốc (1, 2, 3...)
                    canvas.drawText(String.valueOf(ms.order), mxCenter, myCenter + textOffset, milestoneTextPaint);
                }
            }
        }

        // CẬP NHẬT NỘI SUY CHUYỂN ĐỘNG TRƯỢT MƯỢT (SMOOTH GLIDE LERP)
        boolean needsContinuousInvalidate = false;
        long currentTime = System.currentTimeMillis();

        // 1. Nội suy tọa độ Người Chơi (Player Lerp)
        if (animPlayerX < 0f || animPlayerY < 0f) {
            animPlayerX = playerPos.x;
            animPlayerY = playerPos.y;
        } else {
            float diffPx = playerPos.x - animPlayerX;
            float diffPy = playerPos.y - animPlayerY;
            if (Math.abs(diffPx) > 0.005f || Math.abs(diffPy) > 0.005f) {
                animPlayerX += diffPx * LERP_FACTOR_PLAYER;
                animPlayerY += diffPy * LERP_FACTOR_PLAYER;
                needsContinuousInvalidate = true;
            } else {
                animPlayerX = playerPos.x;
                animPlayerY = playerPos.y;
            }
        }

        // 2. Nội suy tọa độ Sói Mẹ (Wolf Lerp)
        if (wolfPos != null) {
            if (animWolfX < 0f || animWolfY < 0f) {
                animWolfX = wolfPos.x;
                animWolfY = wolfPos.y;
            } else {
                float diffWx = wolfPos.x - animWolfX;
                float diffWy = wolfPos.y - animWolfY;
                if (Math.abs(diffWx) > 0.005f || Math.abs(diffWy) > 0.005f) {
                    animWolfX += diffWx * LERP_FACTOR_WOLF;
                    animWolfY += diffWy * LERP_FACTOR_WOLF;
                    needsContinuousInvalidate = true;
                } else {
                    animWolfX = wolfPos.x;
                    animWolfY = wolfPos.y;
                }
            }
        } else {
            animWolfX = -1f;
            animWolfY = -1f;
        }

        // 3. Nội suy tọa độ Sói Con (Wolf Cub Lerp)
        if (wolfCubPos != null) {
            if (animWolfCubX < 0f || animWolfCubY < 0f) {
                animWolfCubX = wolfCubPos.x;
                animWolfCubY = wolfCubPos.y;
            } else {
                float diffCx = wolfCubPos.x - animWolfCubX;
                float diffCy = wolfCubPos.y - animWolfCubY;
                if (Math.abs(diffCx) > 0.005f || Math.abs(diffCy) > 0.005f) {
                    animWolfCubX += diffCx * (LERP_FACTOR_WOLF * 1.3f);
                    animWolfCubY += diffCy * (LERP_FACTOR_WOLF * 1.3f);
                    needsContinuousInvalidate = true;
                } else {
                    animWolfCubX = wolfCubPos.x;
                    animWolfCubY = wolfCubPos.y;
                }
            }
        } else {
            animWolfCubX = -1f;
            animWolfCubY = -1f;
        }

        // 6. Vẽ Nhân vật (Player) với Squash & Stretch, Idle Breathing Pulse và Giật nảy tường (Recoil)
        if (animPlayerX >= originX - 1 && animPlayerX <= originX + viewW &&
                animPlayerY >= originY - 1 && animPlayerY <= originY + viewH) {
            float pxCenter = offX + (animPlayerX - originX) * cellSize + cellSize / 2f;
            float pyCenter = offY + (viewH - 1 - (animPlayerY - originY)) * cellSize + cellSize / 2f;

            // Tính toán hiệu ứng Squash & Stretch theo phương di chuyển và nhịp thở
            float breath = 1.0f + 0.045f * (float) Math.sin(currentTime * 0.005);
            float stretchX = 1.0f;
            float stretchY = 1.0f;
            float movingDeltaX = Math.abs(animPlayerX - playerPos.x);
            float movingDeltaY = Math.abs(animPlayerY - playerPos.y);
            if (movingDeltaX > 0.015f) {
                stretchX = 1.15f;
                stretchY = 0.88f;
            } else if (movingDeltaY > 0.015f) {
                stretchX = 0.88f;
                stretchY = 1.15f;
            }

            canvas.save();
            // Nảy giật lùi khi va vào tường (Wall bump recoil)
            canvas.translate(playerRecoilX * cellSize, -playerRecoilY * cellSize);
            canvas.scale(stretchX * breath, stretchY * breath, pxCenter, pyCenter);

            com.example.data.shop.GameItemAssets.INSTANCE.drawPlayerOnCanvas(
                canvas,
                pxCenter,
                pyCenter,
                cellSize,
                currentSkinId
            );

            if (isPlayerFrozen) {
                com.example.data.shop.GameItemAssets.INSTANCE.drawFrozenEffectOnPlayer(
                    canvas,
                    pxCenter,
                    pyCenter,
                    cellSize
                );
            }
            canvas.restore();

            // Giảm dần lực giật nảy
            if (Math.abs(playerRecoilX) > 0.005f || Math.abs(playerRecoilY) > 0.005f) {
                playerRecoilX *= 0.65f;
                playerRecoilY *= 0.65f;
                needsContinuousInvalidate = true;
            } else {
                playerRecoilX = 0f;
                playerRecoilY = 0f;
            }
            needsContinuousInvalidate = true;
        }

        // 6.2. Cập nhật và vẽ các hạt tia lửa/sao nổ ra khi va vào tường (Wall Spark Explosion Particles)
        if (!sparkParticles.isEmpty()) {
            for (int i = sparkParticles.size() - 1; i >= 0; i--) {
                SparkParticle sp = sparkParticles.get(i);
                sp.x += sp.vx;
                sp.y += sp.vy;
                sp.alpha -= 0.05f;
                if (sp.alpha <= 0f) {
                    sparkParticles.remove(i);
                } else {
                    sparkPaint.setColor(withAlpha(sp.color, (int) (sp.alpha * 255)));
                    canvas.drawCircle(sp.x, sp.y, sp.size * sp.alpha, sparkPaint);
                }
            }
            needsContinuousInvalidate = true;
        }

        // 6.5. Vẽ Tia Băng Xuyên Tường từ Sói tới Người Chơi (nếu vừa ném băng)
        if ((isIceBeamActive || isPlayerFrozen) && wolfPos != null) {
            float wxCenter = offX + (animWolfX - originX) * cellSize + cellSize / 2f;
            float wyCenter = offY + (viewH - 1 - (animWolfY - originY)) * cellSize + cellSize / 2f;
            float pxCenter = offX + (animPlayerX - originX) * cellSize + cellSize / 2f;
            float pyCenter = offY + (viewH - 1 - (animPlayerY - originY)) * cellSize + cellSize / 2f;
            com.example.data.shop.GameItemAssets.INSTANCE.drawIceBeamOnCanvas(
                canvas,
                wxCenter,
                wyCenter,
                pxCenter,
                pyCenter,
                cellSize
            );
        }

        // 7. Vẽ Bóng Tối Phá Hủy / Con Sói Truy Đuổi (Consuming Darkness Void)
        if (wolfPos != null && animWolfX >= originX - 1 && animWolfX <= originX + viewW &&
                animWolfY >= originY - 1 && animWolfY <= originY + viewH) {
            float wxCenter = offX + (animWolfX - originX) * cellSize + cellSize / 2f;
            float wyCenter = offY + (viewH - 1 - (animWolfY - originY)) * cellSize + cellSize / 2f;

            // Xoáy bóng tối hư vô nuốt chửng mê cung (Consuming Shadow Vortex)
            float voidPulse = (float) Math.sin(currentTime * 0.007);
            float voidRadius = cellSize * (0.52f + 0.08f * voidPulse);
            canvas.drawCircle(wxCenter, wyCenter, voidRadius, voidAuraPaint);

            // Các xúc tu bóng tối vươn dài (Dark Void Tendrils)
            float voidAngle = (currentTime % 3600L) * (360f / 1800f);
            canvas.save();
            canvas.rotate(-voidAngle, wxCenter, wyCenter);
            for (int ti = 0; ti < 4; ti++) {
                float tendrilX = wxCenter + (float) Math.cos(ti * Math.PI / 2.0) * cellSize * 0.45f;
                float tendrilY = wyCenter + (float) Math.sin(ti * Math.PI / 2.0) * cellSize * 0.45f;
                canvas.drawCircle(tendrilX, tendrilY, cellSize * 0.12f, voidParticlePaint);
            }
            canvas.restore();

            com.example.data.shop.GameItemAssets.INSTANCE.drawWolfOnCanvas(
                canvas,
                wxCenter,
                wyCenter,
                cellSize,
                isWolfFrenzy,
                isWolfStunned
            );
            needsContinuousInvalidate = true;
        }

        // 7.5. Vẽ Sói Con (Wolf Cub) với tọa độ trượt mượt animWolfCubX, animWolfCubY
        if (wolfCubPos != null && animWolfCubX >= originX - 1 && animWolfCubX <= originX + viewW &&
                animWolfCubY >= originY - 1 && animWolfCubY <= originY + viewH) {
            float cxCenter = offX + (animWolfCubX - originX) * cellSize + cellSize / 2f;
            float cyCenter = offY + (viewH - 1 - (animWolfCubY - originY)) * cellSize + cellSize / 2f;
            com.example.data.shop.GameItemAssets.INSTANCE.drawWolfOnCanvas(
                canvas,
                cxCenter,
                cyCenter,
                cellSize * 0.65f,
                true,
                false
            );
        }

        if (needsContinuousInvalidate && !isGameWon) {
            postInvalidateOnAnimation();
        }

        // 8. Hiệu ứng pháo hoa / tia sáng hoàn thành kéo dài đúng 1 GIÂY (1000ms) khi chạm lá cờ
        if (isCelebratingWin) {
            long elapsed = System.currentTimeMillis() - winAnimStartTime;
            if (elapsed < WIN_ANIM_DURATION_MS) {
                float progress = (float) elapsed / WIN_ANIM_DURATION_MS; // 0.0 -> 1.0 trong 1 giây
                if (goalPoint.x >= originX && goalPoint.x < originX + viewW &&
                    goalPoint.y >= originY && goalPoint.y < originY + viewH) {
                    float gCenterX = offX + (goalPoint.x - originX + 0.5f) * cellSize;
                    float gCenterY = offY + (viewH - 1 - (goalPoint.y - originY) + 0.5f) * cellSize;

                    // 8.1. Hào quang tâm lá cờ nhấp nháy rực sáng suốt 2 giây
                    float pulse = (float) (0.5f + 0.5f * Math.sin(progress * Math.PI * 8.0));
                    int haloAlpha = (int) (150 * (1f - progress * 0.35f));
                    winParticlePaint.setColor(Color.argb(haloAlpha, 254, 240, 138));
                    canvas.drawCircle(gCenterX, gCenterY, cellSize * (0.85f + 0.45f * pulse), winParticlePaint);
                    winParticlePaint.setColor(Color.argb((int) (190 * (1f - progress * 0.25f)), 255, 255, 255));
                    canvas.drawCircle(gCenterX, gCenterY, cellSize * (0.42f + 0.20f * pulse), winParticlePaint);

                    // 8.2. 16 Tia sáng hào quang xoay tròn bắn ra từ lá cờ
                    int rayCount = 16;
                    double rotationOffset = progress * Math.PI * 2.5;
                    for (int i = 0; i < rayCount; i++) {
                        double angle = i * (2.0 * Math.PI / rayCount) + rotationOffset;
                        boolean isMajorRay = (i % 2 == 0);
                        float rayWave = (float) (0.75f + 0.25f * Math.sin(progress * Math.PI * 6.0 + i));
                        float rInner = cellSize * 0.35f;
                        float rOuter = cellSize * (isMajorRay ? 4.2f : 2.8f) * rayWave;
                        float x1 = gCenterX + (float) (rInner * Math.cos(angle));
                        float y1 = gCenterY + (float) (rInner * Math.sin(angle));
                        float x2 = gCenterX + (float) (rOuter * Math.cos(angle));
                        float y2 = gCenterY + (float) (rOuter * Math.sin(angle));

                        winBurstPaint.setStrokeWidth(Math.max(2.5f, cellSize * (isMajorRay ? 0.14f : 0.09f)));
                        int rayAlpha = (int) (235 * (1f - progress * 0.3f));
                        if (isMajorRay) {
                            winBurstPaint.setColor(Color.argb(rayAlpha, 255, 215, 0)); // Gold
                        } else {
                            winBurstPaint.setColor(Color.argb(rayAlpha, 254, 240, 138)); // Warm light yellow
                        }
                        canvas.drawLine(x1, y1, x2, y2, winBurstPaint);
                    }

                    // 8.3. 3 Đợt sóng vòng tròn ánh sáng lan tỏa liên hoàn trong 2 giây
                    for (int wave = 0; wave < 3; wave++) {
                        float waveProgress = (progress * 2.2f + wave * 0.33f) % 1.0f;
                        float waveRadius = cellSize * (0.5f + 4.8f * waveProgress);
                        float waveFade = 1.0f - waveProgress;
                        winBurstPaint.setStrokeWidth(Math.max(2f, cellSize * 0.18f * waveFade));

                        if (wave == 0) {
                            winBurstPaint.setColor(Color.argb((int) (255 * waveFade), 255, 215, 0)); // Vàng kim
                        } else if (wave == 1) {
                            winBurstPaint.setColor(Color.argb((int) (230 * waveFade), 239, 68, 68)); // Đỏ rực
                        } else {
                            winBurstPaint.setColor(Color.argb((int) (230 * waveFade), 56, 189, 248)); // Xanh ngọc ánh sáng
                        }
                        canvas.drawCircle(gCenterX, gCenterY, waveRadius, winBurstPaint);
                    }

                    // 8.4. 20 Hạt pháo hoa ánh sáng bắn tung tóe 2 đợt
                    int particleCount = 20;
                    float burstCycle = (progress * 2.0f) % 1.0f;
                    float particleFade = 1.0f - burstCycle * 0.85f;
                    for (int p = 0; p < particleCount; p++) {
                        double pAngle = p * (2.0 * Math.PI / particleCount) + burstCycle * 0.6;
                        float speedFactor = 0.65f + (p % 4) * 0.25f;
                        float pDist = cellSize * (0.4f + 4.0f * burstCycle * speedFactor);
                        float px = gCenterX + (float) (pDist * Math.cos(pAngle));
                        float py = gCenterY + (float) (pDist * Math.sin(pAngle));
                        float pRadius = Math.max(2.5f, cellSize * (0.13f - 0.06f * burstCycle));

                        int pAlpha = (int) (255 * particleFade);
                        if (p % 3 == 0) {
                            winParticlePaint.setColor(Color.argb(pAlpha, 255, 215, 0));
                        } else if (p % 3 == 1) {
                            winParticlePaint.setColor(Color.argb(pAlpha, 255, 255, 255));
                        } else {
                            winParticlePaint.setColor(Color.argb(pAlpha, 249, 115, 22));
                        }
                        canvas.drawCircle(px, py, pRadius, winParticlePaint);
                    }
                }
                postInvalidateDelayed(16);
            } else {
                isCelebratingWin = false;
                isGameWon = true;
                if (moveListener != null) {
                    moveListener.onGameWin(pathHistory.size() - 1);
                }
            }
        }
    }

    // =========================================================================
    // CẤU TRÚC DỮ LIỆU CƠ SỞ & THUẬT TOÁN TẠO MÊ CUNG THUẦN JAVA THEO CẤP ĐỘ
    // =========================================================================

    public static class Cell {
        public int x, y;
        public boolean topWall = true;
        public boolean rightWall = true;
        public boolean bottomWall = true;
        public boolean leftWall = true;
        public boolean visited = false;

        public Cell(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    public static class Edge {
        public Cell cell1, cell2;
        public Edge(Cell c1, Cell c2) {
            this.cell1 = c1;
            this.cell2 = c2;
        }
    }

    public Cell[][] initGrid(int cols, int rows) {
        Cell[][] grid = new Cell[cols][rows];
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                grid[i][j] = new Cell(i, j);
            }
        }
        return grid;
    }

    public static void removeWalls(Cell current, Cell next) {
        int dx = current.x - next.x;
        if (dx == 1) { current.leftWall = false; next.rightWall = false; }
        else if (dx == -1) { current.rightWall = false; next.leftWall = false; }

        int dy = current.y - next.y;
        if (dy == 1) { current.bottomWall = false; next.topWall = false; }
        else if (dy == -1) { current.topWall = false; next.bottomWall = false; }
    }

    /**
     * 1. Cấp độ nhỏ (5x5 đến 20x20): Thuật toán Quay lui (Backtracking)
     */
    public static void generateBacktracking(Cell[][] grid, int cols, int rows, java.util.Random random) {
        java.util.Stack<Cell> stack = new java.util.Stack<>();
        Cell current = grid[0][0];
        current.visited = true;

        do {
            List<Cell> unvisitedNeighbors = getUnvisitedNeighbors(grid, cols, rows, current);
            if (!unvisitedNeighbors.isEmpty()) {
                Cell next = unvisitedNeighbors.get(random.nextInt(unvisitedNeighbors.size()));
                stack.push(current);
                removeWalls(current, next);
                current = next;
                current.visited = true;
            } else if (!stack.isEmpty()) {
                current = stack.pop();
            }
        } while (!stack.isEmpty());
    }

    private static List<Cell> getUnvisitedNeighbors(Cell[][] grid, int cols, int rows, Cell cell) {
        List<Cell> neighbors = new ArrayList<>();
        int x = cell.x;
        int y = cell.y;
        if (y < rows - 1 && !grid[x][y + 1].visited) neighbors.add(grid[x][y + 1]); // Top (y+1)
        if (x < cols - 1 && !grid[x + 1][y].visited) neighbors.add(grid[x + 1][y]); // Right (x+1)
        if (y > 0 && !grid[x][y - 1].visited) neighbors.add(grid[x][y - 1]); // Bottom (y-1)
        if (x > 0 && !grid[x - 1][y].visited) neighbors.add(grid[x - 1][y]); // Left (x-1)
        return neighbors;
    }

    /**
     * 2. Cấp độ trung bình (21x21 đến 50x50): Thuật toán Kruskal ngẫu nhiên
     */
    public static void generateKruskal(Cell[][] grid, int cols, int rows, java.util.Random random) {
        List<Edge> edges = new ArrayList<>();
        int[] parent = new int[cols * rows];
        for (int i = 0; i < cols * rows; i++) parent[i] = i;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (x < cols - 1) edges.add(new Edge(grid[x][y], grid[x + 1][y]));
                if (y < rows - 1) edges.add(new Edge(grid[x][y], grid[x][y + 1]));
            }
        }

        java.util.Collections.shuffle(edges, random);

        for (Edge edge : edges) {
            int id1 = edge.cell1.x + edge.cell1.y * cols;
            int id2 = edge.cell2.x + edge.cell2.y * cols;
            int root1 = findParent(parent, id1);
            int root2 = findParent(parent, id2);

            if (root1 != root2) {
                removeWalls(edge.cell1, edge.cell2);
                parent[root1] = root2;
            }
        }
    }

    private static int findParent(int[] parent, int i) {
        if (parent[i] == i) return i;
        return parent[i] = findParent(parent, parent[i]);
    }

    /**
     * 3. Cấp độ lớn (Trên 50x50): Thuật toán Wilson (Uniform Spanning Tree)
     */
    public static void generateWilson(Cell[][] grid, int cols, int rows, java.util.Random random) {
        int unvisitedCount = cols * rows;
        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                grid[x][y].visited = false;
            }
        }

        int startX = random.nextInt(cols);
        int startY = random.nextInt(rows);
        grid[startX][startY].visited = true;
        unvisitedCount--;

        int[][] walk = new int[cols][rows];

        while (unvisitedCount > 0) {
            int cx = random.nextInt(cols);
            int cy = random.nextInt(rows);
            while (grid[cx][cy].visited) {
                cx = random.nextInt(cols);
                cy = random.nextInt(rows);
            }

            int wx = cx, wy = cy;
            while (!grid[wx][wy].visited) {
                int dir = random.nextInt(4);
                if (dir == 0 && wy < rows - 1) { walk[wx][wy] = 0; wy++; } // Lên (y+1)
                else if (dir == 1 && wx < cols - 1) { walk[wx][wy] = 1; wx++; } // Phải (x+1)
                else if (dir == 2 && wy > 0) { walk[wx][wy] = 2; wy--; } // Xuống (y-1)
                else if (dir == 3 && wx > 0) { walk[wx][wy] = 3; wx--; } // Trái (x-1)
            }

            wx = cx; wy = cy;
            while (!grid[wx][wy].visited) {
                grid[wx][wy].visited = true;
                unvisitedCount--;

                int dir = walk[wx][wy];
                Cell currentCell = grid[wx][wy];
                Cell nextCell = null;

                if (dir == 0) nextCell = grid[wx][wy + 1];
                else if (dir == 1) nextCell = grid[wx + 1][wy];
                else if (dir == 2) nextCell = grid[wx][wy - 1];
                else if (dir == 3) nextCell = grid[wx - 1][wy];

                if (nextCell != null) {
                    removeWalls(currentCell, nextCell);
                    wx = nextCell.x;
                    wy = nextCell.y;
                }
            }
        }
    }

    /**
     * Thuật toán tìm vị trí Start và End khó nhất theo từng cấp độ hình học (Java)
     */
    public static MazePoint[] determineEndpoints(Cell[][] grid, int cols, int rows, java.util.Random random) {
        int maxDim = Math.max(cols, rows);

        // 1. Cấp độ nhỏ: Start ở Trung tâm, End ở Góc xa nhất
        if (maxDim <= 20) {
            MazePoint start = new MazePoint(cols / 2, rows / 2);
            int[][] dist = bfsDistances(grid, cols, rows, start);

            MazePoint[] corners = new MazePoint[] {
                new MazePoint(0, 0),
                new MazePoint(cols - 1, 0),
                new MazePoint(0, rows - 1),
                new MazePoint(cols - 1, rows - 1)
            };

            MazePoint bestEnd = corners[0];
            int maxDist = dist[corners[0].x][corners[0].y];

            for (MazePoint c : corners) {
                if (dist[c.x][c.y] > maxDist) {
                    maxDist = dist[c.x][c.y];
                    bestEnd = c;
                }
            }
            return new MazePoint[] { start, bestEnd };
        }
        // 2. Cấp độ trung bình: Start ở giữa cạnh Trái, End ở cạnh Phải đối diện
        else if (maxDim <= 50) {
            MazePoint start = new MazePoint(0, rows / 2);
            int[][] dist = bfsDistances(grid, cols, rows, start);

            MazePoint bestEnd = new MazePoint(cols - 1, rows / 2);
            int maxDist = dist[bestEnd.x][bestEnd.y];

            for (int y = 0; y < rows; y++) {
                if (dist[cols - 1][y] > maxDist) {
                    maxDist = dist[cols - 1][y];
                    bestEnd = new MazePoint(cols - 1, y);
                }
            }
            return new MazePoint[] { start, bestEnd };
        }
        // 3. Cấp độ lớn: 2-step BFS tìm khoảng cách xa nhất tuyệt đối (hoặc cặp sát vách)
        else {
            return findFarthestEndpointsDoubleBFS(grid, cols, rows);
        }
    }

    public static int[][] bfsDistances(Cell[][] grid, int cols, int rows, MazePoint start) {
        int[][] dist = new int[cols][rows];
        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                dist[x][y] = -1;
            }
        }

        java.util.Queue<MazePoint> queue = new java.util.LinkedList<>();
        dist[start.x][start.y] = 0;
        queue.add(start);

        while (!queue.isEmpty()) {
            MazePoint curr = queue.poll();
            if (curr == null) break;
            Cell c = grid[curr.x][curr.y];
            int d = dist[curr.x][curr.y];

            // Top (y + 1)
            if (!c.topWall && curr.y < rows - 1 && dist[curr.x][curr.y + 1] == -1) {
                dist[curr.x][curr.y + 1] = d + 1;
                queue.add(new MazePoint(curr.x, curr.y + 1));
            }
            // Right (x + 1)
            if (!c.rightWall && curr.x < cols - 1 && dist[curr.x + 1][curr.y] == -1) {
                dist[curr.x + 1][curr.y] = d + 1;
                queue.add(new MazePoint(curr.x + 1, curr.y));
            }
            // Bottom (y - 1)
            if (!c.bottomWall && curr.y > 0 && dist[curr.x][curr.y - 1] == -1) {
                dist[curr.x][curr.y - 1] = d + 1;
                queue.add(new MazePoint(curr.x, curr.y - 1));
            }
            // Left (x - 1)
            if (!c.leftWall && curr.x > 0 && dist[curr.x - 1][curr.y] == -1) {
                dist[curr.x - 1][curr.y] = d + 1;
                queue.add(new MazePoint(curr.x - 1, curr.y));
            }
        }
        return dist;
    }

    public static MazePoint[] findFarthestEndpointsDoubleBFS(Cell[][] grid, int cols, int rows) {
        // Bước 1: BFS từ [0][0] tìm điểm A xa nhất
        int[][] distA = bfsDistances(grid, cols, rows, new MazePoint(0, 0));
        MazePoint pointA = new MazePoint(0, 0);
        int maxDistA = 0;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (distA[x][y] > maxDistA) {
                    maxDistA = distA[x][y];
                    pointA = new MazePoint(x, y);
                }
            }
        }

        // Bước 2: BFS từ điểm A tìm điểm B xa nhất
        int[][] distB = bfsDistances(grid, cols, rows, pointA);
        MazePoint pointB = pointA;
        int maxDistB = 0;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (distB[x][y] > maxDistB) {
                    maxDistB = distB[x][y];
                    pointB = new MazePoint(x, y);
                }
            }
        }

        return new MazePoint[] { pointA, pointB };
    }
}
