package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MazeAmber,
    onPrimary = Color(0xFF080D1A),
    primaryContainer = Color(0xFF78350F),
    onPrimaryContainer = Color(0xFFFEF3C7),
    secondary = MazePlayer,
    onSecondary = Color(0xFF080D1A),
    secondaryContainer = Color(0xFF0E3A5A),
    onSecondaryContainer = Color(0xFFE0F2FE),
    tertiary = MazeAmberGlow,
    onTertiary = Color(0xFF451A03),
    background = MazeBgDarkBase,
    onBackground = MazeTextH1Base,
    surface = MazeSurface1Base,
    onSurface = MazeTextH1Base,
    surfaceVariant = MazeSurface2Base,
    onSurfaceVariant = MazeTextBodyBase,
    outline = MazeEdgeHighlightBase,
    outlineVariant = MazeEdgeHighlightBrightBase,
    error = MazeDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFD97706),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = Color(0xFFF59E0B),
    onTertiary = Color.White,
    background = MazeBgSoftWhite,
    onBackground = MazeTextSoftDark,
    surface = MazeSurfaceSoftWhite,
    onSurface = MazeTextSoftDark,
    surfaceVariant = MazeSurface2SoftWhite,
    onSurfaceVariant = MazeTextBodySoft,
    outline = MazeEdgeHighlightSoft,
    outlineVariant = Color(0xFF94A3B8),
    error = MazeDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    ThemeState.isDark = darkTheme
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
