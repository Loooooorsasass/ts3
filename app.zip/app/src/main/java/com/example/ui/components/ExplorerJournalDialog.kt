package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.i18n.AppLanguage
import com.example.data.lore.ExplorerJournal
import com.example.data.lore.LoreCard
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted

/**
 * Hộp thoại hiển thị Thẻ Nhật Ký Khám Phá vừa mở khóa (Lore Card Unlock Dialog)
 */
@Composable
fun LoreCardUnlockDialog(
    card: LoreCard,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    val isVi = language == AppLanguage.VI

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(46.dp)
            ) {
                Text(
                    text = if (isVi) "GHI VÀO NHẬT KÝ" else "INSCRIBE IN JOURNAL",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
        },
        containerColor = Color(0xFF0F172A),
        shape = RoundedCornerShape(20.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0xFFFBBF24).copy(alpha = 0.35f), Color.Transparent)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = card.badgeIcon, fontSize = 34.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isVi) "MỞ KHÓA NHẬT KÝ KHÁM PHÁ!" else "LORE UNLOCKED!",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MazeAmber,
                    letterSpacing = 1.sp
                )

                Text(
                    text = if (isVi) card.titleVi else card.titleEn,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeTextH1,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "“${if (isVi) card.quoteVi else card.quoteEn}”",
                            fontSize = 14.sp,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFF8FAFC),
                            textAlign = TextAlign.Center,
                            lineHeight = 21.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "— ${if (isVi) card.authorOrLoreVi else card.authorOrLoreEn} —",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    )
}

/**
 * Màn hình / Hộp thoại xem toàn bộ Thư Viện Nhật Ký Khám Phá (Explorer's Journal)
 */
@Composable
fun ExplorerJournalDialog(
    highestCleared: Int,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    val isVi = language == AppLanguage.VI
    val allCards = ExplorerJournal.CARDS
    val unlockedCount = allCards.count { highestCleared >= it.milestoneLevel }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, MazeEdgeHighlight),
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            tint = MazeAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = if (isVi) "NHẬT KÝ KHÁM PHÁ" else "EXPLORER'S JOURNAL",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MazeTextH1
                            )
                            Text(
                                text = if (isVi) "$unlockedCount / ${allCards.size} Thẻ đã giải mã" else "$unlockedCount / ${allCards.size} Relic cards",
                                fontSize = 11.sp,
                                color = MazeAmber,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = MazeTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(allCards) { card ->
                        val isUnlocked = highestCleared >= card.milestoneLevel
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) Color(0xFF1E293B) else Color(0xFF131D2E)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isUnlocked) Color(0xFF334155) else Color(0xFF1E293B)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(if (isUnlocked) Color(0xFF334155) else Color(0xFF1A2438)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isUnlocked) {
                                        Text(text = card.badgeIcon, fontSize = 22.sp)
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = MazeTextMuted,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isUnlocked) (if (isVi) card.titleVi else card.titleEn) else (if (isVi) "Kỷ vật chưa mở khóa" else "Locked Relic"),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isUnlocked) MazeTextH1 else MazeTextMuted
                                        )
                                        Text(
                                            text = "Lv ${card.milestoneLevel}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (isUnlocked) MazeAmber else MazeTextMuted
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    if (isUnlocked) {
                                        Text(
                                            text = "“${if (isVi) card.quoteVi else card.quoteEn}”",
                                            fontSize = 12.sp,
                                            fontStyle = FontStyle.Italic,
                                            color = Color(0xFFCBD5E1),
                                            lineHeight = 17.sp
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = if (isVi) card.authorOrLoreVi else card.authorOrLoreEn,
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    } else {
                                        Text(
                                            text = if (isVi) "Vượt qua Màn ${card.milestoneLevel} để mở khóa triết lý" else "Clear Level ${card.milestoneLevel} to unlock wisdom",
                                            fontSize = 11.sp,
                                            color = MazeTextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
