package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.data.cloud.DailyChallengeManager
import com.example.data.cloud.LeaderboardEntry
import com.example.data.cloud.LeaderboardManager
import com.example.ui.components.LanguageToggleSwitch
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeCyan
import com.example.ui.theme.MazeDanger
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

@Composable
fun LeaderboardScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Level, 1: Daily
    val selectedLevel = uiState.selectedLeaderboardLevel

    val playerLevelRecord = uiState.levelRecords[selectedLevel.toString()]
    val todayKey = "DAILY_${DailyChallengeManager.getTodayDateKey()}"
    val dailyRecord = uiState.levelRecords[todayKey]

    var entries by remember { mutableStateOf<List<LeaderboardEntry>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }

    var showNicknameModal by remember { mutableStateOf(false) }
    var nicknameInput by remember(uiState.progress.playerName) { mutableStateOf(uiState.progress.playerName) }
    var nicknameError by remember { mutableStateOf<String?>(null) }
    var isCheckingNickname by remember { mutableStateOf(false) }

    LaunchedEffect(selectedTab, selectedLevel, uiState.progress.playerName, playerLevelRecord, dailyRecord) {
        isLoading = true
        entries = if (selectedTab == 0) {
            LeaderboardManager.fetchLevelLeaderboard(
                levelNumber = selectedLevel,
                playerBestTimeSec = playerLevelRecord?.bestTimeSec,
                playerStars = playerLevelRecord?.stars ?: 0,
                currentPlayerName = uiState.progress.playerName
            )
        } else {
            LeaderboardManager.fetchDailyLeaderboard(
                dateKey = DailyChallengeManager.getTodayDateKey(),
                playerScoreSec = dailyRecord?.bestTimeSec,
                currentPlayerName = uiState.progress.playerName
            )
        }
        isLoading = false
    }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // TOP BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.navigateTo(AppScreen.HOME) }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = Strings.back(lang),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = Strings.leaderboardTitle(lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            LanguageToggleSwitch(
                currentLanguage = lang,
                onLanguageSelected = { viewModel.setLanguage(it) },
                isCompact = true
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // PLAYER NICKNAME BANNER & EDIT BUTTON
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .clickable {
                    nicknameInput = uiState.progress.playerName
                    nicknameError = null
                    showNicknameModal = true
                },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MazeSurface2)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MazeAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (lang == AppLanguage.VI) "Nickname Bảng Xếp Hạng" else "Leaderboard Nickname",
                            fontSize = 11.sp,
                            color = MazeTextBody
                        )
                        Text(
                            text = uiState.progress.playerName.ifBlank { if (lang == AppLanguage.VI) "Chưa đặt (Nhấn để đặt tên)" else "Not set (Tap to set name)" },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.progress.playerName.isNotBlank()) MazeAmber else MazeCyan
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Nickname",
                    tint = MazeCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // TAB SELECTOR
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(Strings.tabByLevel(lang), fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(Strings.tabDailyChallenge(lang), fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // LEVEL PICKER (if Tab 0)
        if (selectedTab == 0) {
            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val maxLv = minOf(100, maxOf(10, uiState.progress.highestCleared + 2))
                for (lvl in 1..maxLv) {
                    val isSelected = lvl == selectedLevel
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                            .clickable { viewModel.selectLeaderboardLevel(lvl) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = Strings.levelNum(lang, lvl),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MazeAmber)
            }
        } else {
            // TOP 3 PODIUM
            if (entries.size >= 3) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    PodiumCard(rank = 2, entry = entries[1], color = Color(0xFFC0C0C0))
                    PodiumCard(rank = 1, entry = entries[0], color = Color(0xFFFFD700), isFirst = true)
                    PodiumCard(rank = 3, entry = entries[2], color = Color(0xFFCD7F32))
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // SCROLLABLE LIST OR EMPTY PLACEHOLDER
            if (entries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Leaderboard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = Strings.noLeaderboardData(lang, selectedTab == 0, selectedLevel),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = Strings.beTheFirst(lang),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(entries) { entry ->
                        LeaderboardRowItem(entry = entry)
                    }
                }
            }
        }
    }

    // NICKNAME EDIT MODAL
    if (showNicknameModal) {
        AlertDialog(
            onDismissRequest = {
                if (uiState.progress.playerName.isNotBlank()) showNicknameModal = false
            },
            containerColor = MazeSurface1,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "🎮 Đặt Tên Người Chơi" else "🎮 Set Player Nickname",
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (lang == AppLanguage.VI)
                            "Nhập nickname của bạn để hiển thị trên Bảng Xếp Hạng. Tên không được trùng với người chơi khác."
                        else
                            "Enter your nickname for the Leaderboard. Name must be unique.",
                        color = MazeTextBody,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = nicknameInput,
                        onValueChange = {
                            nicknameInput = it
                            nicknameError = null
                        },
                        singleLine = true,
                        label = { Text(if (lang == AppLanguage.VI) "Nickname" else "Nickname") },
                        isError = nicknameError != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (nicknameError != null) {
                        Text(
                            text = nicknameError ?: "",
                            color = MazeDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = nicknameInput.trim()
                        if (trimmed.length < 2) {
                            nicknameError = if (lang == AppLanguage.VI) "Tên phải từ 2 ký tự trở lên!" else "Must be at least 2 characters!"
                            return@Button
                        }
                        isCheckingNickname = true
                        viewModel.setPlayerNickname(trimmed) { success, errMsg ->
                            isCheckingNickname = false
                            if (success) {
                                showNicknameModal = false
                            } else {
                                nicknameError = errMsg ?: (if (lang == AppLanguage.VI) "Tên này đã có người sử dụng, vui lòng chọn tên khác!" else "Name taken, please choose another!")
                            }
                        }
                    },
                    enabled = !isCheckingNickname && nicknameInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isCheckingNickname) "..." else (if (lang == AppLanguage.VI) "Xác nhận" else "Confirm"),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                if (uiState.progress.playerName.isNotBlank()) {
                    TextButton(onClick = { showNicknameModal = false }) {
                        Text(text = Strings.cancel(lang), color = MazeTextBody)
                    }
                }
            }
        )
    }
}

@Composable
private fun PodiumCard(rank: Int, entry: LeaderboardEntry, color: Color, isFirst: Boolean = false) {
    Card(
        modifier = Modifier
            .width(if (isFirst) 105.dp else 92.dp)
            .clip(RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = if (isFirst) 14.dp else 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(if (isFirst) 46.dp else 38.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f))
                    .border(2.dp, color, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = entry.avatarEmoji,
                    fontSize = if (isFirst) 22.sp else 18.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "#$rank",
                fontWeight = FontWeight.ExtraBold,
                fontSize = if (isFirst) 16.sp else 13.sp,
                color = color
            )
            Text(
                text = entry.playerName,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = entry.scoreText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LeaderboardRowItem(entry: LeaderboardEntry) {
    val isMe = entry.isCurrentPlayer
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (isMe) 1.5.dp else 0.dp,
                color = if (isMe) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isMe) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${entry.rank}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(28.dp)
                )
                Text(
                    text = entry.avatarEmoji,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = entry.playerName,
                        fontWeight = if (isMe) FontWeight.ExtraBold else FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    if (entry.stars > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            repeat(entry.stars) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = MazeStar,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = entry.scoreText,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
