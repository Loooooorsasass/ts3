package com.example.ui.components;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * HexMazeGameView - Custom Android View hiển thị mê cung tổ ong lục giác (Pointy-Top).
 * Hỗ trợ:
 * - Lưới lục giác 6 hướng (HEX_NE=1, HEX_E=2, HEX_SE=4, HEX_SW=8, HEX_W=16, HEX_NW=32)
 * - Chế độ chơi bình thường & chế độ Pacman truy đuổi
 * - Di chuyển từng bước đều, điều khiển bằng vuốt hoặc chạm ô kề bên
 * - Hỗ trợ cả giao diện Sáng (Soft White) và Tối (Dark)
 */
public class HexMazeGameView extends View {

    public static final int HEX_NE = 1;
    public static final int HEX_E  = 2;
    public static final int HEX_SE = 4;
    public static final int HEX_SW = 8;
    public static final int HEX_W  = 16;
    public static final int HEX_NW = 32;

    public static class HexPoint {
        public final int col;
        public final int row;

        public HexPoint(int col, int row) {
            this.col = col;
            this.row = row;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            HexPoint hexPoint = (HexPoint) o;
            return col == hexPoint.col && row == hexPoint.row;
        }

        @Override
        public int hashCode() {
            return 31 * col + row;
        }
    }

    public interface OnHexMoveListener {
        void onMove(int newCol, int newRow, int totalMoves);
        void onWallHit();
        void onGameWin(int totalMoves);
    }

    private OnHexMoveListener listener;

    private int cols = 5;
    private int rows = 5;
    private int[] masks = new int[0];
    private HexPoint start = new HexPoint(0, 0);
    private HexPoint goal = new HexPoint(0, 0);
    private HexPoint player = new HexPoint(0, 0);
    private HexPoint pacman = null;

    private final Set<Integer> visited = new HashSet<>();
    private final List<HexPoint> pathHistory = new ArrayList<>();
    private final List<HexPoint> hintPath = new ArrayList<>();
    private int moves = 0;
    private boolean isGameWon = false;

    // Paints
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cellFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cellVisitedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint playerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pacmanPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float hexRadius = 20f;
    private float hexWidth = 34.6f;
    private float hexHeight = 40f;
    private float offsetX = 0f;
    private float offsetY = 0f;

    private float downTouchX = 0f;
    private float downTouchY = 0f;

    public HexMazeGameView(Context context) {
        super(context);
        init();
    }

    public HexMazeGameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public HexMazeGameView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        bgPaint.setColor(Color.parseColor("#090B16"));

        cellFillPaint.setColor(Color.parseColor("#131020"));
        cellFillPaint.setStyle(Paint.Style.FILL);

        cellVisitedPaint.setColor(Color.parseColor("#1E1A38"));
        cellVisitedPaint.setStyle(Paint.Style.FILL);

        wallPaint.setColor(Color.parseColor("#38BDF8"));
        wallPaint.setStyle(Paint.Style.STROKE);
        wallPaint.setStrokeWidth(4f);
        wallPaint.setStrokeCap(Paint.Cap.ROUND);

        playerPaint.setColor(Color.parseColor("#F4C15D"));
        playerPaint.setStyle(Paint.Style.FILL);

        goalPaint.setColor(Color.parseColor("#FF5B68"));
        goalPaint.setStyle(Paint.Style.FILL);

        pacmanPaint.setColor(Color.parseColor("#EF4444"));
        pacmanPaint.setStyle(Paint.Style.FILL);

        pathPaint.setColor(Color.parseColor("#F4C15D"));
        pathPaint.setStyle(Paint.Style.STROKE);
        pathPaint.setStrokeWidth(6f);
        pathPaint.setStrokeCap(Paint.Cap.ROUND);
        pathPaint.setStrokeJoin(Paint.Join.ROUND);

        hintPaint.setColor(Color.parseColor("#10B981"));
        hintPaint.setStyle(Paint.Style.STROKE);
        hintPaint.setStrokeWidth(4f);
        hintPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setOnHexMoveListener(OnHexMoveListener l) {
        this.listener = l;
    }

    public void updateTheme(boolean isDark, int wallColor, int accentColor, int panelColor) {
        if (isDark) {
            bgPaint.setColor(Color.parseColor("#090B16"));
            cellFillPaint.setColor(Color.parseColor("#131020"));
            cellVisitedPaint.setColor(Color.parseColor("#1F1B33"));
        } else {
            bgPaint.setColor(Color.parseColor("#F6F7FA"));
            cellFillPaint.setColor(Color.parseColor("#FFFFFF"));
            cellVisitedPaint.setColor(Color.parseColor("#EEF2F6"));
        }
        wallPaint.setColor(wallColor != 0 ? wallColor : (isDark ? Color.parseColor("#38BDF8") : Color.parseColor("#1E293B")));
        playerPaint.setColor(accentColor != 0 ? accentColor : Color.parseColor("#F4C15D"));
        pathPaint.setColor(accentColor != 0 ? accentColor : Color.parseColor("#F4C15D"));
        invalidate();
    }

    public void setHexMazeData(
            int cols,
            int rows,
            int[] masks,
            HexPoint start,
            HexPoint goal,
            HexPoint player,
            List<HexPoint> solutionSpine
    ) {
        this.cols = cols;
        this.rows = rows;
        this.masks = masks != null ? masks : new int[0];
        this.start = start != null ? start : new HexPoint(0, 0);
        this.goal = goal != null ? goal : new HexPoint(0, 0);
        this.player = player != null ? player : new HexPoint(start != null ? start.col : 0, start != null ? start.row : 0);
        this.pacman = null;

        this.visited.clear();
        this.visited.add(this.player.row * this.cols + this.player.col);

        this.pathHistory.clear();
        this.pathHistory.add(this.player);

        this.hintPath.clear();
        if (solutionSpine != null) {
            this.hintPath.addAll(solutionSpine);
        }

        this.moves = 0;
        this.isGameWon = false;

        calculateDimensions();
        invalidate();
    }

    public void setPacmanPos(HexPoint pos) {
        this.pacman = pos;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        calculateDimensions();
    }

    private void calculateDimensions() {
        int w = getWidth() - getPaddingLeft() - getPaddingRight();
        int h = getHeight() - getPaddingTop() - getPaddingBottom();
        if (w <= 0 || h <= 0 || cols <= 0 || rows <= 0) return;

        // Cho Pointy-Top Hexagon:
        // Chiều rộng = sqrt(3) * R
        // Chiều cao = 2 * R
        // Chiều rộng tổng: (cols + 0.5) * hexWidth
        // Chiều cao tổng: (rows * 0.75 + 0.25) * hexHeight
        float sqrt3 = (float) Math.sqrt(3);

        float maxRadiusByWidth = w / ((cols + 0.6f) * sqrt3);
        float maxRadiusByHeight = h / (rows * 1.5f + 0.5f);

        hexRadius = Math.max(8f, Math.min(maxRadiusByWidth, maxRadiusByHeight));
        hexWidth = sqrt3 * hexRadius;
        hexHeight = 2f * hexRadius;

        float totalGridW = (cols + 0.5f) * hexWidth;
        float totalGridH = (rows * 0.75f + 0.25f) * hexHeight;

        offsetX = getPaddingLeft() + (w - totalGridW) / 2f;
        offsetY = getPaddingTop() + (h - totalGridH) / 2f;
    }

    private PointF getHexCenter(int col, int row) {
        float cx = offsetX + col * hexWidth + hexWidth / 2f;
        if (row % 2 != 0) {
            cx += hexWidth / 2f;
        }
        float cy = offsetY + row * (hexHeight * 0.75f) + hexHeight / 2f;
        return new PointF(cx, cy);
    }

    private PointF[] getHexVertices(float cx, float cy, float radius) {
        PointF[] vertices = new PointF[6];
        // Pointy-top hex có góc đỉnh tại: 30°, 90°, 150°, 210°, 270°, 330°
        for (int i = 0; i < 6; i++) {
            double angleDeg = 30.0 + 60.0 * i;
            double angleRad = Math.toRadians(angleDeg);
            float vx = (float) (cx + radius * Math.cos(angleRad));
            float vy = (float) (cy + radius * Math.sin(angleRad));
            vertices[i] = new PointF(vx, vy);
        }
        return vertices;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRect(0, 0, getWidth(), getHeight(), bgPaint);

        if (cols <= 0 || rows <= 0 || masks.length < cols * rows) return;

        // 1. Vẽ thân các ô (Fills & Visited)
        Path hexPath = new Path();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                PointF center = getHexCenter(c, r);
                PointF[] verts = getHexVertices(center.x, center.y, hexRadius - 1f);

                hexPath.reset();
                hexPath.moveTo(verts[0].x, verts[0].y);
                for (int i = 1; i < 6; i++) {
                    hexPath.lineTo(verts[i].x, verts[i].y);
                }
                hexPath.close();

                boolean isCellVisited = visited.contains(r * cols + c);
                canvas.drawPath(hexPath, isCellVisited ? cellVisitedPaint : cellFillPaint);
            }
        }

        // 2. Vẽ tường (Walls) cho từng cạnh nếu bit tương ứng KHÔNG mở
        // Với Pointy-Top Hex:
        // Đỉnh v[i] tại góc (30° + 60°*i):
        // v0: (cx + R*cos30, cy - R*sin30) -> Trên-Phải (30°)
        // v1: (cx,           cy - R)       -> Đỉnh Trên cùng (90°)
        // v2: (cx - R*cos30, cy - R*sin30) -> Trên-Trái (150°)
        // v3: (cx - R*cos30, cy + R*sin30) -> Dưới-Trái (210°)
        // v4: (cx,           cy + R)       -> Đáy Dưới cùng (270°)
        // v5: (cx + R*cos30, cy + R*sin30) -> Dưới-Phải (330°)
        //
        // 6 Cạnh nối giữa 2 ô láng giềng tương ứng:
        // Cạnh Đông-Bắc (NE): giữa v1 (Đỉnh trên) và v0 (Góc trên-phải) -> HEX_NE (1)
        // Cạnh Đông (E):     giữa v0 (Góc trên-phải) và v5 (Góc dưới-phải) -> HEX_E (2)
        // Cạnh Đông-Nam (SE): giữa v5 (Góc dưới-phải) và v4 (Đáy dưới) -> HEX_SE (4)
        // Cạnh Tây-Nam (SW):  giữa v4 (Đáy dưới) và v3 (Góc dưới-trái) -> HEX_SW (8)
        // Cạnh Tây (W):       giữa v3 (Góc dưới-trái) và v2 (Góc trên-trái) -> HEX_W (16)
        // Cạnh Tây-Bắc (NW):  giữa v2 (Góc trên-trái) và v1 (Đỉnh trên) -> HEX_NW (32)
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int mask = masks[r * cols + c];
                PointF center = getHexCenter(c, r);
                PointF[] verts = getHexVertices(center.x, center.y, hexRadius);

                // Cạnh Đông-Bắc (v1 -> v0): Nếu đường HEX_NE đóng thì vẽ tường
                if ((mask & HEX_NE) == 0) canvas.drawLine(verts[1].x, verts[1].y, verts[0].x, verts[0].y, wallPaint);
                // Cạnh Đông (v0 -> v5): Nếu đường HEX_E đóng thì vẽ tường
                if ((mask & HEX_E) == 0) canvas.drawLine(verts[0].x, verts[0].y, verts[5].x, verts[5].y, wallPaint);
                // Cạnh Đông-Nam (v5 -> v4): Nếu đường HEX_SE đóng thì vẽ tường
                if ((mask & HEX_SE) == 0) canvas.drawLine(verts[5].x, verts[5].y, verts[4].x, verts[4].y, wallPaint);
                // Cạnh Tây-Nam (v4 -> v3): Nếu đường HEX_SW đóng thì vẽ tường
                if ((mask & HEX_SW) == 0) canvas.drawLine(verts[4].x, verts[4].y, verts[3].x, verts[3].y, wallPaint);
                // Cạnh Tây (v3 -> v2): Nếu đường HEX_W đóng thì vẽ tường
                if ((mask & HEX_W) == 0) canvas.drawLine(verts[3].x, verts[3].y, verts[2].x, verts[2].y, wallPaint);
                // Cạnh Tây-Bắc (v2 -> v1): Nếu đường HEX_NW đóng thì vẽ tường
                if ((mask & HEX_NW) == 0) canvas.drawLine(verts[2].x, verts[2].y, verts[1].x, verts[1].y, wallPaint);
            }
        }

        // 3. Vẽ đường đi đã qua (Trail)
        if (pathHistory.size() > 1) {
            Path trail = new Path();
            PointF first = getHexCenter(pathHistory.get(0).col, pathHistory.get(0).row);
            trail.moveTo(first.x, first.y);
            for (int i = 1; i < pathHistory.size(); i++) {
                PointF p = getHexCenter(pathHistory.get(i).col, pathHistory.get(i).row);
                trail.lineTo(p.x, p.y);
            }
            canvas.drawPath(trail, pathPaint);
        }

        // 4. Vẽ Đích đến (Goal)
        PointF goalCenter = getHexCenter(goal.col, goal.row);
        canvas.drawCircle(goalCenter.x, goalCenter.y, hexRadius * 0.45f, goalPaint);

        // 5. Vẽ Pacman (nếu có)
        if (pacman != null) {
            PointF pacCenter = getHexCenter(pacman.col, pacman.row);
            canvas.drawCircle(pacCenter.x, pacCenter.y, hexRadius * 0.45f, pacmanPaint);
        }

        // 6. Vẽ Người chơi (Player)
        PointF playerCenter = getHexCenter(player.col, player.row);
        canvas.drawCircle(playerCenter.x, playerCenter.y, hexRadius * 0.48f, playerPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isGameWon) return false;

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downTouchX = event.getX();
                downTouchY = event.getY();
                return true;

            case MotionEvent.ACTION_UP:
                float dx = event.getX() - downTouchX;
                float dy = event.getY() - downTouchY;
                float dist = (float) Math.hypot(dx, dy);

                if (dist > 30f) {
                    // Xử lý vuốt theo 6 hướng lục giác
                    double angle = Math.toDegrees(Math.atan2(dy, dx)); // [-180..180]
                    handleSwipeDirection(angle);
                } else {
                    // Xử lý chạm trực tiếp vào ô lân cận
                    handleCellTap(event.getX(), event.getY());
                }
                return true;
        }
        return super.onTouchEvent(event);
    }

    private void handleSwipeDirection(double angle) {
        // Chuẩn hóa góc:
        // E:  [-30, 30]
        // SE: [30, 90]
        // SW: [90, 150]
        // W:  [150, 180] hoặc [-180, -150]
        // NW: [-150, -90]
        // NE: [-90, -30]
        int dir;
        if (angle >= -30 && angle < 30) {
            dir = HEX_E;
        } else if (angle >= 30 && angle < 90) {
            dir = HEX_SE;
        } else if (angle >= 90 && angle < 150) {
            dir = HEX_SW;
        } else if (angle >= -90 && angle < -30) {
            dir = HEX_NE;
        } else if (angle >= -150 && angle < -90) {
            dir = HEX_NW;
        } else {
            dir = HEX_W;
        }

        tryMoveInDirection(dir);
    }

    private void tryMoveInDirection(int dirBit) {
        if (player.col < 0 || player.col >= cols || player.row < 0 || player.row >= rows) return;
        int currentMask = masks[player.row * cols + player.col];

        if ((currentMask & dirBit) == 0) {
            // Có tường cản
            if (listener != null) listener.onWallHit();
            return;
        }

        // Tính tọa độ ô mới
        boolean isOddRow = (player.row % 2 != 0);
        int nextCol = player.col;
        int nextRow = player.row;

        switch (dirBit) {
            case HEX_NE:
                nextRow = player.row - 1;
                nextCol = isOddRow ? player.col + 1 : player.col;
                break;
            case HEX_E:
                nextCol = player.col + 1;
                break;
            case HEX_SE:
                nextRow = player.row + 1;
                nextCol = isOddRow ? player.col + 1 : player.col;
                break;
            case HEX_SW:
                nextRow = player.row + 1;
                nextCol = isOddRow ? player.col : player.col - 1;
                break;
            case HEX_W:
                nextCol = player.col - 1;
                break;
            case HEX_NW:
                nextRow = player.row - 1;
                nextCol = isOddRow ? player.col : player.col - 1;
                break;
        }

        if (inBoundsOfCols(nextCol) && inBoundsOfRows(nextRow)) {
            moveToCell(nextCol, nextRow);
        }
    }

    private boolean inBoundsOfCols(int c) { return c >= 0 && c < cols; }
    private boolean inBoundsOfRows(int r) { return r >= 0 && r < rows; }

    private void handleCellTap(float tx, float ty) {
        // Tìm ô được chạm
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                PointF center = getHexCenter(c, r);
                float d = (float) Math.hypot(tx - center.x, ty - center.y);
                if (d <= hexRadius) {
                    // Kiểm tra xem ô này có kề và có đường nối không
                    checkAndMoveToNeighbor(c, r);
                    return;
                }
            }
        }
    }

    private void checkAndMoveToNeighbor(int tc, int tr) {
        int currentMask = masks[player.row * cols + player.col];
        boolean isOddRow = (player.row % 2 != 0);

        int[][] directions = isOddRow ? new int[][]{
                {player.col + 1, player.row - 1, HEX_NE},
                {player.col + 1, player.row,     HEX_E},
                {player.col + 1, player.row + 1, HEX_SE},
                {player.col,     player.row + 1, HEX_SW},
                {player.col - 1, player.row,     HEX_W},
                {player.col,     player.row - 1, HEX_NW}
        } : new int[][]{
                {player.col,     player.row - 1, HEX_NE},
                {player.col + 1, player.row,     HEX_E},
                {player.col,     player.row + 1, HEX_SE},
                {player.col - 1, player.row + 1, HEX_SW},
                {player.col - 1, player.row,     HEX_W},
                {player.col - 1, player.row - 1, HEX_NW}
        };

        for (int[] d : directions) {
            if (d[0] == tc && d[1] == tr) {
                if ((currentMask & d[2]) != 0) {
                    moveToCell(tc, tr);
                } else {
                    if (listener != null) listener.onWallHit();
                }
                return;
            }
        }
    }

    private void moveToCell(int c, int r) {
        if (c < 0 || c >= cols || r < 0 || r >= rows) return;

        player = new HexPoint(c, r);
        moves++;
        visited.add(r * cols + c);
        pathHistory.add(player);

        invalidate();

        if (listener != null) {
            listener.onMove(c, r, moves);
        }

        if (player.equals(goal)) {
            isGameWon = true;
            if (listener != null) {
                listener.onGameWin(moves);
            }
        }
    }
}
