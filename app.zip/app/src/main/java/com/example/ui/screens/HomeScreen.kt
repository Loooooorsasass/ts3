package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.engine.LevelDef
import com.example.core.engine.MazeConfig
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.ui.components.CloudSyncDialog
import com.example.ui.components.GlowingProgressBar
import com.example.ui.components.LanguageToggleSwitch
import com.example.ui.components.MoveSensitivityDialog
import com.example.ui.components.VisionRangeDialog
import com.example.ui.components.TactileImpossibleTierButton
import com.example.ui.components.WolfEquipmentDialog
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeCyan
import com.example.ui.theme.MazeDanger
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSuccess
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted
import com.example.data.shop.GameEras
import com.example.ui.components.ExplorerJournalDialog
import com.example.ui.components.LoreCardUnlockDialog
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Hexagon
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

/**
 * Premium Studio "Puzzle Library" Home Screen:
 * - 1. Top Bar: Brand, Stats Pill (Stars + Coins), and Settings.
 * - 2. Continue Hero: Highlight current level & one-click play.
 * - 3. Puzzles Grid: Clean, compact puzzle level selector (1 to 100).
 * - 4. Special Modes: Wolf Chase, Daily Challenge, One Line, Impossible.
 * - 5. Bottom Navigation: Shop, Achievements, Leaderboard, Cloud.
 */
@Composable
fun HomeScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val progress = uiState.progress
    val records = uiState.levelRecords
    val saveSlot = uiState.saveSlot
    val lang = uiState.language

    var showHelpDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showSensitivityDialog by remember { mutableStateOf(false) }
    var showVisionDialog by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var resetCheckState by remember { mutableStateOf(false) }
    var selectedLevelDefForDialog by remember { mutableStateOf<LevelDef?>(null) }
    var displayedLevelCount by remember { mutableIntStateOf(24) }
    var showNicknameDialog by remember { mutableStateOf(false) }
    var nicknameInput by remember(progress.playerName) { mutableStateOf(progress.playerName) }
    var nicknameError by remember { mutableStateOf<String?>(null) }
    var isCheckingNickname by remember { mutableStateOf(false) }
    var showCustomMazeDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MazeBgDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // ─────────────────────────────────────────────────────────────
        // 1. TOP BAR: Brand + Stats Pill + Settings
        // ─────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_app_icon_art),
                    contentDescription = "MazeX Icon",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, MazeEdgeHighlight, RoundedCornerShape(10.dp))
                )
                Column {
                    Text(
                        text = "MAZEX",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = MazeTextH1,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (lang == AppLanguage.VI) "Hành trình giải đố" else "Your puzzle journey",
                        fontSize = 11.sp,
                        color = MazeTextMuted
                    )
                }
            }

            // Right Group: Stats Pill & Settings Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Compact Stats Pill (Stars + Coins)
                Surface(
                    onClick = { viewModel.navigateTo(AppScreen.SHOP) },
                    shape = RoundedCornerShape(999.dp),
                    color = MazeSurface1,
                    border = BorderStroke(1.dp, MazeEdgeHighlight)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = MazeStar, modifier = Modifier.size(13.dp))
                            Text(text = "${progress.totalStars}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MazeTextH1)
                        }

                        Box(modifier = Modifier.width(1.dp).height(12.dp).background(MazeEdgeHighlight))

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = MazeAmber, modifier = Modifier.size(13.dp))
                            Text(text = "${progress.coins}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MazeTextH1)
                        }
                    }
                }

                // Settings Button (>= 48dp target)
                Surface(
                    onClick = { showSettingsDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    color = MazeSurface1,
                    border = BorderStroke(1.dp, MazeEdgeHighlight),
                    modifier = Modifier.size(42.dp).testTag("home_settings_btn")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MazeTextH1,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ─────────────────────────────────────────────────────────────
        // 2. HERO CONTINUE CARD (One-click Resume / Play Next Level)
        // ─────────────────────────────────────────────────────────────
        val isDemoActive = !progress.hasPassedDemo && progress.highestCleared == 0
        val currentTargetLevel = when {
            saveSlot != null && saveSlot.defId.toIntOrNull() != null -> saveSlot.defId.toInt()
            else -> minOf(MazeConfig.MAX_LEVEL, progress.highestCleared + 1)
        }
        val currentLevelDef = if (isDemoActive && (saveSlot == null || saveSlot.defId == "DEMO_15x15")) {
            MazeConfig.demoLevelDef()
        } else {
            MazeConfig.generateLevelDef(currentTargetLevel)
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MazeSurface1),
            border = BorderStroke(1.dp, MazeEdgeHighlight),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("continue_hero_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (saveSlot != null) {
                            if (lang == AppLanguage.VI) "TIẾP TỤC VÁN CHƠI" else "CONTINUE GAME"
                        } else {
                            if (lang == AppLanguage.VI) "MÀN TIẾP THEO" else "NEXT PUZZLE"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeAmber,
                        letterSpacing = 0.5.sp
                    )

                    Text(
                        text = "${progress.highestCleared} / ${MazeConfig.MAX_LEVEL} ${if (lang == AppLanguage.VI) "Đã hoàn thành" else "Solved"}",
                        fontSize = 11.sp,
                        color = MazeTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isDemoActive) (if (lang == AppLanguage.VI) "MÀN DEMO 15×15" else "DEMO CHALLENGE") else "LEVEL $currentTargetLevel",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MazeTextH1
                        )
                        Text(
                            text = if (isDemoActive) (if (lang == AppLanguage.VI) "15 × 15 • Vượt qua để mở Màn 1" else "15 × 15 • Clear to unlock Level 1") else "${currentLevelDef.w} × ${currentLevelDef.h} • ${Strings.stepsUnit(lang, currentLevelDef.target)}",
                            fontSize = 12.sp,
                            color = MazeTextBody
                        )
                    }

                    Button(
                        onClick = {
                            if (saveSlot != null) {
                                viewModel.resumeFromSave()
                            } else {
                                viewModel.startLevel(currentLevelDef)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                        modifier = Modifier.height(44.dp).testTag("home_hero_play_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (lang == AppLanguage.VI) "CHƠI NGAY" else "PLAY",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                GlowingProgressBar(
                    progress = (progress.highestCleared.toFloat() / MazeConfig.MAX_LEVEL.toFloat()).coerceIn(0f, 1f),
                    activeColor = MazeAmber,
                    glowColor = MazeAmber,
                    trackColor = MazeSurface2
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ─────────────────────────────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        // 3. WORLD MAP JOURNEY (HÀNH TRÌNH THẾ GIỚI THEO KỶ NGUYÊN)
        // ─────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (lang == AppLanguage.VI) "HÀNH TRÌNH THẾ GIỚI" else "WORLD JOURNEY",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeTextH1,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = if (lang == AppLanguage.VI) "5 Kỷ Nguyên • Mê cung • Boss & Lục Giác" else "5 Eras • Mazes • Bosses & Hexagons",
                    fontSize = 11.sp,
                    color = MazeTextMuted
                )
            }

            // Nút mở Nhật ký Khám phá (Explorer's Journal)
            Button(
                onClick = { viewModel.openExplorerJournal() },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MazeAmber.copy(alpha = 0.15f), contentColor = MazeAmber),
                border = BorderStroke(1.dp, MazeAmber.copy(alpha = 0.4f)),
                modifier = Modifier.height(36.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.AutoStories,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    val unlockedLoreCount = com.example.data.lore.ExplorerJournal.getUnlockedCards(progress.highestCleared).size
                    Text(
                        text = if (lang == AppLanguage.VI) "Nhật Ký ($unlockedLoreCount)" else "Journal ($unlockedLoreCount)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hiển thị danh sách Chapter Kỷ Nguyên
        val eras = GameEras.ERAS
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            for (era in eras) {
                val eraLevels = era.levels.toList()
                val eraHighestCleared = progress.highestCleared
                val isEraUnlocked = eraLevels.first() == 1 || eraHighestCleared >= (eraLevels.first() - 1)
                val eraProgressCount = eraLevels.count { it <= eraHighestCleared }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isEraUnlocked) MazeSurface1 else MazeSurface2.copy(alpha = 0.6f)),
                    border = BorderStroke(1.dp, if (isEraUnlocked) MazeEdgeHighlight else Color.Transparent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = if (lang == AppLanguage.VI) era.nameVi else era.nameEn,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isEraUnlocked) MazeAmber else MazeTextMuted
                                    )
                                    if (!isEraUnlocked) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = MazeTextMuted,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = if (lang == AppLanguage.VI) era.descriptionVi else era.descriptionEn,
                                    fontSize = 10.sp,
                                    color = MazeTextMuted
                                )
                            }
                            Text(
                                text = "$eraProgressCount / ${eraLevels.size}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isEraUnlocked) MazeAmber else MazeTextMuted
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val levelRows = eraLevels.chunked(5)
                        for (row in levelRows) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                for (levelNum in row) {
                                    val isDemoPending = !progress.hasPassedDemo && progress.highestCleared == 0
                                    val isCleared = levelNum <= progress.highestCleared
                                    val isCurrent = !isDemoPending && (levelNum == progress.highestCleared + 1)
                                    val isLocked = isDemoPending || (levelNum > progress.highestCleared + 1)
                                    val isBossStage = levelNum in listOf(6, 16, 26, 36, 50)
                                    val isHexStage = levelNum in listOf(12, 24)

                                    val btnColor = when {
                                        isBossStage && !isLocked -> Color(0xFF7F1D1D)
                                        isHexStage && !isLocked -> Color(0xFF78350F)
                                        isCurrent -> MazeAmber.copy(alpha = 0.2f)
                                        isCleared -> MazeSurface2
                                        else -> Color(0xFF0F172A)
                                    }

                                    val borderColor = when {
                                        isBossStage && !isLocked -> Color(0xFFEF4444)
                                        isHexStage && !isLocked -> Color(0xFFFBBF24)
                                        isCurrent -> MazeAmber
                                        isCleared -> MazeEdgeHighlight
                                        else -> Color.Transparent
                                    }

                                    Surface(
                                        onClick = {
                                            if (isDemoPending) {
                                                viewModel.startLevel(MazeConfig.demoLevelDef())
                                            } else if (isBossStage) {
                                                val wolfLvl = when (levelNum) {
                                                    6 -> 1
                                                    16 -> 3
                                                    26 -> 6
                                                    36 -> 10
                                                    else -> 15
                                                }
                                                viewModel.startWolfChaseLevel(wolfLvl)
                                            } else if (isHexStage) {
                                                viewModel.navigateTo(AppScreen.HEX_PLAYING)
                                            } else if (isCleared || isCurrent) {
                                                val def = MazeConfig.generateLevelDef(levelNum)
                                                if (isCleared) {
                                                    selectedLevelDefForDialog = def
                                                } else {
                                                    viewModel.startLevel(def)
                                                }
                                            }
                                        },
                                        enabled = true,
                                        shape = RoundedCornerShape(10.dp),
                                        color = btnColor,
                                        border = BorderStroke(1.dp, borderColor),
                                        modifier = Modifier.weight(1f).height(50.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize().padding(2.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            if (isLocked) {
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = null,
                                                    tint = MazeTextMuted.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Text(
                                                    text = "$levelNum",
                                                    fontSize = 10.sp,
                                                    color = MazeTextMuted
                                                )
                                            } else {
                                                when {
                                                    isBossStage -> {
                                                        Text(
                                                            text = "BOSS",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color(0xFFFCA5A5)
                                                        )
                                                        Text(
                                                            text = "$levelNum 🐺",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = Color.White
                                                        )
                                                    }
                                                    isHexStage -> {
                                                        Text(
                                                            text = "HEX",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color(0xFFFDE047)
                                                        )
                                                        Text(
                                                            text = "$levelNum ⬡",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = Color.White
                                                        )
                                                    }
                                                    else -> {
                                                        Text(
                                                            text = "$levelNum",
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = if (isCurrent) MazeAmber else MazeTextH1
                                                        )
                                                        if (isCleared) {
                                                            Text(text = "⭐", fontSize = 8.sp)
                                                        } else {
                                                            val def = MazeConfig.generateLevelDef(levelNum)
                                                            Text(
                                                                text = "${def.w}×${def.h}",
                                                                fontSize = 8.sp,
                                                                color = MazeAmber
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ─────────────────────────────────────────────────────────────
        // 4. SIDE ARENAS & FREE CHALLENGES (ĐẤU TRƯỜNG & THỬ THÁCH TỰ DO)
        // ─────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == AppLanguage.VI) "ĐẤU TRƯỜNG & THỬ THÁCH PHỤ" else "SIDE ARENAS & MODES",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MazeTextH1,
                letterSpacing = 0.5.sp
            )
            Text(
                text = if (lang == AppLanguage.VI) "Vuốt ngang ➔" else "Scroll ➔",
                fontSize = 11.sp,
                color = MazeTextMuted
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Thanh cuộn ngang gọn gàng, không chiếm dụng diện tích
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // A. Tự Tạo Mê Cung (Custom Maze Generator)
            item {
                ArenaCard(
                    title = if (lang == AppLanguage.VI) "TỰ TẠO MÊ CUNG" else "CUSTOM MAZE",
                    subtitle = if (lang == AppLanguage.VI) "Tùy biến thuật toán & cỡ" else "Custom algorithm & size",
                    tag = "🛠️ Tự do",
                    color = Color(0xFF6366F1),
                    onClick = { showCustomMazeDialog = true }
                )
            }

            // B. Thử Thách 10 Phút (10-Minute Rush Speedrun)
            item {
                ArenaCard(
                    title = if (lang == AppLanguage.VI) "THỬ THÁCH 10 PHÚT" else "10-MIN RUSH",
                    subtitle = if (lang == AppLanguage.VI) "600s tốc biến leo TOP" else "600s speedrun challenge",
                    tag = "⏱️ Rush",
                    color = Color(0xFFA855F7),
                    onClick = { viewModel.navigateTo(AppScreen.RUSH_MODE) }
                )
            }

            // C. Thử Thách Ngày (Daily Challenge)
            item {
                val dailyDone = progress.dailyAllCompleted || (progress.dailyStage1Time > 0 && progress.dailyStage2Time > 0 && progress.dailyStage3Time > 0)
                ArenaCard(
                    title = if (lang == AppLanguage.VI) "THỬ THÁCH NGÀY" else "DAILY CHALLENGE",
                    subtitle = if (lang == AppLanguage.VI) "3 câu đố mới mỗi ngày" else "3 fresh puzzles daily",
                    tag = if (dailyDone) "✓ Xong" else "${progress.dailyAttemptsUsed}/3 lượt",
                    color = Color(0xFF10B981),
                    onClick = { viewModel.navigateTo(AppScreen.DAILY_CHALLENGE) }
                )
            }

            // D. Mê Cung Khổng Lồ (Impossible Mega Maze)
            item {
                ArenaCard(
                    title = if (lang == AppLanguage.VI) "MÊ CUNG KHỔNG LỒ" else "IMPOSSIBLE MAZE",
                    subtitle = "300×300 → 1000×1000",
                    tag = "Tier ${progress.impossibleCleared + 1}",
                    color = MazeDanger,
                    onClick = {
                        val def = MazeConfig.impossibleDefForTier((progress.impossibleCleared + 1).coerceAtMost(MazeConfig.IMPOSSIBLE_TIER_SIZES.size))
                        viewModel.startLevel(def)
                    }
                )
            }

            // E. Vẽ Một Nét (One Line Mode)
            item {
                ArenaCard(
                    title = if (lang == AppLanguage.VI) "VẼ MỘT NÉT" else "ONE LINE",
                    subtitle = "${ONE_LINE_LEVELS.size} Màn câu đố",
                    tag = "1 Nét",
                    color = MazeCyan,
                    onClick = { viewModel.navigateTo(AppScreen.ONELINE_GAME) }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ─────────────────────────────────────────────────────────────
        // 5. BOTTOM NAVIGATION & SHORTCUTS (Shop, Achievements, Leaderboard, Gear)
        // ─────────────────────────────────────────────────────────────
        Text(
            text = if (lang == AppLanguage.VI) "KHÁM PHÁ THÊM" else "MORE",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MazeTextH1,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MoreShortcutButton(
                label = Strings.tabShop(lang),
                icon = Icons.Default.WorkspacePremium,
                onClick = { viewModel.navigateTo(AppScreen.SHOP) },
                modifier = Modifier.weight(1f)
            )

            MoreShortcutButton(
                label = Strings.tabLeaderboard(lang),
                icon = Icons.Default.Star,
                onClick = { viewModel.navigateTo(AppScreen.LEADERBOARD) },
                modifier = Modifier.weight(1f)
            )

            MoreShortcutButton(
                label = Strings.tabAchievements(lang),
                icon = Icons.Default.MonetizationOn,
                onClick = { viewModel.navigateTo(AppScreen.ACHIEVEMENTS) },
                modifier = Modifier.weight(1f)
            )

            MoreShortcutButton(
                label = if (lang == AppLanguage.VI) "Trang Bị" else "Gear",
                icon = Icons.Default.Speed,
                onClick = { viewModel.openWolfEquipmentDialog() },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // ─────────────────────────────────────────────────────────────
    // DIALOGS & OVERLAYS
    // ─────────────────────────────────────────────────────────────

    // Dialog Tự Tạo Mê Cung Vuông (Custom Square Maze Creator)
    if (showCustomMazeDialog) {
        var customSize by remember { mutableIntStateOf(15) }
        var selectedAlgIndex by remember { mutableIntStateOf(1) } // 1: Backtracking, 2: Kruskal, 3: Wilson

        AlertDialog(
            onDismissRequest = { showCustomMazeDialog = false },
            containerColor = MazeSurface1,
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "🛠️ Tự Tạo Mê Cung" else "🛠️ Custom Maze Generator",
                    color = MazeTextH1,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (lang == AppLanguage.VI) "Chọn thuật toán sinh bản đồ:" else "Choose maze generation algorithm:",
                        color = MazeTextBody,
                        fontSize = 12.sp
                    )

                    // 3 Thuật toán
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            Triple(1, "Quay lui\n(DFS)", "Backtracking\n(DFS)"),
                            Triple(2, "Kruskal\n(Fractal)", "Kruskal\n(Fractal)"),
                            Triple(3, "Wilson\n(Cây đều)", "Wilson\n(Uniform)")
                        ).forEach { (idx, viName, enName) ->
                            val isSel = (selectedAlgIndex == idx)
                            Surface(
                                onClick = { selectedAlgIndex = idx },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MazeAmber else MazeSurface2,
                                border = BorderStroke(1.dp, if (isSel) MazeAmber else MazeEdgeHighlight),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.VI) viName else enName,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) Color.Black else MazeTextBody,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (lang == AppLanguage.VI) "Kích thước: ${customSize}×${customSize}" else "Maze Size: ${customSize}×${customSize}",
                        color = MazeTextH1,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Slider(
                        value = customSize.toFloat(),
                        onValueChange = { customSize = it.toInt() },
                        valueRange = 5f..50f,
                        steps = 44,
                        colors = SliderDefaults.colors(
                            thumbColor = MazeAmber,
                            activeTrackColor = MazeAmber
                        )
                    )

                    Text(
                        text = if (lang == AppLanguage.VI)
                            "• Kích thước tự chọn từ 5×5 đến 50×50.\n• Tự do khám phá mọi thuật toán yêu thích!"
                        else
                            "• Any size from 5×5 to 50×50.\n• Freely explore any algorithm you like!",
                        color = MazeTextMuted,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val n = customSize * customSize
                        val target = ((n - 1) * 0.75).toInt().coerceIn(1, n - 1)
                        val customDef = LevelDef(
                            id = "CUSTOM_${customSize}x${customSize}_${System.currentTimeMillis()}",
                            numericLevel = null,
                            tier = "CUSTOM",
                            w = customSize,
                            h = customSize,
                            target = target,
                            moveCap = null,
                            vision = null,
                            isFinal = false,
                            noTimer = true,
                            isWolfChase = false,
                            timeLimitSec = 0,
                            algorithmIndex = selectedAlgIndex
                        )
                        showCustomMazeDialog = false
                        viewModel.startLevel(customDef)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                ) {
                    Text(if (lang == AppLanguage.VI) "Bắt Đầu Chơi" else "Play Now", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomMazeDialog = false }) {
                    Text(if (lang == AppLanguage.VI) "Hủy" else "Cancel", color = MazeTextMuted)
                }
            }
        )
    }

    // ── Lore Card & Explorer Journal Dialogs ──
    uiState.unlockedLoreCard?.let { card ->
        LoreCardUnlockDialog(
            card = card,
            language = lang,
            onDismiss = { viewModel.dismissLoreCardPopup() }
        )
    }

    if (uiState.showExplorerJournalDialog) {
        ExplorerJournalDialog(
            highestCleared = progress.highestCleared,
            language = lang,
            onDismiss = { viewModel.closeExplorerJournal() }
        )
    }

    // Full In-App Settings Dialog
    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            containerColor = MazeSurface1,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "Cài Đặt Ứng Dụng" else "Settings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MazeTextH1
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Sound & Music Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (lang == AppLanguage.VI) "Âm thanh & Rung" else "Audio & Haptics",
                            color = MazeTextBody,
                            fontSize = 13.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                onClick = { viewModel.toggleSound() },
                                shape = CircleShape,
                                color = if (progress.soundEnabled) MazeAmber.copy(alpha = 0.2f) else MazeSurface2,
                                border = BorderStroke(1.dp, if (progress.soundEnabled) MazeAmber else MazeEdgeHighlight),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (progress.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                        contentDescription = "Sound",
                                        tint = if (progress.soundEnabled) MazeAmber else MazeTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Surface(
                                onClick = { viewModel.toggleMusic() },
                                shape = CircleShape,
                                color = if (progress.musicEnabled) MazeAmber.copy(alpha = 0.2f) else MazeSurface2,
                                border = BorderStroke(1.dp, if (progress.musicEnabled) MazeAmber else MazeEdgeHighlight),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (progress.musicEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                                        contentDescription = "Music",
                                        tint = if (progress.musicEnabled) MazeAmber else MazeTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Surface(
                                onClick = { viewModel.toggleHaptics() },
                                shape = CircleShape,
                                color = if (progress.hapticEnabled) MazeAmber.copy(alpha = 0.2f) else MazeSurface2,
                                border = BorderStroke(1.dp, if (progress.hapticEnabled) MazeAmber else MazeEdgeHighlight),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Vibration,
                                        contentDescription = "Haptics",
                                        tint = if (progress.hapticEnabled) MazeAmber else MazeTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Move Sensitivity Option
                    Surface(
                        onClick = { showSensitivityDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        color = MazeSurface2,
                        border = BorderStroke(1.dp, MazeEdgeHighlight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Strings.sensitivityLabel(lang),
                                fontSize = 13.sp,
                                color = MazeTextH1,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "${(progress.moveSensitivity * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MazeAmber
                            )
                        }
                    }

                    // Language Selection Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = Strings.languageLabel(lang),
                            fontSize = 13.sp,
                            color = MazeTextBody
                        )
                        LanguageToggleSwitch(
                            currentLanguage = lang,
                            onLanguageSelected = { viewModel.setLanguage(it) },
                            isCompact = true
                        )
                    }

                    // Theme Mode Switch (Light / Dark)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == AppLanguage.VI) "Chế độ giao diện (Sáng / Tối)" else "Theme Mode (Light / Dark)",
                                fontSize = 13.sp,
                                color = MazeTextH1,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = if (progress.isDarkMode)
                                    (if (lang == AppLanguage.VI) "Đang dùng: Tối (Đen hiện tại)" else "Mode: Dark (Current)")
                                else
                                    (if (lang == AppLanguage.VI) "Đang dùng: Sáng (Trắng dịu nhẹ)" else "Mode: Light (Soft White)"),
                                fontSize = 11.sp,
                                color = MazeAmber
                            )
                        }
                        Switch(
                            checked = progress.isDarkMode,
                            onCheckedChange = { viewModel.toggleDarkMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = MazeAmber,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = MazeSurface2
                            )
                        )
                    }

                    // Tùy chọn góc nhìn bản đồ (Số ô nhìn thấy / Toàn bản đồ)
                    Surface(
                        onClick = { showVisionDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        color = MazeSurface2,
                        border = BorderStroke(1.dp, MazeEdgeHighlight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (lang == AppLanguage.VI) "Góc nhìn bản đồ (Số ô nhìn thấy)" else "Vision Range",
                                    fontSize = 13.sp,
                                    color = MazeTextH1,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = if (progress.customVisionCells > 0)
                                        (if (lang == AppLanguage.VI) "Đang xem: ${progress.customVisionCells} ô gần nhân vật" else "View: ${progress.customVisionCells} cells")
                                    else if (progress.useTenCellView)
                                        (if (lang == AppLanguage.VI) "Đang xem: 10 ô gần nhân vật" else "View: 10 cells")
                                    else
                                        (if (lang == AppLanguage.VI) "Đang xem: Toàn bản đồ (Mặc định)" else "View: Full Map (Default)"),
                                    fontSize = 11.sp,
                                    color = MazeAmber
                                )
                            }
                            Text(
                                text = if (lang == AppLanguage.VI) "Đổi" else "Edit",
                                fontSize = 13.sp,
                                color = MazeCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Player Nickname
                    Surface(
                        onClick = {
                            nicknameInput = progress.playerName
                            nicknameError = null
                            showNicknameDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = MazeSurface2,
                        border = BorderStroke(1.dp, MazeEdgeHighlight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == AppLanguage.VI) "Tên người chơi (Nickname)" else "Player Nickname",
                                    fontSize = 13.sp,
                                    color = MazeTextH1,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = progress.playerName.ifBlank { if (lang == AppLanguage.VI) "Chưa đặt (Nhấn để đặt)" else "Not set (Tap to set)" },
                                    fontSize = 12.sp,
                                    color = MazeAmber,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = if (lang == AppLanguage.VI) "Đổi" else "Edit",
                                fontSize = 13.sp,
                                color = MazeCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Cloud Sync Trigger
                    Surface(
                        onClick = {
                            showSettingsDialog = false
                            viewModel.openCloudSync()
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = MazeSurface2,
                        border = BorderStroke(1.dp, MazeEdgeHighlight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Strings.cloudSyncTitle(lang),
                                fontSize = 13.sp,
                                color = MazeTextH1
                            )
                            Icon(Icons.Default.CloudSync, contentDescription = null, tint = MazeCyan, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Reset & Account Deletion (Google Play Compliance)
                    Surface(
                        onClick = {
                            showSettingsDialog = false
                            showResetConfirmDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = MazeDanger.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, MazeDanger.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == AppLanguage.VI) "Xóa tài khoản & Dữ liệu" else "Delete Account & Data",
                                fontSize = 13.sp,
                                color = MazeDanger,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "→",
                                fontSize = 14.sp,
                                color = MazeDanger,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (lang == AppLanguage.VI) "Đóng" else "Close", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Player Nickname Dialog
    if (showNicknameDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isCheckingNickname) {
                    showNicknameDialog = false
                    nicknameError = null
                }
            },
            containerColor = MazeSurface1,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "Đặt Tên Người Chơi" else "Set Player Nickname",
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1
                )
            },
            text = {
                Column {
                    Text(
                        text = if (lang == AppLanguage.VI)
                            "Tên hiển thị độc nhất trên Bảng Xếp Hạng. (3 - 16 ký tự, không phân biệt hoa thường)"
                        else
                            "Unique name shown on Global Leaderboards. (3 - 16 chars, case-insensitive)",
                        fontSize = 12.sp,
                        color = MazeTextBody
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = nicknameInput,
                        onValueChange = {
                            nicknameInput = it
                            nicknameError = null
                        },
                        singleLine = true,
                        placeholder = { Text(if (lang == AppLanguage.VI) "Nhập nickname của bạn..." else "Enter your nickname...") },
                        isError = nicknameError != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (nicknameError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = nicknameError.orEmpty(),
                            color = MazeDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = nicknameInput.trim()
                        if (trimmed.length < 3 || trimmed.length > 16) {
                            nicknameError = if (lang == AppLanguage.VI) "Tên phải từ 3 đến 16 ký tự!" else "Name must be 3-16 characters!"
                            return@Button
                        }
                        isCheckingNickname = true
                        nicknameError = null
                        viewModel.setPlayerNickname(trimmed) { success, msg ->
                            isCheckingNickname = false
                            if (success) {
                                showNicknameDialog = false
                            } else {
                                nicknameError = msg
                            }
                        }
                    },
                    enabled = !isCheckingNickname,
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isCheckingNickname) (if (lang == AppLanguage.VI) "Đang lưu..." else "Saving...") else (if (lang == AppLanguage.VI) "Xác nhận" else "Confirm"),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        if (!isCheckingNickname) {
                            showNicknameDialog = false
                            nicknameError = null
                        }
                    }
                ) {
                    Text(if (lang == AppLanguage.VI) "Đóng" else "Cancel", color = MazeTextBody)
                }
            }
        )
    }

    // Reset Progress / Delete Data Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetConfirmDialog = false
                resetCheckState = false
            },
            containerColor = MazeSurface1,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "Xóa Tài Khoản & Dữ Liệu?" else "Delete Account & Data?",
                    fontWeight = FontWeight.Bold,
                    color = MazeDanger
                )
            },
            text = {
                Column {
                    Text(
                        text = if (lang == AppLanguage.VI)
                            "Hành động này sẽ xóa toàn bộ tiến trình, số sao, tiền xu và trang bị của bạn về trạng thái ban đầu. Không thể khôi phục sau khi xóa."
                        else
                            "This will permanently delete all your progress, stars, coins and items. This cannot be undone.",
                        fontSize = 13.sp,
                        color = MazeTextBody
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { resetCheckState = !resetCheckState }
                    ) {
                        Checkbox(
                            checked = resetCheckState,
                            onCheckedChange = { resetCheckState = it }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.VI) "Tôi hiểu và muốn xóa vĩnh viễn" else "I understand and confirm deletion",
                            fontSize = 12.sp,
                            color = MazeTextH1
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetCheckState) {
                            showResetConfirmDialog = false
                            resetCheckState = false
                            viewModel.deleteAccountAndData()
                        }
                    },
                    enabled = resetCheckState,
                    colors = ButtonDefaults.buttonColors(containerColor = MazeDanger),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (lang == AppLanguage.VI) "Xác nhận xóa" else "Confirm Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResetConfirmDialog = false
                    resetCheckState = false
                }) {
                    Text(if (lang == AppLanguage.VI) "Hủy" else "Cancel", color = MazeTextBody)
                }
            }
        )
    }

    // Level Replay / Detail Modal
    selectedLevelDefForDialog?.let { def ->
        val record = records[def.id]
        AlertDialog(
            onDismissRequest = { selectedLevelDefForDialog = null },
            containerColor = MazeSurface1,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = "${Strings.levelNum(lang, def.numericLevel ?: 1)} (${def.w}×${def.h})",
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1
                )
            },
            text = {
                Column {
                    Text(
                        text = if (record != null) {
                            if (lang == AppLanguage.VI)
                                "Kỷ lục: ${record.bestTimeSec}s • ${record.bestMoves} bước"
                            else
                                "Best: ${record.bestTimeSec}s • ${record.bestMoves} moves"
                        } else {
                            if (lang == AppLanguage.VI) "Bạn đã hoàn thành màn chơi này!" else "You have solved this puzzle!"
                        },
                        fontSize = 13.sp,
                        color = MazeTextBody
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedLevelDefForDialog = null
                        viewModel.startLevel(def)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF090B16)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (lang == AppLanguage.VI) "Chơi lại" else "Replay", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedLevelDefForDialog = null }) {
                    Text(if (lang == AppLanguage.VI) "Đóng" else "Close", color = MazeTextBody)
                }
            }
        )
    }

    // Sensitivity Dialog
    if (showSensitivityDialog) {
        MoveSensitivityDialog(
            sensitivity = progress.moveSensitivity,
            onSensitivityChange = { viewModel.setMoveSensitivity(it) },
            onDismiss = { showSensitivityDialog = false },
            lang = lang
        )
    }

    // Vision Range Dialog
    if (showVisionDialog) {
        VisionRangeDialog(
            currentVisionCells = if (progress.customVisionCells > 0) progress.customVisionCells else (if (progress.useTenCellView) 10 else 0),
            onVisionChange = { viewModel.setCustomVisionCells(it) },
            onDismiss = { showVisionDialog = false },
            lang = lang
        )
    }

    // Cloud Sync Dialog
    if (uiState.showCloudSyncDialog) {
        CloudSyncDialog(
            lastSyncTime = progress.lastCloudSyncTime,
            totalStars = progress.totalStars,
            highestCleared = progress.highestCleared,
            language = lang,
            onSyncConfirmed = { viewModel.confirmCloudSync() },
            onDismiss = { viewModel.closeCloudSync() }
        )
    }

    // Wolf Equipment Dialog
    if (uiState.showWolfEquipmentDialog) {
        WolfEquipmentDialog(
            progress = progress,
            language = lang,
            onEquip = { viewModel.equipEquipment(it) },
            onUnlock = { viewModel.buyEquipment(it) },
            onBuyShield = { viewModel.buyShieldPack() },
            onDismiss = { viewModel.closeWolfEquipmentDialog() }
        )
    }
}

@Composable
private fun SpecialModeItem(
    title: String,
    subtitle: String,
    tag: String,
    isUnlocked: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = isUnlocked,
        shape = RoundedCornerShape(14.dp),
        color = if (isUnlocked) MazeSurface1 else MazeSurface2,
        border = BorderStroke(1.dp, if (isUnlocked) MazeEdgeHighlight else Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUnlocked) MazeTextH1 else MazeTextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MazeTextBody
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isUnlocked) accentColor.copy(alpha = 0.15f) else MazeSurface2,
                border = BorderStroke(1.dp, if (isUnlocked) accentColor.copy(alpha = 0.5f) else MazeEdgeHighlight)
            ) {
                Text(
                    text = tag,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUnlocked) accentColor else MazeTextMuted,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MoreShortcutButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MazeSurface1,
        border = BorderStroke(1.dp, MazeEdgeHighlight),
        modifier = modifier.height(60.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MazeAmber,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MazeTextH1,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ArenaCard(
    title: String,
    subtitle: String,
    tag: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MazeSurface1),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        modifier = Modifier.width(160.dp).height(80.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tag,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
            Column {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeTextH1,
                    maxLines = 1
                )
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    color = MazeTextMuted,
                    maxLines = 1
                )
            }
        }
    }
}
