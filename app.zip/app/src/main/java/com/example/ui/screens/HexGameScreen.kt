package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.engine.HexAlgorithm
import com.example.core.engine.HexMaze
import com.example.core.engine.HexMazeConfig
import com.example.core.engine.HexMazeEngine
import com.example.core.i18n.AppLanguage
import com.example.ui.components.HexMazeGameView
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel
import kotlinx.coroutines.delay

/**
 * Màn hình chơi Mê Cung Tổ Ong Lục Giác (Hexagonal Maze):
 * - Hỗ trợ 3 chế độ: Màn Thường (1..50), Pacman Đuổi (1..20), Tự Tạo Mê Cung (Custom)
 * - Tự do chọn thuật toán sinh (Kruskal, Prim, DFS) và kích thước mê cung (5x5 đến 30x30)
 * - Tốc độ Pacman tăng dần từ dễ đến khó theo cấp độ
 * - Theo dõi vị trí người chơi chính xác cho AI Pac-man
 */
@Composable
fun HexGameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language
    val isDark = uiState.progress.isDarkMode

    var selectedLevel by remember { mutableIntStateOf(1) }
    var isPacmanMode by remember { mutableStateOf(false) }
    var isCustomMode by remember { mutableStateOf(false) }

    // Thuật toán & Kích thước tùy chọn cho người chơi
    var selectedAlgorithm by remember { mutableStateOf(HexAlgorithm.KRUSKAL) }
    var customCols by remember { mutableIntStateOf(12) }
    var customRows by remember { mutableIntStateOf(12) }
    var showCustomDialog by remember { mutableStateOf(false) }

    var currentHexMaze by remember { mutableStateOf<HexMaze?>(null) }
    var hexViewRef by remember { mutableStateOf<HexMazeGameView?>(null) }

    var currentMoves by remember { mutableIntStateOf(0) }
    var showWinDialog by remember { mutableStateOf(false) }

    // Pacman chasing state
    var pacmanPos by remember { mutableStateOf<HexMazeGameView.HexPoint?>(null) }
    var playerHexPos by remember { mutableStateOf<com.example.core.engine.HexPoint?>(null) }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    fun loadLevel(level: Int, pacman: Boolean, custom: Boolean = false) {
        selectedLevel = level
        isPacmanMode = pacman
        isCustomMode = custom
        showWinDialog = false
        currentMoves = 0

        val (c, r) = when {
            custom -> Pair(customCols, customRows)
            pacman -> HexMazeConfig.hexMapSizeForLevel(level + HexMazeConfig.PACMAN_UNLOCK_LEVEL)
            else -> HexMazeConfig.hexMapSizeForLevel(level)
        }

        val seed = if (custom) {
            "HEX_CUSTOM_${selectedAlgorithm.name}_${c}x${r}_${System.currentTimeMillis()}"
        } else {
            "HEX_${selectedAlgorithm.name}_${if (pacman) "P_" else ""}$level"
        }

        val maze = HexMazeEngine.buildHexMaze(
            cols = c,
            rows = r,
            seed = seed,
            algorithm = selectedAlgorithm
        )
        currentHexMaze = maze

        val spinePoints = maze.spine.map { HexMazeGameView.HexPoint(it.col, it.row) }
        val startPoint = HexMazeGameView.HexPoint(maze.start.col, maze.start.row)
        val goalPoint = HexMazeGameView.HexPoint(maze.goal.col, maze.goal.row)

        playerHexPos = com.example.core.engine.HexPoint(maze.start.col, maze.start.row)

        hexViewRef?.updateTheme(isDark, 0, 0, 0)
        hexViewRef?.setHexMazeData(
            maze.cols,
            maze.rows,
            maze.masks,
            startPoint,
            goalPoint,
            startPoint,
            spinePoints
        )

        if (pacman) {
            pacmanPos = goalPoint
            hexViewRef?.setPacmanPos(goalPoint)
        } else {
            pacmanPos = null
            hexViewRef?.setPacmanPos(null)
        }
    }

    LaunchedEffect(selectedLevel, isPacmanMode, isCustomMode, selectedAlgorithm, isDark) {
        loadLevel(selectedLevel, isPacmanMode, isCustomMode)
    }

    // AI Pacman Chase loop với độ khó tăng dần theo cấp độ (từ dễ đến khó)
    LaunchedEffect(isPacmanMode, currentHexMaze, showWinDialog) {
        if (!isPacmanMode || currentHexMaze == null || showWinDialog) return@LaunchedEffect
        delay(HexMazeConfig.PACMAN_SPAWN_DELAY_SEC * 1000L) // 5s xuất phát trễ

        val stepInterval = HexMazeConfig.pacmanStepIntervalForLevel(selectedLevel)

        while (!showWinDialog) {
            delay(stepInterval)
            val maze = currentHexMaze ?: break
            val currentPac = pacmanPos ?: break

            val pacHexPoint = com.example.core.engine.HexPoint(currentPac.col, currentPac.row)
            val playerPoint = playerHexPos ?: com.example.core.engine.HexPoint(maze.start.col, maze.start.row)
            val next = HexMazeEngine.HexPacmanAI.computeNextMove(maze, pacHexPoint, playerPoint)
            if (next != null) {
                val newPac = HexMazeGameView.HexPoint(next.col, next.row)
                pacmanPos = newPac
                hexViewRef?.setPacmanPos(newPac)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MazeBgDark)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // 1. TOP BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(AppScreen.HOME) }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MazeTextH1
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when {
                        isCustomMode -> if (lang == AppLanguage.VI) "MÊ CUNG TỰ TẠO (HEX)" else "CUSTOM HEX MAZE"
                        isPacmanMode -> if (lang == AppLanguage.VI) "PACMAN TRUY ĐUỔI (HEX)" else "HEX PACMAN CHASE"
                        else -> if (lang == AppLanguage.VI) "TỔ ONG LỤC GIÁC" else "HEXAGONAL MAZE"
                    },
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeTextH1
                )
                Text(
                    text = when {
                        isCustomMode -> "${customCols}×${customRows} • ${selectedAlgorithm.name}"
                        isPacmanMode -> if (lang == AppLanguage.VI) "Cấp $selectedLevel/20 • Độ khó: ${(selectedLevel * 5)}%" else "Stage $selectedLevel/20 • Diff: ${(selectedLevel * 5)}%"
                        else -> if (lang == AppLanguage.VI) "Màn $selectedLevel/50 • ${selectedAlgorithm.name}" else "Level $selectedLevel/50 • ${selectedAlgorithm.name}"
                    },
                    fontSize = 11.sp,
                    color = MazeAmber
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Surface(
                    onClick = { showCustomDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    color = MazeSurface2,
                    border = BorderStroke(1.dp, MazeEdgeHighlight)
                ) {
                    Box(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                        Icon(Icons.Default.Tune, contentDescription = "Tùy chỉnh", tint = MazeAmber, modifier = Modifier.size(16.dp))
                    }
                }

                Surface(
                    onClick = { loadLevel(selectedLevel, isPacmanMode, isCustomMode) },
                    shape = RoundedCornerShape(10.dp),
                    color = MazeSurface2,
                    border = BorderStroke(1.dp, MazeEdgeHighlight)
                ) {
                    Box(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = MazeTextH1, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. MODE SELECTOR (3 CHẾ ĐỘ: MÀN THƯỜNG / PACMAN ĐUỔI / TỰ TẠO)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Màn thường
            Surface(
                onClick = { loadLevel(1, false, false) },
                shape = RoundedCornerShape(10.dp),
                color = if (!isPacmanMode && !isCustomMode) MazeAmber else MazeSurface1,
                border = BorderStroke(1.dp, if (!isPacmanMode && !isCustomMode) MazeAmber else MazeEdgeHighlight),
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == AppLanguage.VI) "🐝 Thường (50)" else "🐝 Normal (50)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isPacmanMode && !isCustomMode) Color.Black else MazeTextBody
                    )
                }
            }

            // Pacman đuổi
            Surface(
                onClick = { loadLevel(1, true, false) },
                shape = RoundedCornerShape(10.dp),
                color = if (isPacmanMode && !isCustomMode) Color(0xFFEF4444) else MazeSurface1,
                border = BorderStroke(1.dp, if (isPacmanMode && !isCustomMode) Color(0xFFEF4444) else MazeEdgeHighlight),
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == AppLanguage.VI) "👻 Sói/Pacman" else "👻 Pacman (20)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPacmanMode && !isCustomMode) Color.White else MazeTextBody
                    )
                }
            }

            // Tự tạo
            Surface(
                onClick = {
                    showCustomDialog = true
                },
                shape = RoundedCornerShape(10.dp),
                color = if (isCustomMode) Color(0xFF8B5CF6) else MazeSurface1,
                border = BorderStroke(1.dp, if (isCustomMode) Color(0xFF8B5CF6) else MazeEdgeHighlight),
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == AppLanguage.VI) "🛠️ Tự Tạo" else "🛠️ Custom",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCustomMode) Color.White else MazeTextBody
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 3. LEVEL HORIZONTAL SELECTOR (chỉ hiển thị khi không ở custom mode)
        if (!isCustomMode) {
            val maxLevels = if (isPacmanMode) HexMazeConfig.MAX_PACMAN_LEVEL else HexMazeConfig.MAX_HEX_LEVEL
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items((1..maxLevels).toList()) { lvl ->
                    val isSelected = (lvl == selectedLevel)
                    Surface(
                        onClick = { loadLevel(lvl, isPacmanMode, false) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) MazeAmber else MazeSurface2,
                        border = BorderStroke(1.dp, if (isSelected) MazeAmber else MazeEdgeHighlight)
                    ) {
                        Text(
                            text = "$lvl",
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (isSelected) Color.Black else MazeTextBody,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        } else {
            // Hiển thị thông tin mê cung tự tạo
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MazeSurface2,
                border = BorderStroke(1.dp, MazeEdgeHighlight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📐 ${customCols}×${customRows} • ${if (lang == AppLanguage.VI) selectedAlgorithm.nameVi else selectedAlgorithm.nameEn}",
                        fontSize = 11.sp,
                        color = MazeAmber,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(
                        onClick = { showCustomDialog = true },
                        modifier = Modifier.height(26.dp)
                    ) {
                        Text(if (lang == AppLanguage.VI) "Thay đổi" else "Change", fontSize = 11.sp, color = MazeTextH1)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 4. MAIN HEX GAME VIEW
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(MazeSurface1)
                .padding(2.dp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    HexMazeGameView(ctx).apply {
                        setOnHexMoveListener(object : HexMazeGameView.OnHexMoveListener {
                            override fun onMove(newCol: Int, newRow: Int, totalMoves: Int) {
                                currentMoves = totalMoves
                                playerHexPos = com.example.core.engine.HexPoint(newCol, newRow)
                            }

                            override fun onWallHit() {
                                viewModel.hapticManager.performWallHitFeedback()
                            }

                            override fun onGameWin(totalMoves: Int) {
                                currentMoves = totalMoves
                                showWinDialog = true
                                viewModel.soundManager.playWin()
                                viewModel.hapticManager.performWinFeedback()
                            }
                        })
                        hexViewRef = this
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 5. HUD CONTROLS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == AppLanguage.VI) "Bước đi: $currentMoves" else "Moves: $currentMoves",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MazeTextH1
            )

            Button(
                onClick = {
                    if (isCustomMode) {
                        loadLevel(1, isPacmanMode, true)
                    } else {
                        val maxLevels = if (isPacmanMode) HexMazeConfig.MAX_PACMAN_LEVEL else HexMazeConfig.MAX_HEX_LEVEL
                        val next = (selectedLevel + 1).coerceAtMost(maxLevels)
                        loadLevel(next, isPacmanMode, false)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MazeAmber),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isCustomMode) {
                        if (lang == AppLanguage.VI) "Sinh Lại ⟳" else "Regenerate ⟳"
                    } else {
                        if (lang == AppLanguage.VI) "Màn Tiếp →" else "Next Level →"
                    },
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }

    // WIN DIALOG
    if (showWinDialog) {
        val maxL = if (isPacmanMode) HexMazeConfig.MAX_PACMAN_LEVEL else HexMazeConfig.MAX_HEX_LEVEL
        AlertDialog(
            onDismissRequest = { showWinDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Celebration, contentDescription = null, tint = MazeStar)
                    Text(text = if (lang == AppLanguage.VI) "Chiến Thắng!" else "Victory!", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = if (lang == AppLanguage.VI)
                        "Bạn đã vượt qua mê cung với $currentMoves bước đi!"
                    else
                        "You cleared the hexagonal maze in $currentMoves moves!",
                    color = MazeTextBody
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWinDialog = false
                        if (isCustomMode) {
                            loadLevel(1, isPacmanMode, true)
                        } else {
                            val next = (selectedLevel + 1).coerceAtMost(maxL)
                            loadLevel(next, isPacmanMode, false)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                ) {
                    Text(if (lang == AppLanguage.VI) "Tiếp Tục" else "Continue", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showWinDialog = false
                    loadLevel(selectedLevel, isPacmanMode, isCustomMode)
                }) {
                    Text(if (lang == AppLanguage.VI) "Chơi Lại" else "Replay", color = MazeTextBody)
                }
            },
            containerColor = MazeSurface2
        )
    }

    // DIALOG TÙY CHỌN TỰ TẠO MÊ CUNG LỤC GIÁC (CUSTOM MAZE DIALOG)
    if (showCustomDialog) {
        var tempCols by remember { mutableIntStateOf(customCols) }
        var tempRows by remember { mutableIntStateOf(customRows) }
        var tempAlg by remember { mutableStateOf(selectedAlgorithm) }
        var tempPacman by remember { mutableStateOf(isPacmanMode) }

        AlertDialog(
            onDismissRequest = { showCustomDialog = false },
            containerColor = MazeSurface1,
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "🛠️ Tự Tạo Mê Cung Lục Giác" else "🛠️ Custom Hex Maze Generator",
                    color = MazeTextH1,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (lang == AppLanguage.VI) "Chọn thuật toán tạo mê cung:" else "Choose generation algorithm:",
                        color = MazeTextBody,
                        fontSize = 12.sp
                    )

                    // 3 thuật toán: Kruskal, Prim, DFS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        HexAlgorithm.values().forEach { alg ->
                            val isSel = (tempAlg == alg)
                            Surface(
                                onClick = { tempAlg = alg },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MazeAmber else MazeSurface2,
                                border = BorderStroke(1.dp, if (isSel) MazeAmber else MazeEdgeHighlight),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = when (alg) {
                                        HexAlgorithm.KRUSKAL -> "Kruskal"
                                        HexAlgorithm.PRIM -> "Prim"
                                        HexAlgorithm.DFS -> "DFS"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) Color.Black else MazeTextBody,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Kích thước chiều ngang (cột: 5..30)
                    Text(
                        text = if (lang == AppLanguage.VI) "Số cột (Cols): $tempCols" else "Columns: $tempCols",
                        color = MazeTextH1,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = tempCols.toFloat(),
                        onValueChange = { tempCols = it.toInt() },
                        valueRange = 5f..30f,
                        steps = 24,
                        colors = SliderDefaults.colors(
                            thumbColor = MazeAmber,
                            activeTrackColor = MazeAmber
                        )
                    )

                    // Kích thước chiều dọc (hàng: 5..30)
                    Text(
                        text = if (lang == AppLanguage.VI) "Số hàng (Rows): $tempRows" else "Rows: $tempRows",
                        color = MazeTextH1,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = tempRows.toFloat(),
                        onValueChange = { tempRows = it.toInt() },
                        valueRange = 5f..30f,
                        steps = 24,
                        colors = SliderDefaults.colors(
                            thumbColor = MazeAmber,
                            activeTrackColor = MazeAmber
                        )
                    )

                    // Chế độ Pacman truy đuổi bật/tắt
                    Surface(
                        onClick = { tempPacman = !tempPacman },
                        shape = RoundedCornerShape(8.dp),
                        color = if (tempPacman) Color(0xFFEF4444).copy(alpha = 0.2f) else MazeSurface2,
                        border = BorderStroke(1.dp, if (tempPacman) Color(0xFFEF4444) else MazeEdgeHighlight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == AppLanguage.VI) "👻 Thêm Pacman truy đuổi" else "👻 Add Pacman chase",
                                fontSize = 12.sp,
                                color = MazeTextH1,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (tempPacman) "BẬT" else "TẮT",
                                fontSize = 11.sp,
                                color = if (tempPacman) Color(0xFFEF4444) else MazeTextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        customCols = tempCols
                        customRows = tempRows
                        selectedAlgorithm = tempAlg
                        isPacmanMode = tempPacman
                        isCustomMode = true
                        showCustomDialog = false
                        loadLevel(1, tempPacman, true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                ) {
                    Text(if (lang == AppLanguage.VI) "Tạo Mê Cung" else "Create Maze", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomDialog = false }) {
                    Text(if (lang == AppLanguage.VI) "Hủy" else "Cancel", color = MazeTextMuted)
                }
            }
        )
    }
}
