package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.AppLanguage
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1

/**
 * Nút chuyển đổi ngôn ngữ hỗ trợ 8 ngôn ngữ phổ biến nhất thế giới.
 * Hiển thị dạng LazyRow cuộn ngang, mỗi ô là cờ + mã ngôn ngữ.
 * isCompact=true: chỉ hiện cờ + mã 2 chữ; isCompact=false: hiện cờ + tên đầy đủ.
 */
@Composable
fun LanguageToggleSwitch(
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
    isCompact: Boolean = true
) {
    val allLanguages = AppLanguage.values().toList()

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .testTag("language_toggle_switch"),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(allLanguages) { lang ->
            val isSelected = (lang == currentLanguage)
            LanguageSegment(
                language = lang,
                isSelected = isSelected,
                label = if (isCompact) lang.code.uppercase() else lang.displayName,
                flag = lang.flag,
                onClick = { onLanguageSelected(lang) }
            )
        }
    }
}

@Composable
private fun LanguageSegment(
    language: AppLanguage,
    isSelected: Boolean,
    label: String,
    flag: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    val bgColor by animateColorAsState(
        targetValue = if (isSelected) MazeAmber.copy(alpha = 0.25f) else Color.Transparent,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "lang_bg"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isSelected) MazeAmber else MazeEdgeHighlight,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "lang_border"
    )

    val textColor by animateColorAsState(
        targetValue = if (isSelected) MazeAmber else MazeTextBody,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "lang_text"
    )

    val segmentShape = RoundedCornerShape(10.dp)

    Box(
        modifier = Modifier
            .clip(segmentShape)
            .background(bgColor)
            .border(BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor), segmentShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("lang_segment_${language.code}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = flag,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                color = textColor,
                textAlign = TextAlign.Center
            )
        }
    }
}
