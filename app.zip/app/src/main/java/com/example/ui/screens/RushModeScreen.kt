package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.engine.MazeBuilder
import com.example.core.engine.RushModeConfig
import com.example.core.engine.RushModeManager
import com.example.core.engine.RushModeState
import com.example.core.i18n.AppLanguage
import com.example.ui.components.MazeGameView
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel
import kotlinx.coroutines.delay

/**
 * Màn hình Chế Độ Thử Thách 10 Phút (Rush Mode Speedrun):
 * - Tổng thời gian: 600 giây (10 phút)
 * - Mê cung tăng dần kích thước từ 5×5 đến 25×25
 * - Mục tiêu: Vượt qua nhiều mê cung nhất có thể để đạt Rank và điểm cao nhất
 */
@Composable
fun RushModeScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language
    val isDark = uiState.progress.isDarkMode

    var rushState by remember { mutableStateOf(RushModeState()) }
    var mazeViewRef by remember { mutableStateOf<MazeGameView?>(null) }
    var showResultDialog by remember { mutableStateOf(false) }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    fun loadNextMaze(clearedCount: Int) {
        val mazeView = mazeViewRef ?: return  // Guard: view must be ready
        val size = RushModeConfig.mazeSizeForRound(clearedCount)
        val levelDef = RushModeConfig.generateRushLevelDef(clearedCount)
        val maze = MazeBuilder.buildMaze(
            w = size,
            h = size,
            target = levelDef.target,
            seedBig = (clearedCount.toULong() xor System.currentTimeMillis().toULong()),
            algorithmIndex = levelDef.algorithmIndex
        )

        val startPt = MazeGameView.MazePoint(maze.start.x, maze.start.y)
        val goalPt = MazeGameView.MazePoint(maze.goal.x, maze.goal.y)
        val spinePoints = maze.spine.map { MazeGameView.MazePoint(it.x, it.y) }

        // Use proper dark-theme colors instead of all-zeros (which makes maze invisible)
        val darkPanel   = android.graphics.Color.parseColor("#0B1120")
        val darkWall    = android.graphics.Color.parseColor("#38BDF8")
        val darkVisited = android.graphics.Color.argb(89, 2, 132, 199)  // ~35% alpha #0284C7
        val darkAccent  = android.graphics.Color.parseColor("#38BDF8")
        mazeView.updateStudioTheme(darkPanel, darkWall, darkVisited, darkAccent)
        mazeView.setMazeData(
            maze.w,
            maze.h,
            maze.masks,
            startPt,
            goalPt,
            startPt,
            emptySet(),
            listOf(startPt),
            spinePoints,
            null
        )
    }

    fun startNewRushGame() {
        rushState = RushModeManager.startNewSession()
        showResultDialog = false
        // Note: loadNextMaze(0) is called via LaunchedEffect below once mazeViewRef is set
    }

    // Load first maze once AndroidView factory sets mazeViewRef and game becomes active
    var rushViewReady by remember { mutableStateOf(false) }
    LaunchedEffect(rushViewReady, rushState.isActive) {
        if (rushViewReady && rushState.isActive && rushState.mazesCleared == 0) {
            loadNextMaze(0)
        }
    }

    // Timer countdown 10 phút
    LaunchedEffect(rushState.isActive, rushState.isFinished) {
        if (!rushState.isActive || rushState.isFinished) return@LaunchedEffect
        while (rushState.isActive && !rushState.isFinished) {
            delay(1000L)
            val updated = RushModeManager.updateTimer(rushState)
            rushState = updated
            if (updated.isFinished) {
                showResultDialog = true
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MazeBgDark)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // 1. TOP BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(AppScreen.HOME) }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MazeTextH1
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (lang == AppLanguage.VI) "THỬ THÁCH 10 PHÚT" else "10-MIN SPEEDRUN RUSH",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeTextH1
                )
                val rank = RushModeManager.getRank(rushState.mazesCleared)
                Text(
                    text = "${rank.emoji} ${if (lang == AppLanguage.VI) rank.nameVi else rank.nameEn} • ${rushState.mazesCleared} Mê cung",
                    fontSize = 11.sp,
                    color = MazeAmber
                )
            }

            // Đếm ngược 600s
            val mins = rushState.remainingSeconds / 60
            val secs = rushState.remainingSeconds % 60
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (rushState.remainingSeconds <= 60) Color(0xFFEF4444) else MazeSurface2,
                border = BorderStroke(1.dp, MazeEdgeHighlight)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Timer,
                        contentDescription = null,
                        tint = if (rushState.remainingSeconds <= 60) Color.White else MazeAmber,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = String.format("%02d:%02d", mins, secs),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = if (rushState.remainingSeconds <= 60) Color.White else MazeTextH1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 2. HUD: Kích thước hiện tại + Điểm số
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MazeSurface1),
            border = BorderStroke(1.dp, MazeEdgeHighlight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (lang == AppLanguage.VI) "Mê Cung Hiện Tại" else "Current Maze",
                        fontSize = 10.sp,
                        color = MazeTextMuted
                    )
                    Text(
                        text = "#${rushState.mazesCleared + 1} (${rushState.currentMazeSize}×${rushState.currentMazeSize})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeAmber
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (lang == AppLanguage.VI) "Tổng Điểm" else "Total Score",
                        fontSize = 10.sp,
                        color = MazeTextMuted
                    )
                    Text(
                        text = "${rushState.totalScore} pts",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF38BDF8)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. MAIN GAME VIEW
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(MazeSurface1)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!rushState.isActive && !rushState.isFinished) {
                // Màn hình bắt đầu
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = MazeAmber,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (lang == AppLanguage.VI) "THỬ THÁCH KHÁM PHÁ 10 PHÚT" else "10-MINUTE MAZE RUSH",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MazeTextH1
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (lang == AppLanguage.VI)
                            "Khám phá các mê cung từ 5×5 đến 25×25 trong 600 giây.\nAi giải được nhiều mê cung nhất sẽ đạt hạng cao nhất!"
                        else
                            "Solve mazes from 5×5 to 25×25 in 600 seconds.\nSolve as many as you can to achieve the Master rank!",
                        fontSize = 12.sp,
                        color = MazeTextBody,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { startNewRushGame() },
                        colors = ButtonDefaults.buttonColors(containerColor = MazeAmber),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.VI) "BẮT ĐẦU 10 PHÚT" else "START 10 MINUTES",
                            color = Color.Black,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                AndroidView(
                    factory = { ctx ->
                        MazeGameView(ctx).apply {
                            setOnMazeMoveListener(object : MazeGameView.OnMazeMoveListener {
                                override fun onMove(dx: Int, dy: Int, newPlayer: MazeGameView.MazePoint?, totalMoves: Int) {}
                                override fun onUndo(restoredPlayer: MazeGameView.MazePoint?) {}
                                override fun onWallHit() {
                                    viewModel.hapticManager.performWallHitFeedback()
                                }
                                override fun onGameWin(totalMoves: Int) {
                                    viewModel.soundManager.playWin()
                                    viewModel.hapticManager.performWinFeedback()
                                    val solveSec = ((System.currentTimeMillis() - rushState.currentMazeStartTime) / 1000).toInt().coerceAtLeast(1)
                                    val nextState = RushModeManager.onMazeCleared(rushState, solveSec, totalMoves)
                                    rushState = nextState
                                    loadNextMaze(nextState.mazesCleared)
                                }
                            })
                            mazeViewRef = this
                            rushViewReady = true  // Signal that view is ready for first maze load
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    // KẾT QUẢ HẾT 10 PHÚT
    if (showResultDialog) {
        val rank = RushModeManager.getRank(rushState.mazesCleared)
        AlertDialog(
            onDismissRequest = { showResultDialog = false },
            title = {
                Text(
                    text = if (lang == AppLanguage.VI) "Hết Giờ! Kết Quả 10 Phút" else "Time's Up! 10-Min Result",
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${rank.emoji} Danh Hiệu: ${if (lang == AppLanguage.VI) rank.nameVi else rank.nameEn}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MazeAmber
                    )
                    Text(
                        text = if (lang == AppLanguage.VI)
                            "• Mê cung đã vượt qua: ${rushState.mazesCleared}\n• Tổng điểm tích lũy: ${rushState.totalScore} pts"
                        else
                            "• Mazes cleared: ${rushState.mazesCleared}\n• Total score: ${rushState.totalScore} pts",
                        fontSize = 13.sp,
                        color = MazeTextBody
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultDialog = false
                        startNewRushGame()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                ) {
                    Text(if (lang == AppLanguage.VI) "Thử Lại 10 Phút" else "Play Again", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResultDialog = false
                    viewModel.navigateTo(AppScreen.HOME)
                }) {
                    Text(if (lang == AppLanguage.VI) "Về Trang Chủ" else "Home", color = MazeTextBody)
                }
            },
            containerColor = MazeSurface2
        )
    }
}
