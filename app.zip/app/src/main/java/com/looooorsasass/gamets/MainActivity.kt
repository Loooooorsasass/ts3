package com.looooorsasass.gamets

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.ads.AdManager
import com.example.core.i18n.AppLanguage
import com.example.ui.screens.AchievementsScreen
import com.example.ui.screens.DailyChallengeScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HexGameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.OneLineScreen
import com.example.ui.screens.ReplayScreen
import com.example.ui.screens.RushModeScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeBgSoftWhite
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextMuted
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

/**
 * MainActivity chính thức chạy toàn bộ Game Mê Cung (MazeX / Maze Game Engine):
 * 1. Khởi tạo cấu hình quảng cáo thân thiện với trẻ em & gia đình (COPPA / Age 3+ / Xếp hạng G).
 * 2. Kích hoạt giao diện hiển thị tràn viền enableEdgeToEdge() chuẩn Android 15 & 16.
 * 3. Kết nối toàn bộ 8 màn chơi hoàn chỉnh: HomeScreen, GameScreen, OneLineScreen, ShopScreen,
 *    DailyChallengeScreen, AchievementsScreen, LeaderboardScreen, ReplayScreen.
 * 4. Xử lý Predictive Back Gesture bằng BackHandler chuẩn xác.
 * 5. Lưu trữ tiến trình game tự động và bền vững qua Room Database (AppDatabase).
 */
class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels()

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Xin quyền thông báo (POST_NOTIFICATIONS) trên Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Xử lý deep link điều hướng từ thông báo Flash Sale
        handleIntent(intent)

        // Áp dụng cấu hình thân thiện với trẻ em & gia đình (COPPA / Age 3+ / Xếp hạng G)
        try {
            AdManager.getInstance(applicationContext)
        } catch (_: Exception) {}

        // Kích hoạt giao diện tràn viền chuẩn Android 15 & 16
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val isDark = uiState.progress.isDarkMode

            MyApplicationTheme(darkTheme = isDark) {
                var showExitDialog by remember { mutableStateOf(false) }

                // Hiển thị quảng cáo xen kẽ (Interstitial Ad) sau khi thắng ván hoặc khi thoát về màn hình chính.
                // Cờ pendingInterstitial được bật trong GameViewModel.handleWin() / navigateTo(HOME) và
                // được tiêu thụ tại đây (nơi có Activity) để thực sự gọi AdMob.
                LaunchedEffect(uiState.pendingInterstitial) {
                    if (uiState.pendingInterstitial) {
                        viewModel.triggerInterstitial(this@MainActivity)
                    }
                }

                // Xử lý nút quay lại (Back Gesture) chuẩn Android 15/16
                BackHandler(enabled = true) {
                    when {
                        showExitDialog -> {
                            showExitDialog = false
                        }
                        uiState.currentScreen == AppScreen.HOME -> {
                            showExitDialog = true
                        }
                        else -> {
                            viewModel.navigateTo(AppScreen.HOME)
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_maze_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    containerColor = if (isDark) MazeBgDark else MazeBgSoftWhite
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentScreen) {
                            AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                            AppScreen.PLAYING -> GameScreen(viewModel = viewModel)
                            AppScreen.REPLAY -> ReplayScreen(viewModel = viewModel)
                            AppScreen.LEADERBOARD -> LeaderboardScreen(viewModel = viewModel)
                            AppScreen.ACHIEVEMENTS -> AchievementsScreen(viewModel = viewModel)
                            AppScreen.DAILY_CHALLENGE -> DailyChallengeScreen(viewModel = viewModel)
                            AppScreen.SHOP -> ShopScreen(viewModel = viewModel)
                            AppScreen.ONELINE_GAME -> OneLineScreen(viewModel = viewModel)
                            AppScreen.HEX_PLAYING -> HexGameScreen(viewModel = viewModel)
                            AppScreen.RUSH_MODE -> RushModeScreen(viewModel = viewModel)
                        }
                    }

                    // ─── Trình Thiết Lập Lần Đầu: Wizard 4 Bước ───────────────────────────
                    if (uiState.showFirstLaunchLanguageDialog) {
                        var setupStep by remember { mutableIntStateOf(1) }
                        var chosenLang by remember { mutableStateOf(AppLanguage.VI) }
                        var initialIsDark by remember { mutableStateOf(uiState.progress.isDarkMode) }
                        var initialNickname by remember { mutableStateOf("") }

                        // Danh sách 8 ngôn ngữ phổ biến nhất thế giới
                        val allLanguages = AppLanguage.values().toList()

                        AlertDialog(
                            onDismissRequest = {},  // Không cho tắt bằng tap ra ngoài
                            containerColor = MazeSurface1,
                            shape = RoundedCornerShape(20.dp),
                            title = {
                                Column {
                                    // Thanh tiến trình bước
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        repeat(4) { idx ->
                                            val step = idx + 1
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(4.dp)
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(
                                                        if (step <= setupStep) MazeAmber
                                                        else MazeSurface2
                                                    )
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = when (setupStep) {
                                            1 -> "🌐 Chọn Ngôn Ngữ / Choose Language"
                                            2 -> "🎨 Chọn Giao Diện / Choose Theme"
                                            3 -> "✏️ Đặt Tên / Set Nickname"
                                            else -> "🎮 Bắt Đầu / Start Game"
                                        },
                                        color = MazeTextH1,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "Bước $setupStep / 4",
                                        color = MazeAmber,
                                        fontSize = 11.sp
                                    )
                                }
                            },
                            text = {
                                when (setupStep) {
                                    // ─── BƯỚC 1: CHỌN NGÔN NGỮ ────────────────────────────
                                    1 -> {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "Chọn ngôn ngữ hiển thị của game:\nSelect your preferred language:",
                                                color = MazeTextBody,
                                                fontSize = 13.sp,
                                                modifier = Modifier.padding(bottom = 12.dp)
                                            )
                                            LazyVerticalGrid(
                                                columns = GridCells.Fixed(2),
                                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .wrapContentHeight()
                                            ) {
                                                items(allLanguages) { lang ->
                                                    val isSelected = (lang == chosenLang)
                                                    Surface(
                                                        onClick = { chosenLang = lang },
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = if (isSelected) MazeAmber else MazeSurface2,
                                                        border = BorderStroke(
                                                            width = if (isSelected) 2.dp else 1.dp,
                                                            color = if (isSelected) MazeAmber else Color.White.copy(alpha = 0.15f)
                                                        ),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                                                            horizontalAlignment = Alignment.CenterHorizontally
                                                        ) {
                                                            Text(
                                                                text = lang.flag,
                                                                fontSize = 24.sp
                                                            )
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = lang.displayName,
                                                                fontSize = 12.sp,
                                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                                                color = if (isSelected) Color.Black else MazeTextBody,
                                                                textAlign = TextAlign.Center
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // ─── BƯỚC 2: CHỌN GIAO DIỆN ───────────────────────────
                                    2 -> {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "Chọn giao diện màu sắc bạn thích:\nPick your preferred color theme:",
                                                color = MazeTextBody,
                                                fontSize = 13.sp,
                                                modifier = Modifier.padding(bottom = 16.dp)
                                            )
                                            // Tùy chọn Sáng / Tối
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                // Giao diện Tối
                                                Surface(
                                                    onClick = { initialIsDark = true },
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = Color(0xFF0B1120),
                                                    border = BorderStroke(
                                                        width = if (initialIsDark) 3.dp else 1.dp,
                                                        color = if (initialIsDark) MazeAmber else Color.White.copy(alpha = 0.2f)
                                                    ),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(
                                                        modifier = Modifier.padding(16.dp),
                                                        horizontalAlignment = Alignment.CenterHorizontally
                                                    ) {
                                                        Text("🌙", fontSize = 28.sp)
                                                        Spacer(modifier = Modifier.height(6.dp))
                                                        Text(
                                                            text = "Tối\nDark",
                                                            fontSize = 13.sp,
                                                            fontWeight = if (initialIsDark) FontWeight.ExtraBold else FontWeight.Normal,
                                                            color = if (initialIsDark) MazeAmber else Color.White.copy(alpha = 0.7f),
                                                            textAlign = TextAlign.Center
                                                        )
                                                        if (initialIsDark) {
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text("✓ Đang chọn", fontSize = 10.sp, color = MazeAmber)
                                                        }
                                                    }
                                                }
                                                // Giao diện Sáng
                                                Surface(
                                                    onClick = { initialIsDark = false },
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = Color(0xFFF5F5F0),
                                                    border = BorderStroke(
                                                        width = if (!initialIsDark) 3.dp else 1.dp,
                                                        color = if (!initialIsDark) MazeAmber else Color.Black.copy(alpha = 0.15f)
                                                    ),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(
                                                        modifier = Modifier.padding(16.dp),
                                                        horizontalAlignment = Alignment.CenterHorizontally
                                                    ) {
                                                        Text("☀️", fontSize = 28.sp)
                                                        Spacer(modifier = Modifier.height(6.dp))
                                                        Text(
                                                            text = "Sáng\nLight",
                                                            fontSize = 13.sp,
                                                            fontWeight = if (!initialIsDark) FontWeight.ExtraBold else FontWeight.Normal,
                                                            color = if (!initialIsDark) Color(0xFF7C5200) else Color.Black.copy(alpha = 0.6f),
                                                            textAlign = TextAlign.Center
                                                        )
                                                        if (!initialIsDark) {
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text("✓ Đang chọn", fontSize = 10.sp, color = Color(0xFF7C5200))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // ─── BƯỚC 3: ĐẶT NICKNAME ─────────────────────────────
                                    3 -> {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "Đặt tên hiển thị trên bảng xếp hạng:\nSet your leaderboard display name:",
                                                color = MazeTextBody,
                                                fontSize = 13.sp,
                                                modifier = Modifier.padding(bottom = 12.dp)
                                            )
                                            OutlinedTextField(
                                                value = initialNickname,
                                                onValueChange = { initialNickname = it.take(20) },
                                                label = { Text("Tên / Nickname") },
                                                placeholder = { Text("Ví dụ: Hunter99") },
                                                singleLine = true,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "• Có thể để trống và đặt sau\n• Can be left blank and set later",
                                                color = MazeTextMuted,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    // ─── BƯỚC 4: BẮT ĐẦU GAME ────────────────────────────
                                    else -> {
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("🎉", fontSize = 48.sp)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "Sẵn sàng! / All Set!",
                                                color = MazeTextH1,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 18.sp,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))
                                            // Tóm tắt cài đặt đã chọn
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = MazeSurface2,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(14.dp)) {
                                                    Text("${chosenLang.flag} ${chosenLang.displayName}", color = MazeTextH1, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(if (initialIsDark) "🌙 Giao diện Tối" else "☀️ Giao diện Sáng", color = MazeAmber, fontSize = 13.sp)
                                                    if (initialNickname.isNotBlank()) {
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Text("✏️ $initialNickname", color = MazeTextBody, fontSize = 13.sp)
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(14.dp))
                                            Text(
                                                text = "Nhấn 'Vào Game' để bắt đầu hướng dẫn!\nTap 'Enter Game' to start the tutorial!",
                                                color = MazeTextBody,
                                                fontSize = 12.sp,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                when (setupStep) {
                                    4 -> {
                                        // Nút cuối: Vào Game + Hướng dẫn
                                        Button(
                                            onClick = {
                                                viewModel.selectInitialLanguageAndStartLevel1(
                                                    lang = chosenLang,
                                                    isDark = initialIsDark,
                                                    nickname = initialNickname
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MazeAmber),
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                text = "🎮 Vào Game! / Enter Game!",
                                                color = Color.Black,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 15.sp
                                            )
                                        }
                                    }
                                    else -> {
                                        Button(
                                            onClick = { setupStep++ },
                                            colors = ButtonDefaults.buttonColors(containerColor = MazeAmber),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                text = "Tiếp / Next →",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            },
                            dismissButton = {
                                if (setupStep > 1) {
                                    TextButton(onClick = { setupStep-- }) {
                                        Text("← Quay lại / Back", color = MazeTextMuted)
                                    }
                                }
                            }
                        )
                    }

                    // Hộp thoại xác nhận thoát game
                    if (showExitDialog) {
                        val isVi = uiState.language == AppLanguage.VI
                        AlertDialog(
                            onDismissRequest = { showExitDialog = false },
                            containerColor = MazeSurface1,
                            title = {
                                Text(
                                    text = if (isVi) "Thoát Game?" else "Exit Game?",
                                    color = MazeTextH1,
                                    style = MaterialTheme.typography.titleLarge
                                )
                            },
                            text = {
                                Text(
                                    text = if (isVi) "Tiến trình của bạn đã được lưu tự động. Bạn có muốn thoát không?"
                                    else "Your game progress is saved automatically. Do you want to exit?",
                                    color = Color.White.copy(alpha = 0.85f),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = { finish() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                                ) {
                                    Text(
                                        text = if (isVi) "Thoát" else "Exit",
                                        color = Color.Black
                                    )
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showExitDialog = false }) {
                                    Text(
                                        text = if (isVi) "Chơi tiếp" else "Resume",
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val target = intent?.getStringExtra("NAVIGATE_TO")
        if (target == "shop") {
            viewModel.navigateTo(AppScreen.SHOP)
        }
    }
}
