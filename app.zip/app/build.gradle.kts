import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

// Chỉ kiểm tra thông tin ký khi thực sự build/ký bản release, để không chặn build debug.
val releaseSigningRequested = gradle.startParameter.taskNames.any { task ->
  val name = task.lowercase()
  name.contains("release") && (name.contains("bundle") || name.contains("assemble") || name.contains("package"))
}

android {
  namespace = "com.example"
  compileSdk = 36

  defaultConfig {
    applicationId = "com.aistudio.exactmaze.qrvx"
    minSdk = 26
    targetSdk = 36
    versionCode = 6
    versionName = "1.0.4"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val customKeystore = System.getenv("KEYSTORE_PATH")?.let { file(it) }
      val uploadKeystore = file("${rootDir}/packaging/signing/my-upload-key.jks")
      val fallbackKeystore = file("${rootDir}/debug.keystore")
      val targetKeystore = when {
        customKeystore?.exists() == true -> customKeystore
        uploadKeystore.exists() -> uploadKeystore
        else -> fallbackKeystore
      }

      // Mật khẩu ký chỉ lấy từ biến môi trường hoặc -P khi chạy Gradle. KHÔNG dùng mật khẩu mặc định:
      // nếu thiếu, build release phải thất bại rõ ràng thay vì âm thầm ký bằng khoá sai
      // khiến bản phát hành không thể cập nhật được trên Google Play.
      val resolvedStorePassword = System.getenv("STORE_PASSWORD") ?: findProperty("signingStorePassword") as String?
      val resolvedKeyPassword = System.getenv("KEY_PASSWORD") ?: findProperty("signingKeyPassword") as String?

      if (releaseSigningRequested &&
        (resolvedStorePassword.isNullOrBlank() || resolvedKeyPassword.isNullOrBlank())
      ) {
        throw GradleException(
          "Thiếu thông tin ký bản release. Hãy đặt biến môi trường STORE_PASSWORD và KEY_PASSWORD " +
            "(hoặc truyền -PsigningStorePassword=... -PsigningKeyPassword=...)."
        )
      }

      storeFile = targetKeystore
      storePassword = resolvedStorePassword
      keyAlias = System.getenv("KEY_ALIAS") ?: (if (targetKeystore == fallbackKeystore) "androiddebugkey" else "upload")
      keyPassword = resolvedKeyPassword
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
      ndk {
        debugSymbolLevel = "FULL"
      }
    }
    debug {
      val customDebugKeystore = file("${rootDir}/debug.keystore")
      if (customDebugKeystore.exists()) {
        signingConfig = signingConfigs.getByName("debugConfig")
      }
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  buildFeatures {
    compose = true
    buildConfig = true
  }

  testOptions {
    unitTests {
      isIncludeAndroidResources = true
    }
  }

  lint {
    abortOnError = false
    checkReleaseBuilds = false
  }

  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
// .env vẫn ở thư mục gốc; file mẫu đã được gom vào packaging/env/.
secrets {
  propertiesFileName = file("${rootDir}/.env").absolutePath
  defaultPropertiesFileName = file("${rootDir}/packaging/env/.env.example").absolutePath
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

dependencies {
  // BOMs
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))

  // Jetpack Compose Core & UI
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.activity.compose)

  // Material Design 3 & Icons
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)

  // Lifecycle & ViewModel Compose
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.viewmodel.compose)

  // Navigation Compose
  implementation(libs.androidx.navigation.compose)

  // Kotlin Coroutines
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.kotlinx.coroutines.android)

  // Core KTX & Fragment
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.fragment.ktx)

  // Room Database
  implementation(libs.androidx.room.runtime)
  implementation(libs.androidx.room.ktx)
  "ksp"(libs.androidx.room.compiler)

  // Networking & Serialization (Retrofit, OkHttp, Moshi)
  implementation(libs.retrofit)
  implementation(libs.converter.moshi)
  implementation(libs.okhttp)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  "ksp"(libs.moshi.kotlin.codegen)

  // Google Play Billing & Ads
  implementation(libs.billing.ktx)
  implementation(libs.play.services.ads)

  // Firebase
  implementation(libs.firebase.ai)
  implementation(libs.firebase.appcheck.recaptcha)
  implementation(libs.firebase.appcheck.debug)
  implementation(libs.firebase.auth)
  implementation(libs.firebase.firestore)

  // Unit and Screenshot Testing
  testImplementation(libs.junit)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)

  // Android Instrumented Testing
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)

  // Debugging & Tooling
  debugImplementation(libs.androidx.compose.ui.tooling)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
}
